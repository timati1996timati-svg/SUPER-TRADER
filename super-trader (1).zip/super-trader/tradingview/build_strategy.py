"""SuperTrader_Pro.pine ning BEGIN CORE ... END CORE qismidan strategiya faylini yaratadi.

    python3 tradingview/build_strategy.py

Indikator va strategiya hisob-kitobi har doim bir xil bo'lishi uchun core qo'lda
ko'chirilmaydi; testlar ham ikkalasi mos ekanini tekshiradi.
"""
import os

HERE = os.path.dirname(os.path.abspath(__file__))
BEGIN = "// ==================== BEGIN CORE ===================="
END = "// ==================== END CORE ===================="

HEADER = '''// This Pine Script® code is subject to the terms of the Apache License 2.0
// SuperTrader Pro - STRATEGIYA versiyasi (TradingView Strategy Tester uchun)
// AVTOMATIK YARATILGAN: tradingview/build_strategy.py. Core qismini SuperTrader_Pro.pine da o'zgartiring.
// Kirish: signal shami yopilgandan keyingi sham ochilishida (Python backtest kabi).
// Signal manbasi:
//   Firma          - reyting KO'PAYTIR/SOTIB OL ga ko'tarilganda; chiqish: trailing stop yoki reyting tushganda
//   Kengash        - 2+ strategiya rozi bo'lganda; chiqish: trailing stop yoki reyting tushganda
//   SMC Confluence - 9 omilli ICT/SMC signali; stop swing ortida, maqsad R x risk, teskari BOS da chiqish
// Pozitsiya hajmi: kapital x risk% x (Firma rejimida risk jamoasi ko'paytiruvchisi) / (kirish - stop).
// Bu moliyaviy maslahat emas. O'tmishdagi natija kelajakni kafolatlamaydi.

//@version=6
strategy("SuperTrader Pro Strategiya", shorttitle="SuperTrader Strat", overlay=true, initial_capital=10000, currency=currency.USD, commission_type=strategy.commission.percent, commission_value=0.1, slippage=2, pyramiding=0, default_qty_type=strategy.fixed, default_qty_value=1)

grpMode = "Strategiya"
mode    = input.string("Firma", "Signal manbasi", options=["Firma", "Kengash", "SMC Confluence"], group=grpMode)
maxPos  = input.float(100.0, "Maks. pozitsiya (% kapital)", minval=1, maxval=1000, group=grpMode)
showMA  = input.bool(true, "SMA 50 / 200", group=grpMode)

'''

TAIL = '''
// ============================================================ SAVDO MANTIQI
isSmc    = mode == "SMC Confluence"
longSig  = mode == "Firma" ? (planBuy and lvl <= minLevel and prevLvl > minLevel and finalM > 0) : isSmc ? cfBuy : councilLong
shortSig = mode == "Firma" ? (planSell and lvl >= 4 - minLevel and prevLvl < 4 - minLevel and finalM > 0) : isSmc ? (allowShort and cfSell) : councilShort
mult     = mode == "Firma" ? finalM : 1.0
sigStopL = isSmc ? cfStopL : close - stopAtr * atr
sigStopS = isSmc ? cfStopS : close + stopAtr * atr
sigTgtL  = isSmc ? cfTgtL : na
sigTgtS  = isSmc ? cfTgtS : na
tagL     = isSmc ? "SMC " + str.tostring(cfBull) + "/9" : "BUY " + ratingText(lvl)
tagS     = isSmc ? "SMC " + str.tostring(cfBear) + "/9" : "SHORT " + ratingText(lvl)

sizeFor(float stopPx) =>
    rpu = math.abs(close - stopPx)
    q = rpu > 0 ? strategy.equity * riskPct / 100 * mult / rpu : 0.0
    math.max(0.0, math.min(q, strategy.equity * maxPos / 100 / close))

var float trailS   = na
var float hiS      = na
var float loS      = na
var float pendStop = na

pos = strategy.position_size
// yangi ochilgan pozitsiya: stop signal paytidagi qiymatdan boshlanadi
if pos > 0 and nz(pos[1]) <= 0
    trailS := pendStop
    hiS := high
if pos < 0 and nz(pos[1]) >= 0
    trailS := pendStop
    loS := low

if pos > 0
    hiS := math.max(hiS, high)
    if isSmc
        if bearBOS
            strategy.close("L", comment="ayiq BOS")
    else if lvl >= 3
        strategy.close("L", comment="reyting: " + ratingText(lvl))
    else
        trailS := math.max(trailS, hiS - trailAtr * atr)
        strategy.exit("LX", "L", stop=trailS, comment="trailing stop")
else if pos < 0
    loS := math.min(loS, low)
    if isSmc
        if bullBOS
            strategy.close("S", comment="buqa BOS")
    else if lvl <= 1
        strategy.close("S", comment="reyting: " + ratingText(lvl))
    else
        trailS := math.min(trailS, loS + trailAtr * atr)
        strategy.exit("SX", "S", stop=trailS, comment="trailing stop")
else
    trailS := na
    if longSig
        q = sizeFor(sigStopL)
        if q > 0
            pendStop := sigStopL
            strategy.entry("L", strategy.long, qty=q, comment=tagL)
            strategy.exit("LX", "L", stop=sigStopL, limit=sigTgtL, comment="stop / maqsad")
    else if shortSig
        q = sizeFor(sigStopS)
        if q > 0
            pendStop := sigStopS
            strategy.entry("S", strategy.short, qty=q, comment=tagS)
            strategy.exit("SX", "S", stop=sigStopS, limit=sigTgtS, comment="stop / maqsad")

plot(showMA ? sma50 : na, "SMA 50", color=color.new(#3b82f6, 0))
plot(showMA ? sma200 : na, "SMA 200", color=color.new(#f59e0b, 0), linewidth=2)
plot(pos != 0 ? trailS : na, "Trailing stop", color=color.new(#f43f5e, 0), style=plot.style_linebr, linewidth=2)
bgcolor(color.new(ratingColor(lvl), 92), title="Reyting foni")
'''


def core(text: str) -> str:
    return text[text.index(BEGIN):text.index(END) + len(END)]


def build() -> str:
    with open(os.path.join(HERE, "SuperTrader_Pro.pine")) as f:
        return HEADER + core(f.read()) + "\n" + TAIL


if __name__ == "__main__":
    out = os.path.join(HERE, "SuperTrader_Pro_Strategy.pine")
    with open(out, "w") as f:
        f.write(build())
    print("yozildi:", out)
