# SuperTrader 🚀

[![CI](https://github.com/OWNER/super-trader/actions/workflows/ci.yml/badge.svg)](https://github.com/OWNER/super-trader/actions/workflows/ci.yml)
![Python](https://img.shields.io/badge/python-3.9%2B-blue)
![License](https://img.shields.io/badge/license-Apache--2.0-green)
![Dependencies](https://img.shields.io/badge/dependencies-0-brightgreen)

**Aksiya va kripto uchun "agentlar firmasi", strategiyalar, backtest, risk nazorati va TradingView indikatori.**
Faqat Python standart kutubxonasi kerak, `pip install` shart emas. Claude bilan ixtiyoriy jonli bahs ham bor.

> 🇬🇧 *English summary:* SuperTrader is a zero-dependency Python toolkit for stocks and crypto:
> a rule-based multi-agent "trading firm" (analysts → bull/bear debate → 5-tier rating → trader →
> risk team → portfolio manager, inspired by TradingAgents), five strategies, an honest backtester,
> Monte-Carlo "time machine", position sizing with PASS/BLOCK risk checks, paper trading, an optional
> Binance connector (testnet by default), an optional Claude-powered debate, and a matching
> TradingView Pine Script v6 indicator + strategy.

![Agentlar firmasi hisoboti](docs/analysis.png)

## Imkoniyatlar

| | |
| --- | --- |
| 🏢 **Agentlar firmasi** | 7 tahlilchi → buqa/ayiq bahsi → 5 darajali reyting → treyder rejasi → risk jamoasi (agressiv / neytral / ehtiyotkor) → portfel menejeri |
| 🧠 **Claude bilan bahs** (ixtiyoriy) | `--llm`: Claude dalillarni o'qib, o'zbek tilida bahs yozadi va o'z reytingini beradi |
| 🧱 **ICT/SMC Confluence** | BOS, Fair Value Gap, Order Block, talab/taklif zonalari, S/R, Wyckoff-lite, trend, RSI/MACD, hajm - 9 omilli ball va signal |
| 📈 **6 strategiya** | Bollinger+RSI+MACD, Donchian trend, EMA kesishuvi, ICT/SMC Confluence, ORB (kun ichida), firma reytingi + agentlar kengashi |
| 🧪 **Halol backtest** | kirish keyingi sham ochilishida; bitta shamda stop ham, maqsad ham urilsa, stop hisoblanadi; komissiya va sirpanish; reyting jadvali |
| 🎲 **Vaqt mashinasi** | rejani aktivning o'z shamlaridan 10 000 marta simulyatsiya qiladi |
| 🛡️ **Risk** | hajm = maks. zarar / stopgacha masofa; kunlik limit, R:R va pozitsiya chegarasi; natija PASS yoki BLOCK |
| 📒 **Qarorlar jurnali** | `analyze --save`, keyin `reflect`: qaysi reyting qanchalik to'g'ri chiqqani |
| 📺 **TradingView** | Pine v6 indikator va strategiya, Python bilan bir xil qoidalar ([tradingview/](tradingview/README.md)) |
| 💱 **Ma'lumot** | Yahoo Finance (aksiya), Binance (kripto), CSV. API kalit shart emas |
| 🧾 **Savdo** | qog'oz savdo (standart); Binance spot (standart testnet), aniq "HA ..." tasdig'isiz buyruq yuborilmaydi |

## Tez boshlash

```bash
git clone https://github.com/OWNER/super-trader.git
```

```bash
cd super-trader
```

```bash
python3 -m supertrader demo
```

`demo` internetsiz ishlaydi, sintetik narxlarda barcha strategiyalarni solishtiradi va
`supertrader_demo.html` faylini yaratadi. Haqiqiy bozor bilan ishlash uchun:

```bash
python3 -m supertrader analyze BTCUSDT AAPL --report tahlil.html
```

## Agentlar firmasi qanday ishlaydi

```mermaid
flowchart LR
    D[Narx ma'lumoti] --> A1[Trend] & A2[Momentum] & A3[Volatillik] & A4[Hajm] & A5[Bozor rejimi] & A6[ICT/SMC] & A7[Strategiyalar kengashi]
    A1 & A2 & A3 & A4 & A5 & A6 & A7 --> B{Buqa vs Ayiq bahsi}
    B --> R[5 darajali reyting<br/>SOTIB OL … SOT]
    R --> T[Treyder: kirish, stop, maqsad]
    T --> K1[Agressiv] & K2[Neytral] & K3[Ehtiyotkor / veto]
    K1 & K2 & K3 --> P[Portfel menejeri:<br/>risk ko'paytiruvchi, hajm]
    P --> J[(Qarorlar jurnali)] --> X[reflect: natija]
```

* Har bir tahlilchi aniq qoidalar bilan ball beradi (masalan: narx SMA200 dan yuqori bo'lsa +20,
  RSI 70 dan yuqori bo'lsa -10). Ballar yig'indisi -100 dan +100 gacha:
  **≥40 SOTIB OL · ≥15 KO'PAYTIR · KUT · ≤-15 KAMAYTIR · ≤-40 SOT**.
* Risk jamoasi ATR persentili, ADX va SMA200 trendiga qarab riskni oshiradi, kamaytiradi yoki veto qo'yadi.
* Har bir qaror faqat o'sha shamgacha bo'lgan ma'lumotdan chiqariladi (oldinga qaramaydi, bu test bilan tekshirilgan).
* `calibrate` buyrug'i reytingni tarixda tekshiradi: "SOTIB OL" berilgan kunlardan keyin narx haqiqatan
  "SOT" kunlaridan yaxshiroq harakat qilganmi? Agar yo'q bo'lsa, buni ochiq aytadi.

## ICT/SMC Confluence

9 ta omil, har biri 1 ball. BUY uchun kamida 5 ball kerak, tuzilma buqa bo'lishi va buqa balli ayiq
ballidan katta bo'lishi shart:

| # | Omil | Buqa sharti |
| --- | --- | --- |
| 1 | Trend | close > EMA20 > EMA50 |
| 2 | Bozor tuzilmasi | oxirgi BOS yuqoriga (swing yuqori yorilgan) |
| 3 | Fair Value Gap | 3 shamlik bo'shliq ≥ ATR × 0.15, tuzilma buzilmagan |
| 4 | Order Block | narx BOS dan oldingi teskari sham zonasida |
| 5 | Talab zonasi | narx pivot past ± ATR × 0.25 ichida |
| 6 | S/R | narx swing pastdan 0.15% dan yaqin |
| 7 | RSI | 50 < RSI < 70 |
| 8 | MACD | gistogramma musbat va o'smoqda |
| 9 | Hajm / Wyckoff-lite | hajm > o'rtacha × 1.3 yoki diapazon torayishi + hajm |

* Har bir tuzilma bosqichida faqat bitta signal beriladi (signal har shamda takrorlanmaydi).
* `smc` strategiyasida stop oxirgi swing past ortida (yoki 2×ATR), maqsad 2R, teskari BOS
  bo'lsa chiqiladi.
* Firmadagi **ICT/SMC tahlilchisi** faqat tuzilmaga xos omillarni sanaydi: BOS ±10, FVG, OB, zona, S/R
  va Wyckoff-lite ±5 dan. Trend, RSI, MACD va hajm boshqa tahlilchilarda bor, ular ikki marta sanalmaydi.
* ⚠️ Ball **g'alaba ehtimoli emas**, faqat bajarilgan omillar soni. Wyckoff-lite faqat taxminiy
  proksi, haqiqiy faza (spring, UTAD) aniqlash emas. Elliott to'lqinlari ataylab hisoblanmaydi,
  chunki avtomatik sanash ishonchsiz.

## Buyruqlar

| Buyruq | Vazifasi |
| --- | --- |
| `analyze SYMBOL [--save] [--llm] [--report f.html]` | agentlar firmasi: tahlil, bahs, reyting, reja, hajm |
| `calibrate SYMBOL [--horizon 10]` | firma reytingi tarixda qanchalik to'g'ri chiqqan |
| `reflect` | jurnaldagi qarorlarning haqiqiy natijasi |
| `signal SYMBOL...` | har bir strategiyaning hozirgi signali, hajmi va risk tekshiruvi |
| `backtest SYMBOL -s firm --report f.html` | tarixda sinash (barcha strategiyalar: `-s all`) |
| `leaderboard A B C` | strategiyalar musobaqasi bir nechta aktivda |
| `timemachine SYMBOL --entry E --stop S --target T` | rejani 10 000 marta simulyatsiya qilish |
| `size --entry E --stop S --target T --account N --max-loss L` | pozitsiya hajmi + PASS/BLOCK |
| `paper buy/sell/close/check/status` | qog'oz savdo |
| `binance balance/buy/sell` | Binance spot (standart testnet) |
| `strategies` | strategiyalar va parametrlar ro'yxati |

Umumiy sozlamalar: `-i 1h` (interval), `--source yahoo|binance`, `--csv fayl.csv`, `--account 5000`,
`--risk-pct 1`, `--max-loss 50`, `-P stop_atr=2.5 allow_short=true`.

Misollar:

```bash
python3 -m supertrader analyze BTCUSDT --save
```

```bash
python3 -m supertrader calibrate BTCUSDT ETHUSDT SPY
```

```bash
python3 -m supertrader backtest TSLA -i 5m --range 60d -s orb
```

```bash
python3 -m supertrader backtest BTCUSDT -i 4h -s smc firm --report smc.html
```

```bash
python3 -m supertrader size --entry 364.18 --stop 358.32 --target 370.04 --account 5000 --max-loss 50
```

## Claude bilan bahs (ixtiyoriy)

```bash
pip install anthropic
```

```bash
export ANTHROPIC_API_KEY=...
```

```bash
python3 -m supertrader analyze AAPL --llm
```

Raqamli qaror o'zgarmaydi. Claude (`claude-opus-5-5`) tahlilchilar dalillarini o'qib, buqa va ayiq
tadqiqotchilar, uchta risk tahlilchisi va portfel menejeri nomidan o'zbek tilida bahs yozadi. U o'z
reytingini beradi, terminal esa bu reyting qoidalar reytingi bilan mos yoki mos emasligini ko'rsatadi.
Claude rad etsa, server so'rovni boshqa modelda avtomatik qayta bajaradi (`fallbacks: "default"`).
API so'rovlari pullik.

## TradingView

`tradingview/SuperTrader_Pro.pine` faylini Pine Editor'ga qo'ying va **Add to chart** bosing.
Batafsil: [tradingview/README.md](tradingview/README.md).

## Xavfsizlik

* Qog'oz savdo standart holat. Binance standart holatda **testnet**; haqiqiy hisob uchun `--mainnet`
  kerak va aniq tasdiq yozish so'raladi, masalan `HA BUY 0.0003 BTCUSDT`.
* Kalitlar faqat muhit o'zgaruvchilaridan o'qiladi (`BINANCE_API_KEY`, `BINANCE_API_SECRET`,
  `ANTHROPIC_API_KEY`). Ularni hech qachon repozitoriyga qo'shmang. Binance kalitida
  "Enable Withdrawals" ni **yoqmang**.
* `trader_data/` (qog'oz hisob, jurnal) `.gitignore` ichida.

## Testlar

```bash
python3 -m unittest discover -s tests
```

```bash
python3 tests/pine_lint.py tradingview/*.pine
```

Testlar quyidagilarni tekshiradi:
* indikatorlar;
* risk hajmi (day-trader-skill misoli: $5 000 hisob va $50 chegara bilan 8 dona);
* backtest qoidalari (oldinga qaramaslik, avval stop);
* haqiqiy TSLA ma'lumotida ORB natijasi;
* ICT/SMC: pivot tasdiqlanishi, BOS, FVG, har bosqichda bitta signal, oldinga qaramaslik;
* firma qarorlari va jurnal;
* Claude so'rovining shakli;
* Pine skriptlari Python qoidalariga mosligi.

## Tuzilishi

```
supertrader/
├── agents/        firm.py (agentlar firmasi) · memory.py (jurnal) · llm.py (Claude)
├── strategies/    bollinger_macd · donchian_trend · ema_cross · confluence (smc) · orb · ensemble · firm
├── smc.py         ICT/SMC: pivot, BOS, FVG, Order Block, zonalar, Wyckoff-lite, 9 omilli ball
├── indicators.py  SMA EMA RSI MACD Bollinger ATR ADX/DMI VWMA OBV ...
├── backtest.py · montecarlo.py · risk.py · broker.py · report.py · data.py · cli.py
tradingview/       SuperTrader_Pro.pine · SuperTrader_Pro_Strategy.pine · build_strategy.py
tests/             unittest + Pine linter + fixtures
```

## Mualliflar va ilhom manbalari

SuperTrader quyidagi ochiq loyihalarning g'oyalari asosida **qayta yozilgan** (ularning kodi bu
repozitoriyda yo'q, batafsil: [NOTICE](NOTICE)):
[TradingAgents](https://github.com/TauricResearch/TradingAgents) (agentlar firmasi, 5 darajali reyting,
qarorlar jurnali), TradingAgents-CN, muallifi hsliuping (bahs darajalari),
[day-trader-skill](https://github.com/Jakeschincariol/day-trader-skill) (ORB, vaqt mashinasi, risk),
[binance-trader](https://github.com/yasinkuyu/binance-trader) (Bollinger strategiyasi),
trader, muallifi timercrack (kanal yorib o'tish trend strategiyasi),
[AI-Trader](https://github.com/HKUDS/AI-Trader) (agentlar kengashi, reyting jadvali),
`confluence_signal.pine` (ICT/SMC confluence indikatori; Pine v6 va Python'ga ko'chirilgan).

## Litsenziya

[Apache 2.0](LICENSE).

> ⚠️ **Bu moliyaviy maslahat emas.** O'tmishdagi natija kelajakni kafolatlamaydi. Avval qog'oz
> savdoda sinang va yo'qotishga tayyor bo'lmagan pulni xavf ostiga qo'ymang.
