"""ICT/SMC Confluence strategiyasi (confluence_signal.pine).

Kirish: 9 omilli confluence BUY signali (tuzilma buqa, ball >= chegara, har bosqichda bitta).
Stop: oxirgi swing past (agar narxdan past bo'lsa, ATR x 0.25 bufer bilan), aks holda narx - 2xATR.
Maqsad: ``target_r`` x risk (standart 2R). Chiqish: tuzilma teskari BOS bilan buzilsa.
"""

from .. import indicators as ta
from ..smc import compute
from .base import LONG, SHORT, Signal, Strategy


class SMCConfluence(Strategy):
    name = "smc"
    title = "ICT/SMC Confluence (9 omil)"
    origin = "confluence_signal.pine"
    params = dict(buy_threshold=5, sell_threshold=5, swing_len=5, target_r=2.0, fallback_atr=2.0, allow_short=False)

    def prepare(self, bars):
        super().prepare(bars)
        self.s = compute(bars, buy_threshold=self.p["buy_threshold"], sell_threshold=self.p["sell_threshold"],
                         swing_len=self.p["swing_len"])
        self.atr = ta.atr([b.h for b in bars], [b.l for b in bars], [b.c for b in bars], 14)

    def warmup(self):
        return 60

    def entry(self, i):
        s, a, c = self.s, self.atr[i], self.bars[i].c
        if not a:
            return None
        ind = dict(bull_score=s["bull_score"][i], bear_score=s["bear_score"][i], bias=s["bias"][i])
        if s["buy"][i]:
            sl = s["swing_low"][i]
            stop = sl - 0.25 * a if sl is not None and sl < c - 0.25 * a else c - self.p["fallback_atr"] * a
            return Signal(LONG, stop, c + (c - stop) * self.p["target_r"], 40 + 6 * s["bull_score"][i],
                          f"confluence {s['bull_score'][i]}/9, tuzilma buqa", self.name, ind)
        if self.p["allow_short"] and s["sell"][i]:
            sh = s["swing_high"][i]
            stop = sh + 0.25 * a if sh is not None and sh > c + 0.25 * a else c + self.p["fallback_atr"] * a
            return Signal(SHORT, stop, c - (stop - c) * self.p["target_r"], 40 + 6 * s["bear_score"][i],
                          f"confluence {s['bear_score'][i]}/9, tuzilma ayiq", self.name, ind)
        return None

    def exit(self, i, pos):
        if pos.side == LONG and self.s["bear_bos"][i]:
            return "ayiq BOS: tuzilma buzildi"
        if pos.side == SHORT and self.s["bull_bos"][i]:
            return "buqa BOS: tuzilma buzildi"
        return None
