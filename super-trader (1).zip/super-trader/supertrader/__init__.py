"""SuperTrader - agentlar firmasi, strategiyalar, backtest, risk va TradingView indikatori."""
__version__ = "2.1.0"
