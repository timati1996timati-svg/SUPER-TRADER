"""ICT/SMC Confluence - ko'p omilli signal (confluence_signal.pine dan, Python'ga ko'chirilgan).

Omillar (har biri 1 ball, jami 9):
  1. Trend: close > EMA20 > EMA50 (sotishda teskari)
  2. Bozor tuzilmasi: oxirgi BOS yo'nalishi (swing pivot yorilishi)
  3. Fair Value Gap: 3 shamlik bo'shliq, kamida ATR x 0.15
  4. Order Block: BOS ni keltirib chiqargan kuchli shamdan oldingi teskari sham zonasida
  5. Talab/taklif zonasi: kengroq pivot atrofida ATR x 0.25 qalinlikdagi zona ichida
  6. S/R: narx oxirgi swing past/yuqorisiga 0.15% dan yaqin
  7. RSI 50..70 (sotishda 30..50)
  8. MACD gistogrammasi musbat va o'smoqda (sotishda teskari)
  9. Hajm > o'rtacha x 1.3 yoki "Wyckoff-lite" (diapazon torayishi + hajm)

BUY: buqa balli >= chegara, tuzilma buqa va buqa > ayiq; har bir tuzilma bosqichida bitta signal.
Muhim: bu ehtimollik emas, balki omillar yig'indisi. Elliott to'lqinlari ataylab
hisoblanmaydi; Wyckoff faqat taxminiy proksi (haqiqiy faza aniqlash emas).

Har bir qiymat faqat o'sha shamgacha ma'lum bo'lgan ma'lumotdan hisoblanadi (pivotlar
``right`` sham keyin tasdiqlanadi - TradingView'dagi ``ta.pivothigh`` kabi).
"""

import math
from typing import Dict, List, Optional

from . import indicators as ta
from .data import Bar

DEFAULTS = dict(ema_fast=20, ema_slow=50, swing_len=5, fvg_atr=0.15, ob_disp_atr=1.2, sd_len=10,
                zone_atr=0.25, sr_tol_pct=0.15, rsi_len=14, rsi_ob=70, rsi_os=30, vol_len=20,
                vol_mult=1.3, wy_len=20, buy_threshold=5, sell_threshold=5)


def pivots(values: List[float], left: int, right: int, high: bool) -> List[Optional[float]]:
    """i-shamda tasdiqlangan pivot qiymati (pivot shami = i - right), aks holda None."""
    out: List[Optional[float]] = [None] * len(values)
    for i in range(left + right, len(values)):
        p = i - right
        v = values[p]
        side = values[p - left:p] + values[p + 1:i + 1]
        if high and all(v > x for x in side):
            out[i] = v
        elif not high and all(v < x for x in side):
            out[i] = v
    return out


def stdev(x: List[float], n: int) -> List[Optional[float]]:
    out: List[Optional[float]] = [None] * len(x)
    for i in range(n - 1, len(x)):
        w = x[i - n + 1:i + 1]
        m = sum(w) / n
        out[i] = math.sqrt(sum((v - m) ** 2 for v in w) / n)
    return out


def compute(bars: List[Bar], **params) -> Dict[str, list]:
    p = dict(DEFAULTS)
    p.update(params)
    N = len(bars)
    o = [b.o for b in bars]
    h = [b.h for b in bars]
    l = [b.l for b in bars]
    c = [b.c for b in bars]
    v = [b.v for b in bars]
    atr = ta.atr(h, l, c, 14)
    ef, es = ta.ema(c, p["ema_fast"]), ta.ema(c, p["ema_slow"])
    rsi = ta.rsi(c, p["rsi_len"])
    _, _, hist = ta.macd(c)
    vol_ma = ta.sma(v, p["vol_len"])
    sd = stdev(c, p["wy_len"])
    mid = ta.sma(c, p["wy_len"])
    width = [2 * s / m if s is not None and m else None for s, m in zip(sd, mid)]
    width_avg: List[Optional[float]] = [None] * N
    wl = p["wy_len"]
    for i in range(N):
        win = width[i - wl + 1:i + 1] if i >= wl - 1 else []
        if len(win) == wl and None not in win:
            width_avg[i] = sum(win) / wl
    ph = pivots(h, p["swing_len"], p["swing_len"], True)
    pl = pivots(l, p["swing_len"], p["swing_len"], False)
    ph_sd = pivots(h, p["sd_len"], p["sd_len"], True)
    pl_sd = pivots(l, p["sd_len"], p["sd_len"], False)

    keys = ("swing_high", "swing_low", "bull_bos", "bear_bos", "bias", "bull_fvg", "bear_fvg", "in_bull_ob",
            "in_bear_ob", "in_demand", "in_supply", "near_support", "near_resistance", "accumulation",
            "distribution", "vol_confirm", "bull_score", "bear_score", "buy", "sell", "demand_top", "demand_bot",
            "supply_top", "supply_bot", "ob_high", "ob_low", "ob_bias", "trend_bull", "trend_bear")
    S: Dict[str, list] = {k: [None] * N for k in keys}
    lsh = lsl = None
    bias = 0
    rbf = rbe = False
    ob_hi = ob_lo = None
    ob_bias = 0
    d_top = d_bot = s_top = s_bot = None
    buy_fired = sell_fired = False
    prev_lsh = prev_lsl = None
    for i in range(N):
        a = atr[i]
        if ph[i] is not None:
            lsh = ph[i]
        if pl[i] is not None:
            lsl = pl[i]
        bull_bos = i > 0 and lsh is not None and prev_lsh is not None and c[i] > lsh and c[i - 1] <= prev_lsh
        bear_bos = i > 0 and lsl is not None and prev_lsl is not None and c[i] < lsl and c[i - 1] >= prev_lsl
        prev_lsh, prev_lsl = lsh, lsl
        if bull_bos:
            bias = 1
        if bear_bos:
            bias = -1
        if i >= 2 and a is not None:
            if l[i] > h[i - 2] and (l[i] - h[i - 2]) > a * p["fvg_atr"]:
                rbf = True
            if h[i] < l[i - 2] and (l[i - 2] - h[i]) > a * p["fvg_atr"]:
                rbe = True
        if bias == -1:
            rbf = False
        if bias == 1:
            rbe = False
        disp = a is not None and abs(c[i] - o[i]) > a * p["ob_disp_atr"]
        if bull_bos and disp and c[i - 1] < o[i - 1]:
            ob_hi, ob_lo, ob_bias = h[i - 1], l[i - 1], 1
        if bear_bos and disp and c[i - 1] > o[i - 1]:
            ob_hi, ob_lo, ob_bias = h[i - 1], l[i - 1], -1
        in_bull_ob = ob_bias == 1 and ob_lo <= c[i] <= ob_hi
        in_bear_ob = ob_bias == -1 and ob_lo <= c[i] <= ob_hi
        if pl_sd[i] is not None and a is not None:
            d_top, d_bot = pl_sd[i] + a * p["zone_atr"], pl_sd[i] - a * p["zone_atr"]
        if ph_sd[i] is not None and a is not None:
            s_top, s_bot = ph_sd[i] + a * p["zone_atr"], ph_sd[i] - a * p["zone_atr"]
        in_demand = d_bot is not None and d_bot <= c[i] <= d_top
        in_supply = s_top is not None and s_bot <= c[i] <= s_top
        tol = p["sr_tol_pct"] / 100
        near_sup = lsl is not None and abs(c[i] - lsl) / c[i] < tol
        near_res = lsh is not None and abs(c[i] - lsh) / c[i] < tol
        r, hs = rsi[i], hist[i]
        rsi_bull = r is not None and 50 < r < p["rsi_ob"]
        rsi_bear = r is not None and p["rsi_os"] < r < 50
        macd_bull = hs is not None and i > 0 and hist[i - 1] is not None and hs > 0 and hs > hist[i - 1]
        macd_bear = hs is not None and i > 0 and hist[i - 1] is not None and hs < 0 and hs < hist[i - 1]
        vol_conf = vol_ma[i] is not None and v[i] > vol_ma[i] * p["vol_mult"]
        contracting = width[i] is not None and width_avg[i] is not None and width[i] < width_avg[i] * 0.85
        accum = contracting and c[i] < mid[i] and vol_conf
        distr = contracting and c[i] > mid[i] and vol_conf
        t_bull = ef[i] is not None and es[i] is not None and c[i] > ef[i] > es[i]
        t_bear = ef[i] is not None and es[i] is not None and c[i] < ef[i] < es[i]
        bull = sum((t_bull, bias == 1, rbf, in_bull_ob, in_demand, near_sup, rsi_bull, macd_bull, vol_conf or accum))
        bear = sum((t_bear, bias == -1, rbe, in_bear_ob, in_supply, near_res, rsi_bear, macd_bear, vol_conf or distr))
        raw_buy = bull >= p["buy_threshold"] and bias == 1 and bull > bear
        raw_sell = bear >= p["sell_threshold"] and bias == -1 and bear > bull
        if bull_bos:
            buy_fired = False
        if bear_bos:
            sell_fired = False
        buy = raw_buy and not buy_fired
        sell = raw_sell and not sell_fired
        if buy:
            buy_fired = True
        if sell:
            sell_fired = True
        row = dict(swing_high=lsh, swing_low=lsl, bull_bos=bull_bos, bear_bos=bear_bos, bias=bias, bull_fvg=rbf,
                   bear_fvg=rbe, in_bull_ob=in_bull_ob, in_bear_ob=in_bear_ob, in_demand=in_demand, in_supply=in_supply,
                   near_support=near_sup, near_resistance=near_res, accumulation=accum, distribution=distr,
                   vol_confirm=vol_conf, bull_score=bull, bear_score=bear, buy=buy, sell=sell, demand_top=d_top,
                   demand_bot=d_bot, supply_top=s_top, supply_bot=s_bot, ob_high=ob_hi, ob_low=ob_lo, ob_bias=ob_bias,
                   trend_bull=t_bull, trend_bear=t_bear)
        for k, val in row.items():
            S[k][i] = val
    return S
