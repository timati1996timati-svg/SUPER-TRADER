---
name: supertrader
description: SuperTrader bilan bozor tahlili - agentlar firmasi reytingi (analyze), signal, backtest, strategiyalar reytingi, Monte-Karlo "vaqt mashinasi", pozitsiya hajmi va qog'oz savdo. Foydalanuvchi aksiya yoki kripto (BTCUSDT, AAPL ...) bo'yicha tahlil, signal, backtest, risk yoki savdo so'raganda ishlating.
---

# SuperTrader

Loyiha ildizidan `python3 -m supertrader <buyruq>` ni ishga tushiring (faqat standart kutubxona).

1. Tahlil: `python3 -m supertrader analyze SYMBOL` - 6 tahlilchi, buqa/ayiq bahsi, 5 darajali reyting, reja, risk jamoasi, hajm.
   `--save` jurnalga yozadi, `--report f.html` hisobot, `--llm` Claude bahsi (anthropic paketi va kalit kerak).
2. Ishonchlilik: `python3 -m supertrader calibrate SYMBOL` - reyting shu aktivda tarixda ishlaganmi.
3. Signal: `python3 -m supertrader signal SYMBOL` - har bir strategiya uchun yo'nalish, stop, maqsad, hajm, PASS/BLOCK.
4. Tekshirish: `python3 -m supertrader backtest SYMBOL --report r.html` va `leaderboard A B C`.
5. Reja simulyatsiyasi: `python3 -m supertrader timemachine SYMBOL --entry E --stop S --target T`.
6. Hajm: `python3 -m supertrader size --entry E --stop S --target T --account N --max-loss L`.
7. Qog'oz savdo: `python3 -m supertrader paper buy SYMBOL --auto` (tasdiq matnini foydalanuvchi o'zi yozadi).

Qoidalar:
- Hech qachon foydalanuvchining aniq roziligisiz buyruq yubormang; `--yes` faqat foydalanuvchi so'rasa.
- `binance ... --mainnet` faqat foydalanuvchi aniq haqiqiy pul bilan savdo so'rasa.
- Reytingni ko'rsatganda `calibrate` natijasini ham ayting; reyting ishlamagan aktivda buni yashirmang.
- Natijalarni raqamlar bilan, halol ko'rsating (zarar va tushishni yashirmang). Bu moliyaviy maslahat emas.
