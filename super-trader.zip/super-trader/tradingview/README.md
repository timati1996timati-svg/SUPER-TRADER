# SuperTrader Pro - TradingView indikatori

Ikki fayl bor:

| Fayl | Nima uchun |
| --- | --- |
| `SuperTrader_Pro.pine` | **Indikator**: reyting, signallar, panel, ogohlantirishlar |
| `SuperTrader_Pro_Strategy.pine` | **Strategiya**: xuddi shu qoidalar bilan TradingView Strategy Tester'da backtest |

Ikkala skript ham Python'dagi `supertrader` bilan **bir xil qoidalarni** ishlatadi: agentlar
firmasi balli (`supertrader/agents/firm.py`) va strategiyalar (`supertrader/strategies/`).
Shuning uchun `supertrader analyze BTCUSDT` va TradingView paneli bir xil reytingni ko'rsatadi.
Faqat tarixning boshida kichik farq bo'lishi mumkin, chunki EMA birinchi qiymatni boshqacha
hisoblaydi.

## O'rnatish (2 daqiqa)

1. TradingView'da istalgan grafikni oching.
2. Pastdagi **Pine Editor** tugmasini bosing.
3. `SuperTrader_Pro.pine` faylining butun matnini nusxalab, muharrirga qo'ying (eski matnni o'chiring).
4. **Save**, keyin **Add to chart**.
5. Strategiya uchun ham xuddi shunday: `SuperTrader_Pro_Strategy.pine` → **Add to chart** →
   pastda **Strategy Tester** yorlig'ida natijalar chiqadi.

## Grafikda nima ko'rinadi

* **Panel (o'ng yuqori)**: REYTING (SOTIB OL / KO'PAYTIR / KUT / KAMAYTIR / SOT), ball (-100..+100),
  bozor rejimi (ADX), 6 tahlilchining har birining balli, risk jamoasi (A/N/E), reja (kirish, SL, TP),
  pozitsiya hajmi (hisob hajmi va risk % bo'yicha), hozirgi pozitsiya va trailing stop.
* **BUY / SHORT / CHIQISH** belgilari: firma signallari. Belgi ustiga sichqonchani olib borsangiz,
  sababi ko'rinadi: har bir tahlilchi balli, stop, maqsad, hajm.
* **Kichik belgilar**: ● Bollinger, ▲ Donchian, ◆ EMA kesishuvi, ■ ORB, **K** kengash (2 va undan ko'p strategiya rozi).
* **Chiziqlar**: SMA 50 (ko'k), SMA 200 (to'q sariq), trailing stop (qizil), stop/maqsad (punktir).
* Ixtiyoriy: Bollinger, Donchian kanali, fon yoki sham rangi = reyting (sozlamalarda yoqiladi).

## Sozlamalar

| Guruh | Asosiy sozlama | Standart |
| --- | --- | --- |
| Risk | Hisob hajmi, risk %, Stop/Maqsad/Trailing = ATR x | $10 000, 1%, 2 / 3 / 3 |
| Risk | Short (fyuchers) savdoga ruxsat | o'chiq (spot) |
| Firma | Kirish darajasi: 0 = faqat SOTIB OL, 1 = KO'PAYTIR ham | 1 |
| Bollinger | Davr, kenglik, RSI, minimal ishonch balli | 20, 2.0, 14, 50 |
| Donchian | Yorib o'tish, qisqa/uzun trend | 20, 20, 60 |
| Kengash | Minimal ovozlar, oyna | 2, 5 sham |
| ORB | Seans, vaqt zonasi, diapazon daqiqasi | 09:30-16:00 Nyu-York, 15 |

## Ogohlantirishlar (alert)

**Alert yaratish** → Condition: `SuperTrader Pro` → kerakli shart:

* `Firma: BUY`, `Firma: SHORT`, `Firma: CHIQISH`, `Reyting o'zgardi`
* `Kengash: LONG/SHORT`, `Bollinger LONG`, `Donchian LONG`, `EMA LONG`, `ORB LONG`

Har doim **"Once Per Bar Close"** ni tanlang: signal faqat sham yopilganda tasdiqlanadi va
keyin o'zgarmaydi (repaint yo'q).

**Webhook (bot uchun)**: Condition → `Any alert() function call`. Xabar JSON formatida keladi:

```json
{"source":"supertrader","symbol":"BTCUSDT","action":"BUY","rating":"SOTIB OL","score":62,
 "price":64250.5,"stop":62100.2,"target":67475.9,"risk_multiplier":1}
```

## Muhim

* Bu indikator **savdo qilmaydi** va moliyaviy maslahat emas. Avval Strategy Tester'da va qog'oz
  savdoda sinang (`supertrader paper ...`).
* Strategiya kirishni signal shamidan keyingi sham ochilishida bajaradi. Reyting tushganda chiqish
  ham keyingi sham ochilishida bo'ladi. Python backtest esa signal shami yopilishida chiqadi, shuning
  uchun natijalar biroz farq qilishi mumkin.
* Komissiya standart holatda 0.1%, sirpanish 2 tik. Strategiya sozlamalaridan o'z birjangizga moslang.
* Core qismini o'zgartirsangiz, strategiyani qayta yarating: `python3 tradingview/build_strategy.py`.
