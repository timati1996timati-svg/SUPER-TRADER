# O'zgarishlar tarixi

## 2.0.0
- **Agentlar firmasi** (TradingAgents arxitekturasi, qoidalar asosida): 6 tahlilchi, buqa/ayiq bahsi,
  5 darajali reyting, treyder rejasi, risk jamoasi (agressiv/neytral/ehtiyotkor), portfel menejeri.
- Yangi buyruqlar: `analyze` (`--save`, `--llm`, `--report`), `calibrate`, `reflect`.
- Qarorlar jurnali: qaror keyingi birinchi yopilishdan baholanadi.
- Ixtiyoriy Claude bahsi (`anthropic` SDK, `claude-opus-5-5`, strukturalangan JSON javob, server-side fallback).
- Yangi strategiya: `firm` (firma reytingi bo'yicha savdo, trailing stop).
- Yangi indikatorlar: ADX/DMI, VWMA, OBV, ROC, percent rank.
- **TradingView**: Pine v6 indikator (panel, signallar, ogohlantirishlar, webhook JSON) va strategiya.
- GitHub uchun tayyorlandi: Apache-2.0, NOTICE, CI (Python 3.9-3.13), boshqa loyihalar kodi olib tashlandi.

## 1.0.0
- 5 strategiya, backtest, Monte-Karlo vaqt mashinasi, risk nazorati, qog'oz savdo, Binance, HTML hisobot.
