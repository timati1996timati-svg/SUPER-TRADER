"""Ixtiyoriy: Claude bilan "jonli bahs" (TradingAgents'dagi LLM agentlar kabi).

Qoidalar asosidagi firma raqamlarni beradi; Claude ularni o'qib, buqa va ayiq
tadqiqotchilar, uchta risk tahlilchisi va portfel menejeri nomidan o'zbek tilida
bahs yozadi va o'z reytingini beradi. Yakuniy raqamli qaror o'zgarmaydi - Claude
fikri alohida ko'rsatiladi, shunda ikkalasini solishtirish mumkin.

O'rnatish:  pip install "supertrader[llm]"   (yoki: pip install anthropic)
Kalit:      export ANTHROPIC_API_KEY=...      (yoki `ant auth login`)
"""

import json

MODEL = "claude-opus-5-5"
RATING_ENUM = ["SOTIB OL", "KO'PAYTIR", "KUT", "KAMAYTIR", "SOT"]

SYSTEM = (
    "Siz savdo firmasining tadqiqot bo'limisiz. Sizga bitta aktiv bo'yicha texnik tahlilchilar "
    "hisobotlari (raqamlar va dalillar) beriladi. Faqat berilgan ma'lumotga tayaning: raqam o'ylab "
    "topmang, yangilik yoki fundamental ma'lumot berilmagan bo'lsa, bu haqda taxmin qilmang va "
    "buni cheklov sifatida ayting. Buqa va ayiq tadqiqotchilar bir-birining eng kuchli dalilini "
    "rad etishga harakat qiladi. Keyin agressiv, neytral va ehtiyotkor risk tahlilchilari treyder "
    "rejasini baholaydi. Oxirida portfel menejeri 5 darajali reyting beradi. Ziddiyatli dalillar "
    "o'zi KUT uchun sabab emas: kuchliroq tomonni tanlang; KUT faqat dalillar haqiqatan teng "
    "yoki juda kam bo'lsa. Barcha matnlarni o'zbek tilida, oddiy va tushunarli yozing. "
    "Bu moliyaviy maslahat emas - tadqiqot."
)

SCHEMA = {
    "type": "object",
    "properties": {
        "bull_case": {"type": "string", "description": "Buqa tadqiqotchining asosiy dalili (3-5 jumla)"},
        "bear_case": {"type": "string", "description": "Ayiq tadqiqotchining asosiy dalili (3-5 jumla)"},
        "debate_winner": {"type": "string", "enum": ["buqa", "ayiq", "teng"]},
        "aggressive_view": {"type": "string"},
        "neutral_view": {"type": "string"},
        "conservative_view": {"type": "string"},
        "rating": {"type": "string", "enum": RATING_ENUM},
        "confidence": {"type": "integer", "description": "0-100"},
        "summary": {"type": "string", "description": "Portfel menejeri xulosasi, 2-4 jumla"},
        "key_risks": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["bull_case", "bear_case", "debate_winner", "aggressive_view", "neutral_view",
                 "conservative_view", "rating", "confidence", "summary", "key_risks"],
    "additionalProperties": False,
}


class LLMError(Exception):
    pass


def evidence(decision) -> dict:
    d = decision.to_dict()
    return dict(
        symbol=d["symbol"], close=d["close"], regime=d["regime"], rule_score=d["score"], rule_rating=d["rating"],
        analysts=[dict(name=r["analyst"], score=r["score"], points=[p["text"] for p in r["points"]],
                       facts={k: (round(v, 4) if isinstance(v, float) else v) for k, v in r["facts"].items()})
                  for r in d["reports"]],
        trader_plan=d["plan"], risk_team=d["risk_views"], monte_carlo=d.get("odds"),
    )


def debate(decision, model: str = MODEL, effort: str = "medium") -> dict:
    try:
        import anthropic
    except ImportError:
        raise LLMError("anthropic paketi o'rnatilmagan: pip install anthropic")
    client = anthropic.Anthropic()
    prompt = ("Quyidagi JSON - firmaning tahlilchilari hisoboti. Bahsni o'tkazing va yakuniy reyting bering.\n\n"
              + json.dumps(evidence(decision), ensure_ascii=False, indent=1, default=str))
    try:
        # fallbacks="default": xavfsizlik klassifikatori rad etsa, server so'rovni tavsiya etilgan modelda qayta bajaradi
        resp = client.beta.messages.create(
            model=model,
            max_tokens=16000,
            betas=["server-side-fallback-2026-07-01"],
            fallbacks="default",
            system=SYSTEM,
            output_config={"effort": effort, "format": {"type": "json_schema", "schema": SCHEMA}},
            messages=[{"role": "user", "content": prompt}],
        )
    except anthropic.AuthenticationError:
        raise LLMError("API kaliti noto'g'ri yoki yo'q (ANTHROPIC_API_KEY yoki `ant auth login`)")
    except anthropic.RateLimitError:
        raise LLMError("so'rovlar chegarasi - birozdan keyin qayta urinib ko'ring")
    except anthropic.APIStatusError as e:
        raise LLMError(f"Claude API xatosi {e.status_code}: {e.message}")
    except anthropic.APIConnectionError:
        raise LLMError("Claude API ga ulanib bo'lmadi (internetni tekshiring)")
    if resp.stop_reason == "refusal":
        raise LLMError("Claude bu so'rovga javob bermadi (refusal)")
    if resp.stop_reason == "max_tokens":
        raise LLMError("javob kesildi (max_tokens)")
    text = next((b.text for b in resp.content if b.type == "text"), "")
    try:
        out = json.loads(text)
    except json.JSONDecodeError:
        raise LLMError("Claude javobi JSON emas")
    out["model"] = resp.model
    return out
