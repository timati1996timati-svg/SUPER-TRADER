"""Qarorlar jurnali va xulosa (TradingAgents memory log + reflection g'oyasi).

Har bir ``analyze --save`` qarori JSONL faylga yoziladi (faqat qo'shiladi, o'chirilmaydi).
``reflect`` keyinroq har bir qarorni haqiqiy narx bilan baholaydi: kirish = qaror shamidan
keyingi BIRINCHI yopilish, chiqish = undan ``horizon`` sham keyin. Yo'nalish to'g'ri
chiqqan qarorlar ulushi reyting bo'yicha ko'rsatiladi - firma o'z xatolaridan o'rganadi.
"""

import datetime as dt
import json
import os
from typing import Dict, List

from ..data import Bar

DEFAULT_LOG = os.path.join("trader_data", "decisions.jsonl")
DIRECTION = {"SOTIB OL": 1, "KO'PAYTIR": 1, "KUT": 0, "KAMAYTIR": -1, "SOT": -1}


def store(decision, path: str = DEFAULT_LOG) -> bool:
    """Bir xil belgi + sham uchun ikkinchi marta yozmaydi (takroriy hisobni oldini oladi)."""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    for e in load(path):
        if e["symbol"] == decision.symbol and e["time"] == decision.time:
            return False
    row = dict(symbol=decision.symbol, time=decision.time,
               date=dt.datetime.fromtimestamp(decision.time, dt.timezone.utc).strftime("%Y-%m-%d %H:%M"),
               rating=decision.rating, score=decision.score, close=decision.close, action=decision.plan.action,
               stop=decision.plan.stop, target=decision.plan.target,
               saved=dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"))
    with open(path, "a") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")
    return True


def load(path: str = DEFAULT_LOG) -> List[dict]:
    if not os.path.exists(path):
        return []
    with open(path) as f:
        return [json.loads(line) for line in f if line.strip()]


def settle(entry: dict, bars: List[Bar], horizon: int = 10):
    idx = next((k for k, b in enumerate(bars) if b.t > entry["time"]), None)
    if idx is None or idx + horizon >= len(bars):
        return None  # hali erta
    e, x = bars[idx].c, bars[idx + horizon].c
    ret = (x / e - 1) * 100
    d = DIRECTION.get(entry["rating"], 0)
    hit = None if d == 0 else (ret * d > 0)
    return dict(entry_close=e, exit_close=x, return_pct=round(ret, 3), hit=hit)


def reflect(entries: List[dict], bars_by_symbol: Dict[str, List[Bar]], horizon: int = 10) -> dict:
    rows, by_rating = [], {}
    for e in entries:
        bars = bars_by_symbol.get(e["symbol"])
        if not bars:
            continue
        s = settle(e, bars, horizon)
        rows.append(dict(e, outcome=s))
        if s is None:
            continue
        g = by_rating.setdefault(e["rating"], dict(n=0, hits=0, judged=0, ret=0.0))
        g["n"] += 1
        g["ret"] += s["return_pct"]
        if s["hit"] is not None:
            g["judged"] += 1
            g["hits"] += int(s["hit"])
    for g in by_rating.values():
        g["avg_return"] = round(g["ret"] / g["n"], 3) if g["n"] else 0.0
        g["hit_rate"] = round(g["hits"] / g["judged"] * 100, 1) if g["judged"] else None
        del g["ret"]
    return dict(rows=rows, by_rating=by_rating)
