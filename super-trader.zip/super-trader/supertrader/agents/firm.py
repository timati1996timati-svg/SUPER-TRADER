"""Agentlar firmasi - TradingAgents (Tauric Research) arxitekturasi, qoidalar asosida.

TradingAgents'da LLM agentlar haqiqiy savdo firmasi kabi ishlaydi:
  tahlilchilar -> buqa/ayiq tadqiqotchilar bahsi -> tadqiqot menejeri (5 darajali reyting)
  -> treyder (aniq reja) -> risk jamoasi (agressiv / neytral / ehtiyotkor) -> portfel menejeri.

Bu yerda xuddi shu oqim, lekin har bir agent shaffof, takrorlanadigan qoidalar bilan
ishlaydi: API kaliti shart emas, bir xil ma'lumot -> bir xil qaror, va har bir qaror
tarixda halol sinaladi (faqat o'sha kungacha bo'lgan shamlar ishlatiladi).
Ixtiyoriy: ``agents.llm`` Claude yordamida bahsni so'z bilan yozadi.

Ball shkalasi va qoidalar ``tradingview/SuperTrader_Pro.pine`` bilan bir xil.
"""

from dataclasses import asdict, dataclass, field
from typing import Dict, List, Optional

from .. import indicators as ta
from ..data import Bar
from ..risk import RiskConfig, size_position

# 5 darajali reyting (TradingAgents: Buy / Overweight / Hold / Underweight / Sell)
RATINGS = ("SOTIB OL", "KO'PAYTIR", "KUT", "KAMAYTIR", "SOT")
RATING_EN = {"SOTIB OL": "Buy", "KO'PAYTIR": "Overweight", "KUT": "Hold", "KAMAYTIR": "Underweight", "SOT": "Sell"}
BUY_T, OVER_T = 40, 15   # chegaralar: >=40 sotib ol, >=15 ko'paytir, >-15 kut, >-40 kamaytir, aks holda sot


def rating_of(score: float) -> str:
    if score >= BUY_T:
        return RATINGS[0]
    if score >= OVER_T:
        return RATINGS[1]
    if score > -OVER_T:
        return RATINGS[2]
    if score > -BUY_T:
        return RATINGS[3]
    return RATINGS[4]


@dataclass
class Point:
    text: str
    weight: float          # + buqa, - ayiq


@dataclass
class Report:
    analyst: str
    score: float
    points: List[Point] = field(default_factory=list)
    facts: Dict[str, float] = field(default_factory=dict)

    def add(self, cond: bool, w: float, yes: str, no: Optional[str] = None):
        if cond:
            self.points.append(Point(yes, w))
            self.score += w
        elif no is not None:
            self.points.append(Point(no, -w))
            self.score -= w


@dataclass
class Plan:
    action: str               # BUY / SELL / HOLD
    entry: float
    stop: Optional[float]
    target: Optional[float]
    reward_r: Optional[float]


@dataclass
class RiskView:
    who: str
    multiplier: float         # risk_pct ga ko'paytiruvchi (0 = veto)
    reason: str


@dataclass
class Decision:
    symbol: str
    time: int
    close: float
    score: float
    rating: str
    reports: List[Report]
    bull: List[Point]
    bear: List[Point]
    regime: str
    plan: Plan
    risk_views: List[RiskView]
    final_multiplier: float
    qty: float = 0.0
    max_loss: float = 0.0
    notes: List[str] = field(default_factory=list)
    odds: Optional[dict] = None
    llm: Optional[dict] = None

    @property
    def rating_en(self):
        return RATING_EN[self.rating]

    def to_dict(self):
        d = asdict(self)
        d["rating_en"] = self.rating_en
        return d


class Features:
    """Barcha indikatorlar bir marta hisoblanadi; agentlar istalgan i-shamni o'qiydi (oldinga qaramaydi)."""

    def __init__(self, bars: List[Bar]):
        self.bars = bars
        c = [b.c for b in bars]
        h = [b.h for b in bars]
        l = [b.l for b in bars]
        v = [b.v for b in bars]
        self.c, self.h, self.l, self.v = c, h, l, v
        self.sma20, self.sma50, self.sma200 = ta.sma(c, 20), ta.sma(c, 50), ta.sma(c, 200)
        self.ema12, self.ema26 = ta.ema(c, 12), ta.ema(c, 26)
        self.macd, self.macd_sig, self.macd_hist = ta.macd(c)
        self.rsi = ta.rsi(c, 14)
        self.bb_up, self.bb_mid, self.bb_lo = ta.bollinger(c, 20, 2.0)
        self.atr = ta.atr(h, l, c, 14)
        self.atr_pct = [a / x * 100 if a is not None and x else None for a, x in zip(self.atr, c)]
        self.atr_rank = ta.percent_rank(self.atr_pct, 100)
        self.vwma = ta.vwma(c, v, 20)
        self.obv = ta.obv(c, v)
        self.obv_ema = ta.ema(self.obv, 20)
        self.vol_ratio = ta.volume_ratio(v, 20)
        self.roc = ta.roc(c, 20)
        self.pdi, self.mdi, self.adx = ta.dmi(h, l, c, 14, 14)
        self.has_volume = sum(1 for x in v[-50:] if x > 0) > 25
        # strategiya agentlari (SuperTrader strategiyalari)
        from ..strategies import BollingerMACD, DonchianTrend, EmaCross
        self.strats = [BollingerMACD(allow_short=True), DonchianTrend(allow_short=True), EmaCross(allow_short=True)]
        for s in self.strats:
            s.prepare(bars)
        self._sig_cache: Dict[int, list] = {}

    def strategy_signals(self, i: int):
        if i not in self._sig_cache:
            out = []
            for s in self.strats:
                sig = s.entry(i) if i >= s.warmup() else None
                out.append((s.name, sig))
            self._sig_cache[i] = out
        return self._sig_cache[i]


def _ok(*xs):
    return all(x is not None for x in xs)


# ------------------------------------------------------------------ tahlilchilar
def trend_analyst(f: Features, i: int) -> Report:
    r = Report("Trend tahlilchisi", 0.0)
    c = f.c[i]
    if f.sma200[i] is not None:
        r.add(c > f.sma200[i], 20, "narx SMA200 dan yuqori (uzoq trend yuqoriga)", "narx SMA200 dan past (uzoq trend pastga)")
    if _ok(f.sma50[i], f.sma200[i]):
        r.add(f.sma50[i] > f.sma200[i], 15, "SMA50 > SMA200 (oltin kesishuv zonasi)", "SMA50 < SMA200 (o'lim kesishuvi zonasi)")
    if f.sma50[i] is not None:
        r.add(c > f.sma50[i], 10, "narx SMA50 dan yuqori", "narx SMA50 dan past")
    if _ok(f.ema12[i], f.ema26[i]):
        r.add(f.ema12[i] > f.ema26[i], 10, "EMA12 > EMA26 (qisqa trend yuqoriga)", "EMA12 < EMA26 (qisqa trend pastga)")
    r.facts = dict(sma50=f.sma50[i], sma200=f.sma200[i])
    return r


def momentum_analyst(f: Features, i: int) -> Report:
    r = Report("Momentum tahlilchisi", 0.0)
    h, rsi = f.macd_hist[i], f.rsi[i]
    if h is not None:
        r.add(h > 0, 10, "MACD gistogrammasi ijobiy", "MACD gistogrammasi manfiy")
        hs = [f.macd_hist[k] for k in range(max(0, i - 3), i + 1)]
        if None not in hs:
            if any(hs[k - 1] <= 0 < hs[k] for k in range(1, len(hs))):
                r.add(True, 10, "MACD yaqinda yuqoriga kesdi")
            elif any(hs[k - 1] >= 0 > hs[k] for k in range(1, len(hs))):
                r.add(True, -10, "MACD yaqinda pastga kesdi")
    if rsi is not None:
        if rsi > 70:
            r.add(True, -10, f"RSI {rsi:.0f} - haddan tashqari sotib olingan")
        elif rsi < 30:
            r.add(True, 10, f"RSI {rsi:.0f} - haddan tashqari sotilgan (qaytish ehtimoli)")
        elif rsi >= 50:
            r.add(True, 10, f"RSI {rsi:.0f} - buqalar ustun")
        else:
            r.add(True, -10, f"RSI {rsi:.0f} - ayiqlar ustun")
    if f.roc[i] is not None:
        r.add(f.roc[i] > 0, 5, f"20 shamlik o'zgarish {f.roc[i]:+.1f}%", f"20 shamlik o'zgarish {f.roc[i]:+.1f}%")
    r.facts = dict(rsi=rsi, macd_hist=h, roc20=f.roc[i])
    return r


def volatility_analyst(f: Features, i: int) -> Report:
    r = Report("Volatillik tahlilchisi", 0.0)
    up, lo, c = f.bb_up[i], f.bb_lo[i], f.c[i]
    if _ok(up, lo) and up > lo:
        pb = (c - lo) / (up - lo)
        if pb < 0:
            r.add(True, 5, f"narx pastki Bollinger'dan tashqarida (%B {pb:.2f}) - cho'zilgan")
        elif pb > 1:
            r.add(True, -5, f"narx yuqori Bollinger'dan tashqarida (%B {pb:.2f}) - cho'zilgan")
        r.facts["pct_b"] = pb
    if f.atr_rank[i] is not None:
        r.facts["atr_rank"] = f.atr_rank[i]
        if f.atr_rank[i] >= 90:
            r.points.append(Point(f"volatillik juda yuqori (ATR so'nggi 100 shamning {f.atr_rank[i]:.0f}-persentilida)", 0))
    r.facts["atr"] = f.atr[i]
    r.facts["atr_pct"] = f.atr_pct[i]
    return r


def volume_analyst(f: Features, i: int) -> Report:
    r = Report("Hajm tahlilchisi", 0.0)
    if not f.has_volume:
        r.points.append(Point("hajm ma'lumoti yo'q - baholanmadi", 0))
        return r
    if f.vwma[i] is not None:
        r.add(f.c[i] > f.vwma[i], 5, "narx VWMA20 dan yuqori (hajm bilan tasdiqlangan)", "narx VWMA20 dan past")
    if f.obv_ema[i] is not None:
        r.add(f.obv[i] > f.obv_ema[i], 5, "OBV o'z o'rtachasidan yuqori (pul kirmoqda)", "OBV o'z o'rtachasidan past (pul chiqmoqda)")
    vr = f.vol_ratio[i]
    if vr is not None and vr > 1.5 and i > 0:
        up = f.c[i] > f.c[i - 1]
        word = "o'sish" if up else "tushish"
        r.add(True, 5 if up else -5, f"hajm {vr:.1f}x o'rtachadan yuqori - {word} shamida")
    r.facts["vol_ratio"] = vr
    return r


def regime_analyst(f: Features, i: int) -> Report:
    r = Report("Bozor rejimi tahlilchisi", 0.0)
    adx, p, m = f.adx[i], f.pdi[i], f.mdi[i]
    if _ok(adx, p, m):
        if adx >= 20:
            r.add(p > m, 10, f"ADX {adx:.0f}: trend bor, +DI ustun", f"ADX {adx:.0f}: trend bor, -DI ustun")
        else:
            r.points.append(Point(f"ADX {adx:.0f}: flet (yon harakat) - yorib o'tishlar ishonchsiz", 0))
        r.facts = dict(adx=adx, plus_di=p, minus_di=m)
    return r


def strategy_analyst(f: Features, i: int, lookback: int = 3) -> Report:
    r = Report("Strategiyalar kengashi", 0.0)
    seen = {}
    for k in range(max(0, i - lookback + 1), i + 1):
        for name, sig in f.strategy_signals(k):
            if sig is not None:
                seen[name] = sig
    for name, sig in seen.items():
        w = 15 if sig.side == "LONG" else -15
        r.add(True, w, f"{name}: {sig.side} - {sig.reason}")
    return r


ANALYSTS = (trend_analyst, momentum_analyst, volatility_analyst, volume_analyst, regime_analyst, strategy_analyst)


def regime_of(f: Features, i: int) -> str:
    adx = f.adx[i]
    if adx is None:
        return "noma'lum"
    if adx >= 25:
        return "kuchli trend"
    if adx >= 20:
        return "trend"
    return "flet"


def score_at(f: Features, i: int) -> float:
    s = sum(a(f, i).score for a in ANALYSTS)
    return max(-100.0, min(100.0, s))


# ------------------------------------------------------------------ firma
def decide(f: Features, i: int, symbol: str = "", cfg: Optional[RiskConfig] = None,
           allow_short: bool = False, stop_atr: float = 2.0, target_atr: float = 3.0) -> Decision:
    cfg = cfg or RiskConfig()
    reports = [a(f, i) for a in ANALYSTS]
    score = max(-100.0, min(100.0, sum(r.score for r in reports)))
    rating = rating_of(score)
    pts = [p for r in reports for p in r.points]
    bull = sorted([p for p in pts if p.weight > 0], key=lambda p: -p.weight)
    bear = sorted([p for p in pts if p.weight < 0], key=lambda p: p.weight)
    regime = regime_of(f, i)
    c, atr = f.c[i], f.atr[i]

    # Treyder: reytingni aniq rejaga aylantiradi
    if rating in RATINGS[:2] and atr:
        plan = Plan("BUY", c, c - stop_atr * atr, c + target_atr * atr, target_atr / stop_atr)
    elif rating in RATINGS[3:] and atr and allow_short:
        plan = Plan("SELL", c, c + stop_atr * atr, c - target_atr * atr, target_atr / stop_atr)
    elif rating in RATINGS[3:]:
        plan = Plan("SELL", c, None, None, None)  # spot: pozitsiyani yopish / kirmaslik
    else:
        plan = Plan("HOLD", c, None, None, None)

    # Risk jamoasi
    rank = f.atr_rank[i] if f.atr_rank[i] is not None else 50.0
    adx = f.adx[i] or 0.0
    strong = rating in (RATINGS[0], RATINGS[4])
    counter_trend = (plan.action == "BUY" and f.sma200[i] is not None and c < f.sma200[i]) or \
                    (plan.action == "SELL" and plan.stop is not None and f.sma200[i] is not None and c > f.sma200[i])
    views = [
        RiskView("Agressiv", 1.5 if strong and adx >= 25 else 1.0,
                 "kuchli signal + kuchli trend: riskni oshirish mumkin" if strong and adx >= 25 else "standart risk"),
        RiskView("Neytral", 0.5 if rank >= 80 else 1.0,
                 f"volatillik yuqori ({rank:.0f}-persentil): yarim risk" if rank >= 80 else "standart risk"),
    ]
    if rank >= 95:
        views.append(RiskView("Ehtiyotkor", 0.0, f"VETO: volatillik ekstremal ({rank:.0f}-persentil)"))
    elif counter_trend:
        views.append(RiskView("Ehtiyotkor", 0.0, "VETO: savdo SMA200 trendiga qarshi"))
    else:
        views.append(RiskView("Ehtiyotkor", 0.5 if not strong else 0.75, "kapitalni himoya qilish: kamaytirilgan risk"))

    # Portfel menejeri: o'rta qiymat; ehtiyotkor veto + neytral kamaytirsa -> 0
    mults = sorted(v.multiplier for v in views)
    final = mults[1]
    notes = []
    if views[2].multiplier == 0 and views[1].multiplier < 1:
        final = 0.0
        notes.append("Ehtiyotkor veto + neytral ogohlantirish: savdo bekor")
    elif views[2].multiplier == 0:
        final = min(final, 0.5)
        notes.append("Ehtiyotkor veto qo'ydi: risk yarimga tushirildi")
    if plan.stop is None:
        final = 0.0
        notes = ["yangi savdo yo'q: " + ("ochiq LONG bo'lsa yopish yoki kamaytirish" if plan.action == "SELL" else "aniq ustunlik paydo bo'lishini kutish")]
    d = Decision(symbol, f.bars[i].t, c, round(score, 1), rating, reports, bull, bear, regime, plan, views, final, notes=notes)
    if plan.stop is not None and final > 0:
        rc = RiskConfig(**{**cfg.to_dict(), "risk_pct": cfg.risk_pct * final})
        sz = size_position(rc, c, plan.stop, plan.target)
        d.qty, d.max_loss = sz.qty, round(sz.max_loss, 2)
        d.notes += sz.notes
    return d


def analyze(bars: List[Bar], symbol: str = "", cfg: Optional[RiskConfig] = None, allow_short: bool = False,
            odds: bool = True, seed: int = 19) -> Decision:
    f = Features(bars)
    d = decide(f, len(bars) - 1, symbol, cfg, allow_short)
    if odds and d.plan.stop is not None and d.plan.target is not None:
        from ..montecarlo import replay_plan
        side = "LONG" if d.plan.action == "BUY" else "SHORT"
        try:
            d.odds = replay_plan(bars, side, d.plan.entry, d.plan.stop, d.plan.target, horizon=20, replays=5000, seed=seed)
        except ValueError:
            d.odds = None
    return d


def calibrate(bars: List[Bar], horizon: int = 10, start: int = 200) -> Dict[str, dict]:
    """Har bir tarixiy shamda reyting -> keyingi ``horizon`` shamdagi daromad (birinchi yopilishdan).

    TradingAgents qarorlarni qaror sanasidan keyingi birinchi yopilish narxidan baholaydi;
    bu yerda ham kirish = (i+1) yopilishi, chiqish = (i+1+horizon) yopilishi.
    """
    f = Features(bars)
    out = {r: [] for r in RATINGS}
    for i in range(start, len(bars) - horizon - 1):
        r = rating_of(score_at(f, i))
        e, x = f.c[i + 1], f.c[i + 1 + horizon]
        out[r].append((x / e - 1) * 100)
    res = {}
    for r, xs in out.items():
        if xs:
            res[r] = dict(n=len(xs), avg=round(sum(xs) / len(xs), 3), win=round(sum(1 for x in xs if x > 0) / len(xs) * 100, 1))
        else:
            res[r] = dict(n=0, avg=0.0, win=0.0)
    return res
