"""Pozitsiya hajmi va risk nazorati.

Manbalar: day-trader-skill/trader-budget (hajm = maks. zarar / bir dona riski),
day-trader-skill/trader-risk (PASS/BLOCK qoidalari), binance-trader
(BollingerStrategy.calculate_position_size - balansning % riski),
ctp-futures-trader/brother2 (kapital * risk / ATR riski).
"""

import math
from dataclasses import asdict, dataclass, field
from typing import List, Optional


@dataclass
class RiskConfig:
    account: float = 10_000.0          # hisob hajmi
    risk_pct: float = 1.0              # bitta savdoda maks. zarar, hisobning %
    max_loss_usd: Optional[float] = None  # yoki aniq summa ($50 kabi) - kichigi olinadi
    max_position_pct: float = 50.0     # bitta pozitsiya hisobning ko'pi bilan %
    daily_loss_limit_pct: float = 3.0  # kunlik zarar chegarasi
    max_trades_per_day: int = 5
    min_reward_risk: float = 1.0       # maqsadli savdolar uchun minimal R:R
    fractional: bool = False           # kripto uchun True (0.0123 BTC), aksiya uchun butun dona
    lot_step: float = 0.0001           # fractional bo'lganda yaxlitlash qadami
    fee_pct: float = 0.1               # bir tomonlama komissiya %
    slippage_pct: float = 0.02         # sirpanish %

    def to_dict(self):
        return asdict(self)


@dataclass
class Sizing:
    qty: float
    entry: float
    stop: float
    target: Optional[float]
    risk_per_unit: float
    max_loss: float
    notional: float
    reward_risk: Optional[float]
    notes: List[str] = field(default_factory=list)


def _floor(x, step):
    return math.floor(x / step + 1e-9) * step


def risk_budget(cfg: RiskConfig, equity: Optional[float] = None) -> float:
    eq = cfg.account if equity is None else equity
    b = eq * cfg.risk_pct / 100.0
    if cfg.max_loss_usd:
        b = min(b, cfg.max_loss_usd)
    return b


def size_position(cfg: RiskConfig, entry: float, stop: float, target: Optional[float] = None,
                  equity: Optional[float] = None, cash: Optional[float] = None) -> Sizing:
    notes = []
    rpu = abs(entry - stop)
    if rpu <= 0:
        return Sizing(0, entry, stop, target, 0, 0, 0, None, ["stop kirish narxiga teng - hajm 0"])
    eq = cfg.account if equity is None else equity
    budget = risk_budget(cfg, eq)
    qty = budget / rpu
    cap = eq * cfg.max_position_pct / 100.0
    if cash is not None:
        cap = min(cap, cash)
    if qty * entry > cap:
        qty = cap / entry
        notes.append(f"pozitsiya {cfg.max_position_pct:.0f}% chegarasigacha kesildi")
    qty = _floor(qty, cfg.lot_step) if cfg.fractional else math.floor(qty)
    if qty <= 0:
        notes.append("risk byudjeti 1 donaga ham yetmaydi")
        qty = 0
    rr = None
    if target is not None:
        rr = abs(target - entry) / rpu
    return Sizing(qty, entry, stop, target, rpu, qty * rpu, qty * entry, rr, notes)


@dataclass
class RiskVerdict:
    ok: bool
    reasons: List[str]
    checks: List[str]

    @property
    def label(self):
        return "PASS ✅" if self.ok else "BLOCK ⛔"


def check_trade(cfg: RiskConfig, s: Sizing, today_pnl: float = 0.0, trades_today: int = 0,
                cash: Optional[float] = None, equity: Optional[float] = None) -> RiskVerdict:
    eq = cfg.account if equity is None else equity
    bad, ok = [], []
    budget = risk_budget(cfg, eq)
    (ok if s.qty > 0 else bad).append(f"hajm: {s.qty:g} dona")
    (ok if s.max_loss <= budget + 0.01 else bad).append(f"maks. zarar ${s.max_loss:,.2f} / chegara ${budget:,.2f}")
    limit = eq * cfg.daily_loss_limit_pct / 100.0
    (ok if -today_pnl + s.max_loss <= limit + 0.01 else bad).append(
        f"kunlik zarar: bugun ${max(-today_pnl, 0):,.2f} + bu savdo ${s.max_loss:,.2f} / chegara ${limit:,.2f}")
    (ok if trades_today < cfg.max_trades_per_day else bad).append(f"bugungi savdolar: {trades_today} / {cfg.max_trades_per_day}")
    if s.reward_risk is not None:
        (ok if s.reward_risk + 1e-9 >= cfg.min_reward_risk else bad).append(f"foyda:risk {s.reward_risk:.2f} / min {cfg.min_reward_risk:.2f}")
    (ok if s.notional <= eq * cfg.max_position_pct / 100 + 0.01 else bad).append(
        f"pozitsiya ${s.notional:,.2f} / maks ${eq * cfg.max_position_pct / 100:,.2f}")
    if cash is not None:
        (ok if s.notional <= cash + 0.01 else bad).append(f"naqd: kerak ${s.notional:,.2f} / bor ${cash:,.2f}")
    return RiskVerdict(not bad, bad, ok)
