"""Backtest dvigateli.

Halol qoidalar:
  * signal i-sham YOPILGANDA hisoblanadi, kirish (i+1)-sham OCHILISHIDA (oldindan ko'rish yo'q)
  * ochilishda narx stopdan o'tib ketgan bo'lsa (gap) savdo bekor qilinadi
  * har bir shamda avval STOP, keyin MAQSAD tekshiriladi (ikkalasiga tegsa - stop, ehtiyotkor
    tanlov, day-trader-skill/timemachine kabi). Gap orqali stop - ochilish narxida.
  * komissiya va sirpanish har ikki tomonda
"""

import datetime as dt
import math
from dataclasses import asdict, dataclass, field
from typing import Dict, List, Optional

from .data import Bar
from .risk import RiskConfig, size_position
from .strategies.base import LONG, Position, Strategy


@dataclass
class Trade:
    side: str
    entry_time: int
    exit_time: int
    entry: float
    exit: float
    qty: float
    pnl: float
    r: float
    reason_in: str
    reason_out: str
    bars: int
    strategy: str = ""

    def to_dict(self):
        d = asdict(self)
        d["entry_time"] = dt.datetime.fromtimestamp(self.entry_time, dt.timezone.utc).strftime("%Y-%m-%d %H:%M")
        d["exit_time"] = dt.datetime.fromtimestamp(self.exit_time, dt.timezone.utc).strftime("%Y-%m-%d %H:%M")
        return d


@dataclass
class Result:
    strategy: str
    symbol: str
    trades: List[Trade]
    equity: List[float]
    times: List[int]
    start_equity: float
    metrics: Dict[str, float] = field(default_factory=dict)
    open_position: Optional[dict] = None


def periods_per_year(bars: List[Bar]) -> float:
    if len(bars) < 2:
        return 252
    step = sorted(bars[i + 1].t - bars[i].t for i in range(min(len(bars) - 1, 200)))[0] or 86400
    if step >= 86400:
        return 252 if _weekdays_only(bars) else 365
    per_day = (6.5 * 3600 / step) if _weekdays_only(bars) else (86400 / step)
    return per_day * (252 if _weekdays_only(bars) else 365)


def _weekdays_only(bars):
    return not any(dt.datetime.fromtimestamp(b.t, dt.timezone.utc).weekday() == 6 for b in bars[:400])


def compute_metrics(res: Result, bars: List[Bar]) -> Dict[str, float]:
    t = res.trades
    eq = res.equity
    wins = [x for x in t if x.pnl > 0]
    losses = [x for x in t if x.pnl <= 0]
    gp = sum(x.pnl for x in wins)
    gl = -sum(x.pnl for x in losses)
    peak, mdd = eq[0] if eq else 0, 0.0
    for v in eq:
        peak = max(peak, v)
        if peak > 0:
            mdd = max(mdd, (peak - v) / peak)
    rets = [(eq[i] / eq[i - 1] - 1) for i in range(1, len(eq)) if eq[i - 1] > 0]
    sharpe = 0.0
    if len(rets) > 2:
        mu = sum(rets) / len(rets)
        sd = math.sqrt(sum((r - mu) ** 2 for r in rets) / (len(rets) - 1))
        sharpe = mu / sd * math.sqrt(periods_per_year(bars)) if sd > 0 else 0.0
    final = eq[-1] if eq else res.start_equity
    bh = (bars[-1].c / bars[0].o - 1) * 100 if bars else 0
    years = max((bars[-1].t - bars[0].t) / (365.25 * 86400), 1e-9) if bars else 1
    cagr = ((final / res.start_equity) ** (1 / years) - 1) * 100 if final > 0 and years > 0.08 else (final / res.start_equity - 1) * 100
    return dict(
        trades=len(t),
        win_rate=round(len(wins) / len(t) * 100, 1) if t else 0.0,
        profit_factor=round(gp / gl, 2) if gl > 0 else (float("inf") if gp > 0 else 0.0),
        total_return_pct=round((final / res.start_equity - 1) * 100, 2),
        cagr_pct=round(cagr, 2),
        max_drawdown_pct=round(mdd * 100, 2),
        sharpe=round(sharpe, 2),
        avg_r=round(sum(x.r for x in t) / len(t), 3) if t else 0.0,
        best_r=round(max((x.r for x in t), default=0), 2),
        worst_r=round(min((x.r for x in t), default=0), 2),
        avg_bars=round(sum(x.bars for x in t) / len(t), 1) if t else 0.0,
        final_equity=round(final, 2),
        buy_hold_pct=round(bh, 2),
    )


def run(strategy: Strategy, bars: List[Bar], cfg: RiskConfig = None, symbol: str = "") -> Result:
    cfg = cfg or RiskConfig()
    strategy.prepare(bars)
    fee = cfg.fee_pct / 100.0
    slip = cfg.slippage_pct / 100.0
    cash = cfg.account
    pos: Optional[Position] = None
    pending = None
    init_stop = None
    trades: List[Trade] = []
    equity, times = [], []
    start = max(strategy.warmup(), 1)

    def close(i, price, why):
        nonlocal cash, pos
        px = price * (1 - slip) if pos.side == LONG else price * (1 + slip)
        if pos.side == LONG:
            gross = (px - pos.entry) * pos.qty
        else:
            gross = (pos.entry - px) * pos.qty
        cost = (pos.entry + px) * pos.qty * fee
        pnl = gross - cost
        cash += pnl
        r = pnl / (pos.risk_per_unit * pos.qty) if pos.risk_per_unit * pos.qty > 0 else 0.0
        trades.append(Trade(pos.side, bars[pos.entry_i].t, bars[i].t, round(pos.entry, 6), round(px, 6), pos.qty,
                            round(pnl, 2), round(r, 3), pos.reason, why, i - pos.entry_i + 1, pos.strategy))
        pos = None

    for i, b in enumerate(bars):
        # 1) kutilayotgan signal bo'yicha kirish (ochilishda)
        if pending is not None and pos is None:
            sig = pending
            pending = None
            px = b.o * (1 + slip) if sig.side == LONG else b.o * (1 - slip)
            gap_through = (sig.side == LONG and px <= sig.stop) or (sig.side != LONG and px >= sig.stop)
            if not gap_through:
                tgt = sig.target
                if tgt is not None and ((sig.side == LONG and tgt <= px) or (sig.side != LONG and tgt >= px)):
                    tgt = None
                sz = size_position(cfg, px, sig.stop, tgt, equity=cash, cash=cash)
                if sz.qty > 0:
                    pos = Position(sig.side, px, sz.qty, sig.stop, tgt, i, sz.risk_per_unit, sig.reason, sig.strategy or strategy.name, b.h, b.l)
                    init_stop = sig.stop
        # 2) ochiq pozitsiyani boshqarish
        if pos is not None:
            pos.highest, pos.lowest = max(pos.highest, b.h), min(pos.lowest, b.l)
            if pos.side == LONG:
                if b.l <= pos.stop:
                    close(i, min(b.o, pos.stop), "stop" if pos.stop == init_stop else "trailing stop")
                elif pos.target is not None and b.h >= pos.target:
                    close(i, max(b.o, pos.target), "maqsad")
            else:
                if b.h >= pos.stop:
                    close(i, max(b.o, pos.stop), "stop" if pos.stop == init_stop else "trailing stop")
                elif pos.target is not None and b.l <= pos.target:
                    close(i, min(b.o, pos.target), "maqsad")
            if pos is not None and i >= start:
                why = strategy.exit(i, pos)
                if why:
                    close(i, b.c, why)
            if pos is not None:
                ns = strategy.trail(i, pos)
                if ns is not None:
                    pos.stop = ns
        # 3) yangi signal
        if pos is None and pending is None and i >= start and i < len(bars) - 1:
            pending = strategy.entry(i)
        # 4) kapital egri chizig'i (ochiq pozitsiya bozor narxida)
        mtm = cash
        if pos is not None:
            mtm += (b.c - pos.entry) * pos.qty if pos.side == LONG else (pos.entry - b.c) * pos.qty
        equity.append(mtm)
        times.append(b.t)

    res = Result(strategy.name, symbol, trades, equity, times, cfg.account)
    if pos is not None:
        res.open_position = dict(side=pos.side, entry=pos.entry, qty=pos.qty, stop=pos.stop, target=pos.target,
                                 since=dt.datetime.fromtimestamp(bars[pos.entry_i].t, dt.timezone.utc).strftime("%Y-%m-%d"))
    res.metrics = compute_metrics(res, bars)
    return res


def score(m: Dict[str, float]) -> float:
    """Reyting bali (AI-Trader leaderboard g'oyasi): daromad, Sharpe va chuqur tushishni muvozanatlaydi."""
    if m["trades"] < 5:
        return -999.0
    pf = min(m["profit_factor"], 5.0)
    return round(m["sharpe"] * 2 + m["total_return_pct"] / 10 - m["max_drawdown_pct"] / 5 + pf, 3)
