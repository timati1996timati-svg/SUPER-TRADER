"""Monte-Karlo: "Vaqt mashinasi" (day-trader-skill/trader-timemachine dan).

1) ``replay_plan`` - reja (kirish/stop/maqsad) ni aksiyaning O'Z shamlaridan
   yig'ilgan ehtimolliklar bilan N marta qayta o'ynaydi. Har bir shamda avval stop
   tekshiriladi. Natija: maqsad / stop / hech biri foizlari va hukm.
2) ``bootstrap_trades`` - backtest savdolarini tasodifiy tartibda qayta tanlab,
   yakuniy kapital va maksimal tushish taqsimotini beradi ("omad" ta'sirini ko'rsatadi).
"""

import random
from typing import Dict, List, Optional

from .data import Bar


def _pct(a: List[float], q: float) -> float:
    s = sorted(a)
    return s[min(len(s) - 1, int(q * len(s)))]


def verdict(target_share: float, r: float) -> str:
    """target / (target + stop) ni breakeven 1/(1+R) bilan solishtiradi."""
    be = 1.0 / (1.0 + r)
    gap = (target_share - be) * 100
    side = "maqsad" if gap > 0 else "stop"
    if abs(gap) < 5:
        return "Tanga tashlashga yaqin (aniq ustunlik yo'q)" if abs(r - 1) < 1e-9 else "Zararsizlik nuqtasiga yaqin"
    if abs(gap) < 15:
        return f"Biroz {side} tomonga og'gan ({gap:+.1f} punkt)"
    return f"Kuchli {side} tomonga ({gap:+.1f} punkt)"


def replay_plan(bars: List[Bar], side: str, entry: float, stop: float, target: float,
                horizon: int = 20, replays: int = 10_000, seed: int = 19, lookback: int = 500) -> Dict:
    hist = bars[-lookback:]
    pool = []
    for i in range(1, len(hist)):
        pc = hist[i - 1].c
        if pc <= 0:
            continue
        b = hist[i]
        pool.append((b.o / pc, b.h / pc, b.l / pc, b.c / pc))
    if len(pool) < 30:
        raise ValueError("Simulyatsiya uchun kamida 30 ta sham kerak")
    long = side.upper() == "LONG"
    risk = abs(entry - stop)
    if risk <= 0:
        raise ValueError("stop kirish narxiga teng bo'lmasligi kerak")
    tr = abs(target - entry) / risk
    rnd = random.Random(seed)
    hit_t = hit_s = 0
    finals, rs, green = [], [], 0
    for _ in range(replays):
        p = entry
        outcome = None
        for _k in range(horizon):
            o, h, l, c = rnd.choice(pool)
            lo, hi, cl = p * l, p * h, p * c
            if long:
                if lo <= stop:
                    outcome = "stop"; break
                if hi >= target:
                    outcome = "target"; break
            else:
                if hi >= stop:
                    outcome = "stop"; break
                if lo <= target:
                    outcome = "target"; break
            p = cl
        if outcome == "target":
            hit_t += 1; rs.append(tr); green += 1; finals.append(target)
        elif outcome == "stop":
            hit_s += 1; rs.append(-1.0); finals.append(stop)
        else:
            r = ((p - entry) if long else (entry - p)) / risk
            rs.append(r); finals.append(p)
            if r > 0:
                green += 1
    n = replays
    hit = hit_t + hit_s
    share = hit_t / hit if hit else 0.0
    return dict(
        replays=n, horizon=horizon, seed=seed, reward_r=round(tr, 2),
        target_pct=round(hit_t / n * 100, 1), stop_pct=round(hit_s / n * 100, 1),
        neither_pct=round((n - hit) / n * 100, 1), green_pct=round(green / n * 100, 1),
        avg_r=round(sum(rs) / n, 3), median_price=round(_pct(finals, 0.5), 4),
        p05=round(_pct(finals, 0.05), 4), p95=round(_pct(finals, 0.95), 4),
        verdict=verdict(share, tr) if hit else "Hech bir tomon urilmadi - gorizontni oshiring",
        note="Ko'pchilik yo'llar hech biriga yetmadi - yakuniy narx hal qiladi" if (n - hit) / n > 0.4 else "",
    )


def bootstrap_trades(pnls: List[float], start_equity: float, runs: int = 5000, seed: int = 19) -> Optional[Dict]:
    if len(pnls) < 3:
        return None
    rnd = random.Random(seed)
    finals, dds = [], []
    for _ in range(runs):
        eq = peak = start_equity
        mdd = 0.0
        for _k in range(len(pnls)):
            eq += rnd.choice(pnls)
            peak = max(peak, eq)
            if peak > 0:
                mdd = max(mdd, (peak - eq) / peak)
        finals.append(eq)
        dds.append(mdd * 100)
    return dict(
        runs=runs, trades=len(pnls),
        median_final=round(_pct(finals, 0.5), 2), p05_final=round(_pct(finals, 0.05), 2), p95_final=round(_pct(finals, 0.95), 2),
        prob_loss_pct=round(sum(1 for f in finals if f < start_equity) / runs * 100, 1),
        median_dd_pct=round(_pct(dds, 0.5), 2), p95_dd_pct=round(_pct(dds, 0.95), 2),
    )
