"""Strategiya interfeysi.

Har bir strategiya ``prepare(bars)`` da indikatorlarni bir marta hisoblaydi,
so'ng backtest dvigateli har bir sham uchun:

* ``entry(i)``      -> ``Signal`` yoki ``None`` (i-sham yopilganda; kirish keyingi sham ochilishida)
* ``exit(i, pos)``  -> chiqish sababi (matn) yoki ``None`` (i-sham yopilish narxida chiqiladi)
* ``trail(i, pos)`` -> yangi stop narxi yoki ``None``
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from ..data import Bar

LONG, SHORT = "LONG", "SHORT"


@dataclass
class Signal:
    side: str                       # LONG yoki SHORT
    stop: float
    target: Optional[float] = None  # None = trend kuzatish, maqsadsiz
    confidence: float = 50.0
    reason: str = ""
    strategy: str = ""
    indicators: Dict[str, float] = field(default_factory=dict)


@dataclass
class Position:
    side: str
    entry: float
    qty: float
    stop: float
    target: Optional[float]
    entry_i: int
    risk_per_unit: float
    reason: str = ""
    strategy: str = ""
    highest: float = 0.0
    lowest: float = 0.0


class Strategy:
    name = "base"
    title = "Asosiy"
    origin = ""
    params: Dict = {}

    def __init__(self, **kw):
        p = dict(self.__class__.params)
        unknown = set(kw) - set(p)
        if unknown:
            raise ValueError(f"{self.name}: noma'lum parametr(lar): {', '.join(sorted(unknown))}")
        p.update(kw)
        self.p = p
        self.bars: List[Bar] = []

    def prepare(self, bars: List[Bar]) -> None:
        self.bars = bars

    def warmup(self) -> int:
        return 1

    def entry(self, i: int) -> Optional[Signal]:
        return None

    def exit(self, i: int, pos: Position) -> Optional[str]:
        return None

    def trail(self, i: int, pos: Position) -> Optional[float]:
        return None

    def describe(self) -> str:
        return f"{self.title} ({self.name}) {self.p}"
