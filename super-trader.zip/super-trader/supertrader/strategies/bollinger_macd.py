"""Bollinger + RSI + Hajm + MACD (binance-trader/app/BollingerStrategy.py dan).

Qoidalar asl nusxadagidek ball tizimi bilan:
  narx pastki chiziqda (+30), RSI < 30 (+25) yoki < 40 (+15),
  hajm > 1.2x (+20) yoki > 1x (+10), %B < 0.1 (+15),
  MACD yuqoriga kesib o'tdi (+25) / ijobiy momentum (+15) / gistogramma manfiy (-10).
  Ball >= ``min_confidence`` bo'lsa LONG. Stop = narx - ATR*2, maqsad = o'rta chiziq.
  Yuqori chiziqqa yetganda yoki o'rta chiziqqa yetganda (``take_profit=middle``) chiqish.
``allow_short=True`` bo'lsa ko'zgu qoidalar bilan SHORT ham ochadi (fyuchers uchun).
"""

from typing import Optional

from .. import indicators as ta
from .base import LONG, SHORT, Position, Signal, Strategy


class BollingerMACD(Strategy):
    name = "bollinger"
    title = "Bollinger+RSI+MACD (qaytish)"
    origin = "binance-trader"
    params = dict(bb_period=20, bb_std=2.0, rsi_period=14, rsi_low=30, rsi_high=70,
                  vol_period=20, vol_threshold=1.2, atr_period=14, stop_atr=2.0,
                  min_bb_width=1.0, max_bb_width=15.0, use_macd=True, min_confidence=50,
                  take_profit="middle", allow_short=False)

    def prepare(self, bars):
        super().prepare(bars)
        p = self.p
        c = [b.c for b in bars]
        self.c = c
        self.up, self.mid, self.lo = ta.bollinger(c, p["bb_period"], p["bb_std"])
        self.rsi = ta.rsi(c, p["rsi_period"])
        self.vr = ta.volume_ratio([b.v for b in bars], p["vol_period"])
        self.atr = ta.atr([b.h for b in bars], [b.l for b in bars], c, p["atr_period"])
        self.ml, self.ms, self.mh = ta.macd(c)

    def warmup(self):
        return max(self.p["bb_period"], 35)

    def _macd_state(self, i):
        if self.mh[i] is None or self.mh[i - 1] is None:
            return "none"
        if self.mh[i - 1] <= 0 < self.mh[i]:
            return "bull_cross"
        if self.mh[i - 1] >= 0 > self.mh[i]:
            return "bear_cross"
        return "bull" if self.mh[i] > 0 else "bear"

    def entry(self, i) -> Optional[Signal]:
        p = self.p
        up, mid, lo, rsi, atr = self.up[i], self.mid[i], self.lo[i], self.rsi[i], self.atr[i]
        if None in (up, mid, lo, rsi, atr) or atr <= 0:
            return None
        price = self.c[i]
        width = (up - lo) / mid * 100
        if not (p["min_bb_width"] <= width <= p["max_bb_width"]):
            return None
        pctb = (price - lo) / (up - lo) if up != lo else 0.5
        vr = self.vr[i] or 1.0
        macd = self._macd_state(i) if p["use_macd"] else "none"
        ind = dict(rsi=round(rsi, 1), bb_width=round(width, 2), pct_b=round(pctb, 3), vol_ratio=round(vr, 2), atr=atr)

        if price <= lo * 1.005:
            conf, why = 30, ["narx pastki BB da"]
            if rsi < p["rsi_low"]:
                conf += 25; why.append(f"RSI haddan past ({rsi:.0f})")
            elif rsi < 40:
                conf += 15; why.append(f"RSI qulay ({rsi:.0f})")
            if vr > p["vol_threshold"]:
                conf += 20; why.append(f"hajm yuqori ({vr:.1f}x)")
            elif vr > 1:
                conf += 10; why.append(f"hajm o'rtachadan yuqori ({vr:.1f}x)")
            if pctb < 0.1:
                conf += 15; why.append("%B < 0.1")
            if macd == "bull_cross":
                conf += 25; why.append("MACD yuqoriga kesdi")
            elif macd == "bull":
                conf += 15; why.append("MACD ijobiy")
            elif p["use_macd"] and self.mh[i] is not None and self.mh[i] < 0:
                conf -= 10; why.append("MACD manfiy (ehtiyot)")
            if conf >= p["min_confidence"]:
                stop = price - atr * p["stop_atr"]
                tgt = mid if p["take_profit"] == "middle" else up
                if tgt <= price:
                    tgt = price + (price - stop)
                return Signal(LONG, stop, tgt, min(conf, 100), "; ".join(why), self.name, ind)

        if p["allow_short"] and price >= up * 0.995:
            conf, why = 30, ["narx yuqori BB da"]
            if rsi > p["rsi_high"]:
                conf += 25; why.append(f"RSI haddan yuqori ({rsi:.0f})")
            elif rsi > 60:
                conf += 15; why.append(f"RSI qulay ({rsi:.0f})")
            if vr > p["vol_threshold"]:
                conf += 20; why.append(f"hajm yuqori ({vr:.1f}x)")
            if pctb > 0.9:
                conf += 15; why.append("%B > 0.9")
            if macd == "bear_cross":
                conf += 25; why.append("MACD pastga kesdi")
            elif macd == "bear":
                conf += 15; why.append("MACD manfiy")
            elif p["use_macd"] and self.mh[i] is not None and self.mh[i] > 0:
                conf -= 10; why.append("MACD ijobiy (ehtiyot)")
            if conf >= p["min_confidence"]:
                stop = price + atr * p["stop_atr"]
                tgt = mid if mid < price else price - (stop - price)
                return Signal(SHORT, stop, tgt, min(conf, 100), "; ".join(why), self.name, ind)
        return None

    def exit(self, i, pos: Position):
        up, lo = self.up[i], self.lo[i]
        if up is None:
            return None
        if pos.side == LONG and self.c[i] >= up * 0.995:
            return "yuqori BB ga yetdi"
        if pos.side == SHORT and self.c[i] <= lo * 1.005:
            return "pastki BB ga yetdi"
        return None
