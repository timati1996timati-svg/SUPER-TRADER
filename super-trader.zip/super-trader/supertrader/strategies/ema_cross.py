"""EMA kesishuvi + RSI filtri - oddiy, tushunarli trend agenti.

Kengashga uchinchi "ovoz" sifatida qo'shildi: Bollinger (qaytish) va Donchian
(yorib o'tish) orasidagi muvozanat. LONG: tez EMA sekin EMA ni yuqoriga kesadi va
RSI 50-70 oralig'ida. Stop = ATR*2, maqsad = ATR*target_atr. Teskari kesishuvda chiqadi.
"""

from .. import indicators as ta
from .base import LONG, SHORT, Signal, Strategy


class EmaCross(Strategy):
    name = "ema_cross"
    title = "EMA kesishuvi + RSI"
    origin = "supertrader"
    params = dict(fast=12, slow=26, rsi_period=14, atr_period=14, stop_atr=2.0, target_atr=4.0, allow_short=False)

    def prepare(self, bars):
        super().prepare(bars)
        c = [b.c for b in bars]
        self.c = c
        self.f = ta.ema(c, self.p["fast"])
        self.s = ta.ema(c, self.p["slow"])
        self.rsi = ta.rsi(c, self.p["rsi_period"])
        self.atr = ta.atr([b.h for b in bars], [b.l for b in bars], c, self.p["atr_period"])

    def warmup(self):
        return self.p["slow"] + 2

    def _cross(self, i):
        f0, s0, f1, s1 = self.f[i - 1], self.s[i - 1], self.f[i], self.s[i]
        if None in (f0, s0, f1, s1):
            return 0
        if f0 <= s0 and f1 > s1:
            return 1
        if f0 >= s0 and f1 < s1:
            return -1
        return 0

    def entry(self, i):
        x, r, a = self._cross(i), self.rsi[i], self.atr[i]
        if not x or r is None or not a:
            return None
        c, p = self.c[i], self.p
        if x > 0 and 50 <= r <= 70:
            return Signal(LONG, c - a * p["stop_atr"], c + a * p["target_atr"], 55, f"EMA{p['fast']} EMA{p['slow']} ni yuqoriga kesdi, RSI {r:.0f}", self.name, dict(rsi=r, atr=a))
        if x < 0 and p["allow_short"] and 30 <= r <= 50:
            return Signal(SHORT, c + a * p["stop_atr"], c - a * p["target_atr"], 55, f"EMA{p['fast']} EMA{p['slow']} ni pastga kesdi, RSI {r:.0f}", self.name, dict(rsi=r, atr=a))
        return None

    def exit(self, i, pos):
        x = self._cross(i)
        if pos.side == LONG and x < 0:
            return "EMA pastga kesdi"
        if pos.side == SHORT and x > 0:
            return "EMA yuqoriga kesdi"
        return None
