from .base import LONG, SHORT, Position, Signal, Strategy
from .bollinger_macd import BollingerMACD
from .donchian_trend import DonchianTrend
from .ema_cross import EmaCross
from .ensemble import Ensemble
from .firm import FirmStrategy
from .orb import OpeningRangeBreakout

REGISTRY = {cls.name: cls for cls in (BollingerMACD, DonchianTrend, EmaCross, OpeningRangeBreakout, Ensemble, FirmStrategy)}
SWING = ("bollinger", "donchian", "ema_cross", "ensemble", "firm")   # kunlik/soatlik shamlar uchun
INTRADAY = ("orb",)                                          # 1m/5m shamlar uchun


def default_members():
    return [BollingerMACD(allow_short=False), DonchianTrend(allow_short=False), EmaCross()]


def make(name: str, **params) -> Strategy:
    if name not in REGISTRY:
        raise ValueError(f"Noma'lum strategiya '{name}'. Mavjud: {', '.join(REGISTRY)}")
    return REGISTRY[name](**params)


def parse_params(items):
    """['stop_atr=2.5', 'allow_short=true'] -> dict"""
    out = {}
    for it in items or []:
        k, _, v = it.partition("=")
        lv = v.lower()
        if lv in ("true", "ha", "yes"):
            out[k] = True
        elif lv in ("false", "yo'q", "no"):
            out[k] = False
        else:
            try:
                out[k] = int(v)
            except ValueError:
                try:
                    out[k] = float(v)
                except ValueError:
                    out[k] = v
    return out
