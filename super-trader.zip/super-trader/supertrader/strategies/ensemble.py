"""Agentlar kengashi - jamoaviy qaror (AI-Trader g'oyasi: "Collective Intelligence").

Har bir strategiya alohida "agent". Oxirgi ``window`` sham ichida kamida
``min_votes`` agent bir yo'nalishda signal bergan bo'lsa va joriy shamda kamida
bittasi signal bersa, kengash kiradi. Stop - eng ishonchli agentniki,
maqsad - ular ichida eng yaqini (ehtiyotkor). Chiqish: ovoz bergan agentlardan
birortasi chiqishni so'rasa.
"""

from typing import List

from .base import Signal, Strategy


class Ensemble(Strategy):
    name = "ensemble"
    title = "Agentlar kengashi (ovoz berish)"
    origin = "ai-trader"
    params = dict(min_votes=2, window=5)

    def __init__(self, members: List[Strategy] = None, **kw):
        super().__init__(**kw)
        if members is None:
            from . import default_members
            members = default_members()
        self.members = members

    def prepare(self, bars):
        super().prepare(bars)
        self.recent = {}
        for m in self.members:
            m.prepare(bars)

    def warmup(self):
        return max(m.warmup() for m in self.members)

    def entry(self, i):
        now = [s for s in (m.entry(i) for m in self.members) if s is not None]
        for s in now:
            self.recent[s.strategy] = (i, s)
        if not now:
            return None
        w = self.p["window"]
        sigs = [s for (j, s) in self.recent.values() if i - j < w]
        for side in ("LONG", "SHORT"):
            votes = [s for s in sigs if s.side == side]
            if len(votes) >= self.p["min_votes"] and any(s.side == side for s in now):
                self.recent = {}
                best = max(votes, key=lambda s: s.confidence)
                tg = [s.target for s in votes if s.target is not None]
                target = (min(tg) if side == "LONG" else max(tg)) if tg else None
                conf = min(100.0, sum(s.confidence for s in votes) / len(votes) + 10 * (len(votes) - 1))
                why = " | ".join(f"{s.strategy}: {s.reason}" for s in votes)
                return Signal(side, best.stop, target, conf, f"{len(votes)} agent rozi -> {why}", self.name, best.indicators)
        return None

    def exit(self, i, pos):
        for m in self.members:
            r = m.exit(i, pos)
            if r:
                return f"{m.name}: {r}"
        return None

    def trail(self, i, pos):
        best = None
        for m in self.members:
            s = m.trail(i, pos)
            if s is None:
                continue
            if best is None or (pos.side == "LONG" and s > best) or (pos.side == "SHORT" and s < best):
                best = s
        return best
