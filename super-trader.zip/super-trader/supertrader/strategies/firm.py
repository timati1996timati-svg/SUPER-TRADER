"""Firma strategiyasi: agentlar firmasining reytingi bo'yicha savdo (TradingAgents -> backtest).

LONG: reyting KO'PAYTIR yoki SOTIB OL ga ko'tarilganda va risk jamoasi veto qo'ymaganda.
Chiqish: reyting KAMAYTIR yoki SOT ga tushganda; stop = 2xATR, keyin eng yuqori narx - 3xATR (trailing).
Har bir qaror faqat o'sha shamgacha bo'lgan ma'lumotdan chiqariladi.
"""

from .base import LONG, SHORT, Signal, Strategy


class FirmStrategy(Strategy):
    name = "firm"
    title = "Agentlar firmasi reytingi (TradingAgents uslubi)"
    origin = "TradingAgents"
    params = dict(min_level=1, stop_atr=2.0, trail_atr=3.0, allow_short=False)

    def prepare(self, bars):
        super().prepare(bars)
        from ..agents.firm import RATINGS, Features, decide
        self.f = Features(bars)
        self._decide = decide
        self.RATINGS = RATINGS
        self._cache = {}

    def warmup(self):
        return 60

    def _d(self, i):
        if i not in self._cache:
            self._cache[i] = self._decide(self.f, i, allow_short=self.p["allow_short"], stop_atr=self.p["stop_atr"])
        return self._cache[i]

    def _level(self, i):
        return self.RATINGS.index(self._d(i).rating)  # 0 = SOTIB OL ... 4 = SOT

    def entry(self, i):
        d = self._d(i)
        lvl, prev = self._level(i), self._level(i - 1)
        bull_now, bull_prev = lvl <= self.p["min_level"], prev <= self.p["min_level"]
        if d.plan.action == "BUY" and bull_now and not bull_prev and d.final_multiplier > 0:
            return Signal(LONG, d.plan.stop, None, 50 + abs(d.score) / 2, f"firma: {d.rating} ({d.score:+.0f})", self.name)
        bear_now, bear_prev = lvl >= 4 - self.p["min_level"], prev >= 4 - self.p["min_level"]
        if self.p["allow_short"] and d.plan.action == "SELL" and d.plan.stop and bear_now and not bear_prev and d.final_multiplier > 0:
            return Signal(SHORT, d.plan.stop, None, 50 + abs(d.score) / 2, f"firma: {d.rating} ({d.score:+.0f})", self.name)
        return None

    def exit(self, i, pos):
        lvl = self._level(i)
        if pos.side == LONG and lvl >= 3:
            return f"firma reytingi tushdi: {self.RATINGS[lvl]}"
        if pos.side == SHORT and lvl <= 1:
            return f"firma reytingi ko'tarildi: {self.RATINGS[lvl]}"
        return None

    def trail(self, i, pos):
        a = self.f.atr[i]
        if a is None:
            return None
        if pos.side == LONG:
            s = pos.highest - self.p["trail_atr"] * a
            return s if s > pos.stop else None
        s = pos.lowest + self.p["trail_atr"] * a
        return s if s < pos.stop else None
