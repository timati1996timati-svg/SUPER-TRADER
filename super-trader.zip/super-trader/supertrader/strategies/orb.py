"""Ochilish diapazonini yorib o'tish - ORB (day-trader-skill/trader-entry + trader-exit dan).

  * Diapazon: seansning birinchi ``or_minutes`` daqiqasi (standart 15 = 9:30, 9:35, 9:40 shamlari)
  * Kirish: diapazondan keyin birinchi YOPILISH diapazon tepasidan yuqori (shortda pastidan past)
  * Stop: diapazon o'rtasi; Maqsad: ``target_r`` x risk (standart 1R)
  * ``no_entries_after`` (15:30) dan keyin kirilmaydi, ``flat_by`` (15:55) da majburiy yopiladi
  * Kuniga bitta savdo
Seans vaqti ``tz`` (standart America/New_York). Kripto uchun ``tz=UTC``, ``session_start=00:00``.
"""

import datetime as dt

from .base import LONG, SHORT, Signal, Strategy


def _tz(name):
    try:
        from zoneinfo import ZoneInfo
        return ZoneInfo(name)
    except Exception:  # tzdata yo'q (Windows) - AQSh DST qoidasi bilan zaxira
        if name in ("UTC", "Etc/UTC"):
            return dt.timezone.utc
        return None


def _ny_offset(utc):
    def nth_sunday(y, m, n):
        d = dt.datetime(y, m, 1)
        d += dt.timedelta(days=(6 - d.weekday()) % 7)
        return d + dt.timedelta(weeks=n - 1)
    start = nth_sunday(utc.year, 3, 2) + dt.timedelta(hours=7)
    end = nth_sunday(utc.year, 11, 1) + dt.timedelta(hours=6)
    return dt.timedelta(hours=-4 if start <= utc.replace(tzinfo=None) < end else -5)


def _hm(s):
    h, m = s.split(":")
    return int(h) * 60 + int(m)


class OpeningRangeBreakout(Strategy):
    name = "orb"
    title = "Ochilish diapazoni yorib o'tish (kunlik savdo)"
    origin = "day-trader-skill"
    params = dict(or_minutes=15, target_r=1.0, tz="America/New_York", session_start="09:30",
                  no_entries_before="09:45", no_entries_after="15:30", flat_by="15:55",
                  min_volume_x=0.0, allow_short=False)

    def prepare(self, bars):
        super().prepare(bars)
        p = self.p
        tz = _tz(p["tz"])
        self.day, self.mins = [], []
        for b in bars:
            u = dt.datetime.fromtimestamp(b.t, dt.timezone.utc)
            if tz is not None:
                loc = u.astimezone(tz)
            else:
                loc = u + _ny_offset(u)
            self.day.append(loc.date())
            self.mins.append(loc.hour * 60 + loc.minute)
        step = (bars[1].t - bars[0].t) // 60 if len(bars) > 1 else 5
        self.step = max(1, step)
        s0 = _hm(p["session_start"])
        self.range = {}
        for i, b in enumerate(bars):
            m = self.mins[i]
            if s0 <= m < s0 + p["or_minutes"]:
                hi, lo, vol, n = self.range.get(self.day[i], (b.h, b.l, 0.0, 0))
                self.range[self.day[i]] = (max(hi, b.h), min(lo, b.l), vol + b.v, n + 1)
        self.traded = set()
        self.last_of_day = set(i for i in range(len(bars)) if i == len(bars) - 1 or self.day[i + 1] != self.day[i])

    def entry(self, i):
        p = self.p
        d = self.day[i]
        if d in self.traded or d not in self.range:
            return None
        close_min = self.mins[i] + self.step  # shamning yopilish vaqti
        s0 = _hm(p["session_start"])
        if self.mins[i] < s0 + p["or_minutes"]:
            return None
        if close_min < _hm(p["no_entries_before"]) or close_min > _hm(p["no_entries_after"]):
            return None
        if i in self.last_of_day:
            return None
        hi, lo, vol, n = self.range[d]
        b = self.bars[i]
        if p["min_volume_x"] and n and b.v < p["min_volume_x"] * vol / n:
            return None
        mid = (hi + lo) / 2
        ind = dict(range_high=hi, range_low=lo, range_mid=mid)
        if b.c > hi:
            self.traded.add(d)
            risk = b.c - mid
            return Signal(LONG, mid, b.c + risk * p["target_r"], 65, f"{p['or_minutes']} daqiqalik diapazon tepasidan yopildi", self.name, ind)
        if p["allow_short"] and b.c < lo:
            self.traded.add(d)
            risk = mid - b.c
            return Signal(SHORT, mid, b.c - risk * p["target_r"], 65, f"{p['or_minutes']} daqiqalik diapazon ostidan yopildi", self.name, ind)
        return None

    def exit(self, i, pos):
        if i in self.last_of_day or self.mins[i] + self.step >= _hm(self.p["flat_by"]):
            return "kun oxiri - majburiy yopish"
        return None
