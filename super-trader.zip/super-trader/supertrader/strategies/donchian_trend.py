"""Kanal yorib o'tish trend strategiyasi ("Katta aka 2.2").

Manba: ctp-futures-trader/strategy/brother2.py (Django/TA-Lib/CTP'siz qayta yozildi).
  * qisqa va uzun trend chizig'i: Wilder silliqlashi (asl koddagi qo'lda SMA)
  * LONG: qisqa > uzun va yopilish >= oldingi N shamning eng yuqori yopilishi
  * SHORT: qisqa < uzun va yopilish <= oldingi N shamning eng past yopilishi
  * Stop (trailing): pozitsiyadan keyingi eng yuqori narx - ATR*stop_n (shortda ko'zgu)
  * Maqsad yo'q - foyda trend tugagunicha yuguradi
"""

from .. import indicators as ta
from .base import LONG, SHORT, Signal, Strategy


class DonchianTrend(Strategy):
    name = "donchian"
    title = "Kanal yorib o'tish trend (Turtle uslubi)"
    origin = "ctp-futures-trader (brother2)"
    params = dict(break_period=20, atr_period=20, short_period=20, long_period=60, stop_atr=3.0, allow_short=True)

    def prepare(self, bars):
        super().prepare(bars)
        p = self.p
        c = [b.c for b in bars]
        self.c = c
        self.atr = ta.atr([b.h for b in bars], [b.l for b in bars], c, p["atr_period"])
        self.short = ta.rma(c, p["short_period"], seed_first=True)
        self.long = ta.rma(c, p["long_period"], seed_first=True)
        self.hi = ta.rolling_max(c, p["break_period"])
        self.lo = ta.rolling_min(c, p["break_period"])

    def warmup(self):
        return max(self.p["long_period"], self.p["break_period"], self.p["atr_period"]) + 1

    def entry(self, i):
        a, hi, lo = self.atr[i], self.hi[i - 1], self.lo[i - 1]
        if None in (a, hi, lo) or a <= 0:
            return None
        c, s, l = self.c[i], self.short[i], self.long[i]
        n = self.p["stop_atr"]
        ind = dict(atr=a, short=s, long=l, channel_high=hi, channel_low=lo)
        if s > l and c >= hi:
            return Signal(LONG, c - a * n, None, 60 + min(30, (s - l) / a * 10), f"{self.p['break_period']}-kunlik maksimum yorildi, trend yuqoriga", self.name, ind)
        if self.p["allow_short"] and s < l and c <= lo:
            return Signal(SHORT, c + a * n, None, 60 + min(30, (l - s) / a * 10), f"{self.p['break_period']}-kunlik minimum yorildi, trend pastga", self.name, ind)
        return None

    def trail(self, i, pos):
        a = self.atr[pos.entry_i - 1] or self.atr[i]
        if a is None:
            return None
        n = self.p["stop_atr"]
        if pos.side == LONG:
            new = pos.highest - a * n
            return new if new > pos.stop else None
        new = pos.lowest + a * n
        return new if new < pos.stop else None
