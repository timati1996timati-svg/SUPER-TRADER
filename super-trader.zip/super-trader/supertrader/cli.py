"""SuperTrader buyruqlar qatori.

    python -m supertrader demo                         # internetsiz namoyish + HTML hisobot
    python -m supertrader analyze BTCUSDT --save       # agentlar firmasi: tahlil, bahs, reyting, reja
    python -m supertrader analyze AAPL --llm           # + Claude bilan jonli bahs (ixtiyoriy)
    python -m supertrader calibrate BTCUSDT            # reyting tarixda qanchalik to'g'ri chiqqan
    python -m supertrader reflect                      # jurnaldagi qarorlar natijasi
    python -m supertrader signal BTCUSDT AAPL          # hozirgi signallar + hajm + risk tekshiruvi
    python -m supertrader backtest BTCUSDT -s donchian --report btc.html
    python -m supertrader leaderboard BTCUSDT ETHUSDT AAPL --report top.html
    python -m supertrader timemachine TSLA --entry 364.18 --stop 358.32 --target 370.04 --interval 5m --horizon 60
    python -m supertrader size --entry 364.18 --stop 358.32 --target 370.04 --account 5000 --max-loss 50
    python -m supertrader paper buy BTCUSDT --auto     # signal bo'yicha qog'oz savdo (tasdiq bilan)
    python -m supertrader paper status
    python -m supertrader binance balance              # testnet (standart)
"""

import argparse
import json
import os
import sys

from . import __version__
from . import backtest as bt
from . import data as D
from . import montecarlo as mc
from .broker import BinanceBroker, BrokerError, PaperBroker, confirmation_phrase
from .report import render
from .risk import RiskConfig, check_trade, size_position
from .strategies import INTRADAY, REGISTRY, SWING, make, parse_params


def _p(*a):
    print(*a, flush=True)


def _cfg(a, symbol=None) -> RiskConfig:
    crypto = bool(symbol) and D.is_crypto(symbol)
    frac = a.fractional if a.fractional is not None else crypto
    return RiskConfig(account=a.account, risk_pct=a.risk_pct, max_loss_usd=a.max_loss, max_position_pct=a.max_position,
                      fee_pct=a.fee if a.fee is not None else (0.1 if crypto else 0.0), slippage_pct=a.slippage,
                      fractional=frac, min_reward_risk=a.min_rr, daily_loss_limit_pct=a.daily_limit, max_trades_per_day=a.max_trades)


def _bars(a, symbol):
    bars = D.load(symbol, a.interval, a.source, a.csv, a.range, seed=a.seed)
    if len(bars) < 60:
        raise D.DataError(f"{symbol}: juda kam sham ({len(bars)})")
    return bars


def _strategies(a):
    names = a.strategy
    if not names or names == ["all"]:
        names = list(INTRADAY if a.interval in ("1m", "5m") else SWING)
    params = parse_params(a.param)
    out = []
    for n in names:
        cls = REGISTRY[n] if n in REGISTRY else None
        if cls is None:
            raise SystemExit(f"Noma'lum strategiya: {n}. Mavjud: {', '.join(REGISTRY)}")
        own = {k: v for k, v in params.items() if k in cls.params}
        out.append(make(n, **own))
    return out


def _money(x):
    return f"${x:,.2f}"


# ---------------------------------------------------------------- buyruqlar
def cmd_backtest(a):
    sym = a.symbols[0] if a.symbols else "DEMO"
    bars = _bars(a, sym)
    cfg = _cfg(a, sym)
    results = [bt.run(s, bars, cfg, sym) for s in _strategies(a)]
    ranking = sorted(((r.strategy, bt.score(r.metrics), r.metrics) for r in results), key=lambda x: -x[1])
    order = {n: i for i, (n, _, _) in enumerate(ranking)}
    results.sort(key=lambda r: order[r.strategy])
    _print_table(sym, ranking)
    best = results[0]
    boot = mc.bootstrap_trades([t.pnl for t in best.trades], cfg.account, seed=a.seed)
    if boot:
        _p(f"\nMonte-Karlo ({best.strategy}, {boot['runs']} marta): median {_money(boot['median_final'])}, "
           f"yomon 5% {_money(boot['p05_final'])}, zarar ehtimoli {boot['prob_loss_pct']}%, 95% tushish {boot['p95_dd_pct']}%")
    if a.json:
        _p(json.dumps(dict(symbol=sym, ranking=[dict(strategy=n, score=s, **m) for n, s, m in ranking],
                           trades=[t.to_dict() for t in best.trades], montecarlo=boot), indent=2, default=str))
    if a.report:
        with open(a.report, "w") as f:
            f.write(render(sym, results, ranking, bars, boot))
        _p(f"\nHisobot: {a.report}")
    return 0


def _print_table(sym, ranking):
    _p(f"\n=== {sym} · strategiyalar reytingi ===")
    _p(f"{'#':>2} {'strategiya':<12} {'ball':>7} {'daromad%':>9} {'tushish%':>9} {'sharpe':>7} {'savdo':>6} {'yutuq%':>7} {'PF':>6} {'B&H%':>8}")
    for n, (name, sc, m) in enumerate(ranking, 1):
        pf = "∞" if m["profit_factor"] == float("inf") else f"{m['profit_factor']:.2f}"
        scs = "   —" if sc <= -999 else f"{sc:.2f}"
        _p(f"{n:>2} {name:<12} {scs:>7} {m['total_return_pct']:>9.2f} {m['max_drawdown_pct']:>9.2f} {m['sharpe']:>7.2f} "
           f"{m['trades']:>6} {m['win_rate']:>7.1f} {pf:>6} {m['buy_hold_pct']:>8.2f}")


def cmd_leaderboard(a):
    syms = a.symbols or ["DEMO"]
    board = {}
    for sym in syms:
        try:
            bars = _bars(a, sym)
        except D.DataError as e:
            _p(f"! {e}")
            continue
        cfg = _cfg(a, sym)
        rows = []
        for s in _strategies(a):
            r = bt.run(s, bars, cfg, sym)
            rows.append((r.strategy, bt.score(r.metrics), r.metrics))
            board.setdefault(r.strategy, []).append(bt.score(r.metrics))
        _print_table(sym, sorted(rows, key=lambda x: -x[1]))
    if len(syms) > 1 and board:
        _p("\n=== Umumiy reyting (o'rtacha ball) ===")
        for n, (name, sc) in enumerate(sorted(((k, sum(v) / len(v)) for k, v in board.items()), key=lambda x: -x[1]), 1):
            _p(f"{n:>2}. {name:<12} {sc:>7.2f}")
    if a.report and syms:
        a.symbols = [syms[0]]
        return cmd_backtest(a)
    return 0


def _latest_signal(strat, bars):
    strat.prepare(bars)
    i = len(bars) - 1
    if i < strat.warmup():
        return None
    return strat.entry(i)


def cmd_signal(a):
    rc = 1
    for sym in (a.symbols or ["DEMO"]):
        try:
            bars = _bars(a, sym)
        except D.DataError as e:
            _p(f"! {e}")
            continue
        cfg = _cfg(a, sym)
        last = bars[-1]
        _p(f"\n=== {sym} · oxirgi yopilish {last.c:,.4f} ({last.dt:%Y-%m-%d %H:%M} UTC) ===")
        for s in _strategies(a):
            sig = _latest_signal(s, bars)
            if not sig:
                _p(f"  {s.name:<11} KUTISH - sharoit yo'q")
                continue
            rc = 0
            sz = size_position(cfg, last.c, sig.stop, sig.target)
            v = check_trade(cfg, sz)
            tgt = f"{sig.target:,.4f}" if sig.target else "trend (trailing stop)"
            _p(f"  {s.name:<11} {sig.side} ishonch {sig.confidence:.0f}% · {sig.reason}")
            _p(f"  {'':<11} kirish ~{last.c:,.4f} · stop {sig.stop:,.4f} · maqsad {tgt}")
            _p(f"  {'':<11} hajm {sz.qty:g} ({_money(sz.notional)}) · maks. zarar {_money(sz.max_loss)} · risk: {v.label}"
               + (f" ({'; '.join(v.reasons)})" if v.reasons else ""))
    return rc


def cmd_size(a):
    cfg = _cfg(a, a.symbol)
    s = size_position(cfg, a.entry, a.stop, a.target, cash=a.cash)
    v = check_trade(cfg, s, cash=a.cash)
    _p(f"Kirish {a.entry} · stop {a.stop} · maqsad {a.target} · bir dona riski {s.risk_per_unit:.4f}")
    _p(f"Hajm: {s.qty:g} dona = {_money(s.notional)} · stopda zarar {_money(s.max_loss)}" + (f" · R:R {s.reward_risk:.2f}" if s.reward_risk else ""))
    for n in s.notes:
        _p("  eslatma: " + n)
    _p(f"Risk tekshiruvi: {v.label}")
    for c in v.checks:
        _p("  ✓ " + c)
    for c in v.reasons:
        _p("  ✗ " + c)
    return 0 if v.ok else 1


def cmd_timemachine(a):
    sym = a.symbols[0] if a.symbols else "DEMO"
    bars = _bars(a, sym)
    entry = a.entry or bars[-1].c
    side = a.side.upper()
    if a.stop is None or a.target is None:
        # stop/maqsad berilmasa - eng yaxshi strategiya signalidan yoki 2/4 ATR
        from .indicators import atr
        at = atr([b.h for b in bars], [b.l for b in bars], [b.c for b in bars], 14)[-1]
        stop = a.stop or (entry - 2 * at if side == "LONG" else entry + 2 * at)
        target = a.target or (entry + 2 * at if side == "LONG" else entry - 2 * at)
    else:
        stop, target = a.stop, a.target
    r = mc.replay_plan(bars, side, entry, stop, target, a.horizon, a.replays, a.seed)
    _p(f"\n=== Vaqt mashinasi · {sym} {side} · kirish {entry:,.4f} stop {stop:,.4f} maqsad {target:,.4f} ({r['reward_r']}R) ===")
    _p(f"{r['replays']:,} simulyatsiya, har biri {r['horizon']} sham (seed {r['seed']}):")
    _p(f"  maqsad birinchi: {r['target_pct']}%   stop birinchi: {r['stop_pct']}%   hech biri: {r['neither_pct']}%")
    _p(f"  yashil yakun: {r['green_pct']}%   o'rtacha R: {r['avg_r']:+.3f}")
    _p(f"  yakuniy narx: median {r['median_price']:,.4f} · 5%-95%: {r['p05']:,.4f} - {r['p95']:,.4f}")
    _p(f"  HUKM: {r['verdict']}")
    if r["note"]:
        _p("  " + r["note"])
    _p("  (Bu bashorat emas: yangiliklar, hisobotlar o'tmishdagi shamlardan farq qilishi mumkin.)")
    if a.json:
        _p(json.dumps(r, indent=2))
    return 0


def _confirm(phrase, yes_flag):
    if yes_flag:
        return True
    _p(f"\nTasdiqlash uchun aynan shuni yozing:  {phrase}")
    try:
        ans = input("> ").strip()
    except EOFError:
        ans = ""
    if ans != phrase:
        _p("Bekor qilindi - buyruq yuborilmadi.")
        return False
    return True


def cmd_paper(a):
    pb = PaperBroker(a.state, cash=a.account)
    if a.action == "status":
        _p(f"Naqd: {_money(pb.cash)} · boshlang'ich {_money(pb.s['start_cash'])}")
        for sym, p in pb.s["positions"].items():
            _p(f"  {sym}: {p['side']} {p['qty']:g} @ {p['entry']:,.4f} · stop {p['stop']} · maqsad {p['target']}")
        closed = [r for r in pb.s["log"] if r["action"] == "close"]
        if closed:
            tot = sum(r["pnl"] for r in closed)
            w = sum(1 for r in closed if r["pnl"] > 0)
            _p(f"Yopilgan savdolar: {len(closed)} · yutuq {w} · jami {_money(tot)}")
        return 0
    if a.action == "reset":
        if os.path.exists(a.state):
            os.remove(a.state)
        _p("Qog'oz hisob tozalandi.")
        return 0
    sym = a.symbol.upper()
    if a.action == "check":
        prices = {}
        for s in list(pb.s["positions"]):
            prices[s] = a.price or _bars(a, s)[-1].c
        for sym_, kind, pnl in pb.check_brackets(prices):
            _p(f"  {sym_}: {kind} ishladi, foyda {_money(pnl)}")
        _p("Tekshirildi.")
        return 0
    price = a.price
    bars = None
    if price is None:
        bars = _bars(a, sym)
        price = bars[-1].c
    if a.action == "close":
        pnl = pb.close(sym, price)
        _p(f"{sym} yopildi @ {price:,.4f} · foyda {_money(pnl)}")
        return 0
    side = "LONG" if a.action == "buy" else "SHORT"
    stop, target, why = a.stop, a.target, "qo'lda"
    if a.auto:
        bars = bars or _bars(a, sym)
        for s in _strategies(a):
            sig = _latest_signal(s, bars)
            if sig and sig.side == side:
                stop, target, why = sig.stop, sig.target, f"{s.name}: {sig.reason}"
                break
        else:
            _p("Hozir hech bir strategiya bu yo'nalishda signal bermayapti. Buyruq yo'q.")
            return 1
    if stop is None:
        raise SystemExit("--stop kerak (yoki --auto). Stopsiz savdo ochilmaydi.")
    cfg = _cfg(a, sym)
    pnl_today, n_today = pb.today_stats()
    sz = size_position(cfg, price, stop, target, equity=pb.equity(), cash=pb.cash)
    if a.qty:
        sz = size_position(RiskConfig(**{**cfg.to_dict(), "risk_pct": 100, "max_loss_usd": abs(price - stop) * a.qty, "max_position_pct": 100}), price, stop, target, cash=pb.cash)
    v = check_trade(cfg, sz, pnl_today, n_today, cash=pb.cash, equity=pb.equity())
    _p(f"\nBuyurtma: {side} {sz.qty:g} {sym} @ ~{price:,.4f} · stop {stop:,.4f} · maqsad {target if target is None else round(target, 4)}")
    _p(f"Sabab: {why}\nMaks. zarar {_money(sz.max_loss)} · risk: {v.label}")
    for r in v.reasons:
        _p("  ✗ " + r)
    if not v.ok and not a.force:
        _p("Risk qoidalari bloklandi. (--force bilan baribir ochish mumkin, tavsiya etilmaydi.)")
        return 1
    if not _confirm(confirmation_phrase("BUY" if side == "LONG" else "SELL", sz.qty, sym), a.yes):
        return 1
    pb.open(sym, side, sz.qty, price, stop, target, why)
    _p(f"Qog'oz pozitsiya ochildi. Naqd: {_money(pb.cash)}")
    return 0


def cmd_binance(a):
    try:
        br = BinanceBroker(testnet=not a.mainnet)
    except BrokerError as e:
        _p(f"! {e}")
        return 1
    _p(f"Binance {'TESTNET' if br.testnet else '‼ HAQIQIY HISOB (MAINNET) ‼'}")
    if a.action == "balance":
        for k, v in sorted(br.balances().items()):
            _p(f"  {k:<8} {v:,.8f}")
        return 0
    sym = a.symbol.upper()
    price = br.price(sym)
    step, minq = br.lot_step(sym)
    if a.action == "buy":
        if not a.usdt:
            raise SystemExit("--usdt summa kerak (masalan --usdt 50)")
        qty = int(a.usdt / price / step) * step
        if qty < minq:
            raise SystemExit(f"Miqdor juda kichik ({qty} < {minq})")
        _p(f"MARKET BUY {qty:g} {sym} @ ~{price:,.4f} (≈ {_money(qty * price)})")
        if a.stop and a.target:
            _p(f"So'ng OCO: maqsad {a.target}, stop {a.stop}")
        if not _confirm(confirmation_phrase("BUY", qty, sym), False):
            return 1
        res = br.market_order(sym, "BUY", qty)
        _p(json.dumps(res, indent=2))
        if a.stop and a.target:
            filled = float(res.get("executedQty", qty))
            _p(json.dumps(br.oco_sell(sym, int(filled / step) * step, a.target, a.stop), indent=2))
        return 0
    if a.action == "sell":
        qty = a.qty or 0
        if qty <= 0:
            raise SystemExit("--qty kerak")
        _p(f"MARKET SELL {qty:g} {sym} @ ~{price:,.4f}")
        if not _confirm(confirmation_phrase("SELL", qty, sym), False):
            return 1
        _p(json.dumps(br.market_order(sym, "SELL", qty), indent=2))
        return 0
    return 1


def _print_decision(d, a):
    import datetime as _dt
    when = _dt.datetime.fromtimestamp(d.time, _dt.timezone.utc).strftime("%Y-%m-%d %H:%M")
    bar = "█" * int(abs(d.score) / 5)
    _p(f"\n╔══ AGENTLAR FIRMASI · {d.symbol} · {when} UTC · yopilish {d.close:,.4f}")
    _p(f"║ REYTING: {d.rating} ({d.rating_en})   ball {d.score:+.0f}/100  {'+' if d.score >= 0 else '-'}{bar}")
    _p(f"║ Bozor rejimi: {d.regime}")
    _p("╠══ 1. Tahlilchilar")
    for r in d.reports:
        _p(f"║  {r.analyst:<26} {r.score:+5.0f}")
        for pt in r.points:
            mark = "▲" if pt.weight > 0 else "▼" if pt.weight < 0 else "•"
            _p(f"║     {mark} {pt.text}")
    _p("╠══ 2. Bahs")
    _p(f"║  Buqa tadqiqotchi ({len(d.bull)} dalil, +{sum(x.weight for x in d.bull):.0f}): " + ("; ".join(x.text for x in d.bull[:3]) or "-"))
    _p(f"║  Ayiq tadqiqotchi ({len(d.bear)} dalil, {sum(x.weight for x in d.bear):.0f}): " + ("; ".join(x.text for x in d.bear[:3]) or "-"))
    _p("╠══ 3. Treyder rejasi")
    pl = d.plan
    if pl.stop is not None:
        _p(f"║  {pl.action} ~{pl.entry:,.4f} · stop {pl.stop:,.4f} · maqsad {pl.target:,.4f} ({pl.reward_r:.1f}R)")
    else:
        _p(f"║  {pl.action}: {'yangi pozitsiya ochilmaydi / borini yopish' if pl.action == 'SELL' else 'kutish'}")
    _p("╠══ 4. Risk jamoasi")
    for v in d.risk_views:
        _p(f"║  {v.who:<11} x{v.multiplier:<4} {v.reason}")
    _p("╠══ 5. Portfel menejeri")
    _p(f"║  Risk ko'paytiruvchi: x{d.final_multiplier}" + (f" · hajm {d.qty:g} · stopda zarar ${d.max_loss:,.2f}" if d.qty else ""))
    for n in d.notes:
        _p(f"║  ! {n}")
    if d.odds:
        o = d.odds
        _p(f"╠══ 6. Vaqt mashinasi ({o['replays']:,} simulyatsiya, {o['horizon']} sham)")
        _p(f"║  maqsad {o['target_pct']}% · stop {o['stop_pct']}% · hech biri {o['neither_pct']}% · {o['verdict']}")
    if d.llm:
        L = d.llm
        _p(f"╠══ 7. Claude bahsi ({L.get('model')})")
        _p(f"║  Buqa: {L['bull_case']}")
        _p(f"║  Ayiq: {L['bear_case']}")
        _p(f"║  G'olib: {L['debate_winner']} · Claude reytingi: {L['rating']} ({L['confidence']}%)"
           + ("  ✓ qoidalar bilan bir xil" if L['rating'] == d.rating else f"  ≠ qoidalar: {d.rating}"))
        _p(f"║  Xulosa: {L['summary']}")
        for k in L.get("key_risks", [])[:4]:
            _p(f"║   - {k}")
    _p("╚══ Bu moliyaviy maslahat emas.")


def cmd_analyze(a):
    from .agents import analyze
    from .agents import memory as M
    rc = 0
    for sym in (a.symbols or ["DEMO"]):
        try:
            bars = _bars(a, sym)
        except D.DataError as e:
            _p(f"! {e}")
            rc = 1
            continue
        d = analyze(bars, sym, _cfg(a, sym), allow_short=a.allow_short, seed=a.seed)
        if a.llm:
            from .agents.llm import LLMError, debate
            try:
                d.llm = debate(d, model=a.model)
            except LLMError as e:
                _p(f"! Claude: {e}")
        if a.json:
            _p(json.dumps(d.to_dict(), indent=2, ensure_ascii=False, default=str))
        else:
            _print_decision(d, a)
        if a.save:
            ok = M.store(d, a.log)
            _p(f"Jurnal: {'saqlandi' if ok else 'bu sham uchun allaqachon bor'} -> {a.log}")
        if a.report:
            from .report import render_decision
            with open(a.report, "w") as f:
                f.write(render_decision(d, bars))
            _p(f"Hisobot: {a.report}")
    return rc


def cmd_reflect(a):
    from .agents import memory as M
    entries = M.load(a.log)
    if not entries:
        _p(f"Jurnal bo'sh: {a.log}. Avval: supertrader analyze SYMBOL --save")
        return 1
    bars = {}
    for sym in sorted({e["symbol"] for e in entries}):
        try:
            bars[sym] = _bars(a, sym)
        except D.DataError as e:
            _p(f"! {e}")
    res = M.reflect(entries, bars, a.horizon)
    _p(f"\n=== Xulosa: {len(entries)} qaror, har biri {a.horizon} shamdan keyin baholandi ===")
    for row in res["rows"][-20:]:
        o = row["outcome"]
        res_txt = "hali erta" if o is None else f"{o['return_pct']:+.2f}% " + ("✓" if o["hit"] else "✗" if o["hit"] is False else "·")
        _p(f"  {row['date']}  {row['symbol']:<9} {row['rating']:<10} {row['score']:+5.0f}  -> {res_txt}")
    _p("\nReyting bo'yicha:")
    for r, g in res["by_rating"].items():
        hr = "-" if g["hit_rate"] is None else f"{g['hit_rate']}%"
        _p(f"  {r:<10} {g['n']:>4} qaror · o'rtacha {g['avg_return']:+.2f}% · to'g'ri yo'nalish {hr}")
    return 0


def cmd_calibrate(a):
    from .agents import calibrate
    for sym in (a.symbols or ["DEMO"]):
        try:
            bars = _bars(a, sym)
        except D.DataError as e:
            _p(f"! {e}")
            continue
        res = calibrate(bars, a.horizon)
        _p(f"\n=== {sym}: firma reytingi tarixda qanchalik to'g'ri? (kirish keyingi yopilishda, {a.horizon} sham ushlab) ===")
        _p(f"{'reyting':<11} {'soni':>6} {'o`rtacha %':>11} {'o`sish ulushi':>14}")
        for r, g in res.items():
            _p(f"{r:<11} {g['n']:>6} {g['avg']:>+11.3f} {g['win']:>13.1f}%")
        buy, sell = res["SOTIB OL"], res["SOT"]
        if buy["n"] >= 20 and sell["n"] >= 20:
            edge = buy["avg"] - sell["avg"]
            _p(f"Farq (SOTIB OL - SOT): {edge:+.3f}% -> " + ("reyting foydali signal bermoqda" if edge > 0 else "bu aktivda reyting ishlamayapti - ehtiyot bo'ling"))
        else:
            _p("Xulosa uchun ma'lumot kam (har bir chetki reytingda kamida 20 kuzatuv kerak).")
    return 0


def cmd_demo(a):
    _p("Internetsiz namoyish: sintetik narxlar (seed=%d), 5 strategiya + agentlar firmasi" % a.seed)
    a.symbols, a.source, a.interval = ["DEMO"], "demo", "1d"
    a.report = a.report or "supertrader_demo.html"
    a.strategy = None
    return cmd_backtest(a)


def cmd_strategies(a):
    for name, cls in REGISTRY.items():
        _p(f"{name:<11} {cls.title}  [manba: {cls.origin}]")
        _p(f"{'':<11} parametrlar: {', '.join(f'{k}={v}' for k, v in cls.params.items())}")
    return 0


def build_parser():
    common = argparse.ArgumentParser(add_help=False)
    g = common.add_argument_group("ma'lumot")
    g.add_argument("-i", "--interval", default="1d", help="1m 5m 15m 1h 4h 1d ... (standart 1d)")
    g.add_argument("--source", default="auto", choices=["auto", "yahoo", "binance", "demo"])
    g.add_argument("--csv", help="CSV fayldan o'qish (time,open,high,low,close,volume)")
    g.add_argument("--range", default="2y", help="Yahoo davri: 5d 60d 1y 2y 5y max")
    g.add_argument("--seed", type=int, default=19)
    s = common.add_argument_group("strategiya")
    s.add_argument("-s", "--strategy", nargs="*", help=f"{', '.join(REGISTRY)} yoki all")
    s.add_argument("-P", "--param", nargs="*", help="strategiya parametri: stop_atr=2.5 allow_short=true")
    r = common.add_argument_group("risk")
    r.add_argument("--account", type=float, default=10_000)
    r.add_argument("--risk-pct", type=float, default=1.0)
    r.add_argument("--max-loss", type=float, help="bitta savdoda maks. zarar $")
    r.add_argument("--max-position", type=float, default=50.0, help="pozitsiya maks. %% hisobdan")
    r.add_argument("--fee", type=float, help="komissiya %% (kripto 0.1, aksiya 0)")
    r.add_argument("--slippage", type=float, default=0.02)
    r.add_argument("--fractional", action="store_true", default=None)
    r.add_argument("--min-rr", type=float, default=1.0)
    r.add_argument("--daily-limit", type=float, default=3.0)
    r.add_argument("--max-trades", type=int, default=5)
    common.add_argument("--json", action="store_true")
    common.add_argument("--report", help="HTML hisobot fayli")

    p = argparse.ArgumentParser(prog="supertrader", description="SuperTrader - agentlar firmasi, strategiyalar, backtest va risk")
    p.add_argument("--version", action="version", version=__version__)
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("demo", parents=[common], help="internetsiz namoyish").set_defaults(fn=cmd_demo)
    sub.add_parser("strategies", help="strategiyalar ro'yxati").set_defaults(fn=cmd_strategies)
    for name, fn, h in [("backtest", cmd_backtest, "tarixda sinash"), ("leaderboard", cmd_leaderboard, "strategiyalar musobaqasi"),
                        ("signal", cmd_signal, "hozirgi signallar")]:
        sp = sub.add_parser(name, parents=[common], help=h)
        sp.add_argument("symbols", nargs="*")
        sp.set_defaults(fn=fn)
    from .agents.memory import DEFAULT_LOG
    sp = sub.add_parser("analyze", parents=[common], help="agentlar firmasi: tahlil, bahs, reyting, reja")
    sp.add_argument("symbols", nargs="*")
    sp.add_argument("--allow-short", action="store_true")
    sp.add_argument("--save", action="store_true", help="qarorni jurnalga yozish")
    sp.add_argument("--log", default=DEFAULT_LOG)
    sp.add_argument("--llm", action="store_true", help="Claude bilan bahs (pip install anthropic)")
    sp.add_argument("--model", default="claude-opus-5-5")
    sp.set_defaults(fn=cmd_analyze)
    sp = sub.add_parser("reflect", parents=[common], help="jurnaldagi qarorlarni haqiqiy natija bilan baholash")
    sp.add_argument("--log", default=DEFAULT_LOG)
    sp.add_argument("--horizon", type=int, default=10)
    sp.set_defaults(fn=cmd_reflect)
    sp = sub.add_parser("calibrate", parents=[common], help="firma reytingini tarixda tekshirish")
    sp.add_argument("symbols", nargs="*")
    sp.add_argument("--horizon", type=int, default=10)
    sp.set_defaults(fn=cmd_calibrate)
    sp = sub.add_parser("timemachine", parents=[common], help="reja Monte-Karlo simulyatsiyasi")
    sp.add_argument("symbols", nargs="*")
    sp.add_argument("--side", default="LONG")
    sp.add_argument("--entry", type=float)
    sp.add_argument("--stop", type=float)
    sp.add_argument("--target", type=float)
    sp.add_argument("--horizon", type=int, default=20)
    sp.add_argument("--replays", type=int, default=10_000)
    sp.set_defaults(fn=cmd_timemachine)
    sp = sub.add_parser("size", parents=[common], help="pozitsiya hajmi + risk tekshiruvi")
    sp.add_argument("--symbol")
    sp.add_argument("--entry", type=float, required=True)
    sp.add_argument("--stop", type=float, required=True)
    sp.add_argument("--target", type=float)
    sp.add_argument("--cash", type=float)
    sp.set_defaults(fn=cmd_size)
    sp = sub.add_parser("paper", parents=[common], help="qog'oz savdo")
    sp.add_argument("action", choices=["buy", "sell", "close", "status", "check", "reset"])
    sp.add_argument("symbol", nargs="?", default="DEMO")
    sp.add_argument("--price", type=float)
    sp.add_argument("--stop", type=float)
    sp.add_argument("--target", type=float)
    sp.add_argument("--qty", type=float)
    sp.add_argument("--auto", action="store_true", help="stop/maqsadni strategiya signalidan olish")
    sp.add_argument("--yes", action="store_true", help="qog'oz savdoda tasdiqni o'tkazib yuborish")
    sp.add_argument("--force", action="store_true")
    sp.add_argument("--state", default=os.path.join("trader_data", "paper.json"))
    sp.set_defaults(fn=cmd_paper)
    sp = sub.add_parser("binance", parents=[common], help="Binance spot (standart testnet)")
    sp.add_argument("action", choices=["balance", "buy", "sell"])
    sp.add_argument("symbol", nargs="?", default="BTCUSDT")
    sp.add_argument("--usdt", type=float)
    sp.add_argument("--qty", type=float)
    sp.add_argument("--stop", type=float)
    sp.add_argument("--target", type=float)
    sp.add_argument("--mainnet", action="store_true", help="HAQIQIY pul bilan")
    sp.set_defaults(fn=cmd_binance)
    return p


def main(argv=None):
    a = build_parser().parse_args(argv)
    try:
        return a.fn(a)
    except (D.DataError, BrokerError, ValueError) as e:
        _p(f"Xato: {e}")
        return 1
    except KeyboardInterrupt:
        return 130
    except BrokenPipeError:
        try:
            sys.stdout = open(os.devnull, "w")
        except OSError:
            pass
        return 0


if __name__ == "__main__":
    sys.exit(main())
