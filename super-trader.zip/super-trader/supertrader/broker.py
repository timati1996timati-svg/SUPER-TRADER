"""Brokerlar: qog'oz savdo (standart) va Binance (ixtiyoriy, haqiqiy pul).

Xavfsizlik qoidasi (day-trader-skill/trader-broker dan): hech qanday buyruq
sizning aniq "HA" javobingizsiz yuborilmaydi. Binance standart holatda TESTNET'ga
ulanadi; haqiqiy hisob uchun ``--mainnet`` va aniq tasdiq matni kerak.
Kalitlar faqat muhit o'zgaruvchilaridan o'qiladi: BINANCE_API_KEY, BINANCE_API_SECRET.
Binance API kalitida "Enable Withdrawals" ni HECH QACHON yoqmang.
"""

import datetime as dt
import hashlib
import hmac
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Dict, Optional

DEFAULT_STATE = os.path.join("trader_data", "paper.json")


class BrokerError(Exception):
    pass


def _today():
    return dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d")


class PaperBroker:
    """JSON faylda saqlanadigan qog'oz hisob: naqd, pozitsiyalar (stop/maqsad bilan), jurnal."""

    def __init__(self, path: str = DEFAULT_STATE, cash: float = 10_000.0, fee_pct: float = 0.1):
        self.path = path
        if os.path.exists(path):
            with open(path) as f:
                self.s = json.load(f)
        else:
            self.s = dict(cash=cash, start_cash=cash, fee_pct=fee_pct, positions={}, log=[])

    def save(self):
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w") as f:
            json.dump(self.s, f, indent=2, ensure_ascii=False)
        os.replace(tmp, self.path)

    @property
    def cash(self):
        return self.s["cash"]

    def today_stats(self):
        t = _today()
        rows = [r for r in self.s["log"] if r["time"].startswith(t)]
        return sum(r.get("pnl", 0) for r in rows), sum(1 for r in rows if r["action"] == "open")

    def equity(self, prices: Dict[str, float] = None):
        prices = prices or {}
        eq = self.cash
        for sym, p in self.s["positions"].items():
            px = prices.get(sym, p["entry"])
            eq += p["qty"] * px if p["side"] == "LONG" else p["qty"] * (2 * p["entry"] - px)
        return eq

    def open(self, symbol, side, qty, price, stop=None, target=None, note=""):
        symbol = symbol.upper()
        if symbol in self.s["positions"]:
            raise BrokerError(f"{symbol} bo'yicha ochiq pozitsiya bor - avval yoping")
        if qty <= 0:
            raise BrokerError("miqdor 0 dan katta bo'lishi kerak")
        cost = qty * price
        fee = cost * self.s["fee_pct"] / 100
        if cost + fee > self.cash + 1e-9:
            raise BrokerError(f"naqd yetmaydi: kerak ${cost + fee:,.2f}, bor ${self.cash:,.2f}")
        self.s["cash"] -= cost + fee
        self.s["positions"][symbol] = dict(side=side, qty=qty, entry=price, stop=stop, target=target,
                                            opened=dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"), note=note)
        self._log("open", symbol, side, qty, price, fee=fee, note=note)
        self.save()

    def close(self, symbol, price, why="qo'lda"):
        symbol = symbol.upper()
        p = self.s["positions"].pop(symbol, None)
        if p is None:
            raise BrokerError(f"{symbol} bo'yicha ochiq pozitsiya yo'q")
        gross = (price - p["entry"]) * p["qty"] if p["side"] == "LONG" else (p["entry"] - price) * p["qty"]
        fee = price * p["qty"] * self.s["fee_pct"] / 100
        self.s["cash"] += p["entry"] * p["qty"] + gross - fee
        pnl = gross - fee - p["entry"] * p["qty"] * self.s["fee_pct"] / 100
        self._log("close", symbol, p["side"], p["qty"], price, pnl=round(pnl, 2), fee=fee, note=why)
        self.save()
        return pnl

    def check_brackets(self, prices: Dict[str, float]):
        """Narx stop yoki maqsadga yetgan pozitsiyalarni yopadi (trader-alerts g'oyasi)."""
        events = []
        for sym, p in list(self.s["positions"].items()):
            px = prices.get(sym)
            if px is None:
                continue
            long = p["side"] == "LONG"
            if p.get("stop") is not None and ((long and px <= p["stop"]) or (not long and px >= p["stop"])):
                events.append((sym, "stop", self.close(sym, px, "stop")))
            elif p.get("target") is not None and ((long and px >= p["target"]) or (not long and px <= p["target"])):
                events.append((sym, "maqsad", self.close(sym, px, "maqsad")))
        return events

    def _log(self, action, symbol, side, qty, price, **kw):
        self.s["log"].append(dict(time=dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
                                  action=action, symbol=symbol, side=side, qty=qty, price=price, **kw))


class BinanceBroker:
    """Binance Spot REST (binance-trader/app/BinanceAPI.py dan, ``requests``siz)."""

    MAINNET = "https://api.binance.com"
    TESTNET = "https://testnet.binance.vision"

    def __init__(self, key: Optional[str] = None, secret: Optional[str] = None, testnet: bool = True, recv_window: int = 5000):
        self.key = key or os.environ.get("BINANCE_API_KEY", "")
        self.secret = secret or os.environ.get("BINANCE_API_SECRET", "")
        if not self.key or not self.secret:
            raise BrokerError("BINANCE_API_KEY va BINANCE_API_SECRET muhit o'zgaruvchilarini o'rnating")
        self.base = self.TESTNET if testnet else self.MAINNET
        self.testnet = testnet
        self.recv_window = recv_window

    def sign(self, params: Dict) -> str:
        q = urllib.parse.urlencode(params)
        sig = hmac.new(self.secret.encode(), q.encode(), hashlib.sha256).hexdigest()
        return f"{q}&signature={sig}"

    def _req(self, method, path, params=None, signed=True):
        params = dict(params or {})
        if signed:
            params.update(timestamp=int(time.time() * 1000), recvWindow=self.recv_window)
            q = self.sign(params)
        else:
            q = urllib.parse.urlencode(params)
        url = f"{self.base}{path}"
        data = None
        if method == "GET":
            url += "?" + q
        else:
            data = q.encode()
        req = urllib.request.Request(url, data=data, method=method, headers={"X-MBX-APIKEY": self.key})
        try:
            with urllib.request.urlopen(req, timeout=20) as r:
                return json.loads(r.read())
        except urllib.error.HTTPError as e:
            body = e.read().decode(errors="replace")
            raise BrokerError(f"Binance {e.code}: {body}")

    def account(self):
        return self._req("GET", "/api/v3/account")

    def balances(self):
        return {b["asset"]: float(b["free"]) + float(b["locked"]) for b in self.account()["balances"]
                if float(b["free"]) + float(b["locked"]) > 0}

    def price(self, symbol):
        return float(self._req("GET", "/api/v3/ticker/price", {"symbol": symbol.upper()}, signed=False)["price"])

    def lot_step(self, symbol):
        info = self._req("GET", "/api/v3/exchangeInfo", {"symbol": symbol.upper()}, signed=False)
        for f in info["symbols"][0]["filters"]:
            if f["filterType"] == "LOT_SIZE":
                return float(f["stepSize"]), float(f["minQty"])
        return 0.00000001, 0.0

    def market_order(self, symbol, side, quantity, test=False):
        path = "/api/v3/order/test" if test else "/api/v3/order"
        return self._req("POST", path, dict(symbol=symbol.upper(), side=side.upper(), type="MARKET", quantity=f"{quantity:.8f}".rstrip("0").rstrip(".")))

    def oco_sell(self, symbol, quantity, take_profit, stop, stop_limit=None):
        """Sotib olgandan keyin stop + maqsad (OCO) buyrug'i."""
        stop_limit = stop_limit or stop * 0.998
        return self._req("POST", "/api/v3/order/oco", dict(
            symbol=symbol.upper(), side="SELL", quantity=f"{quantity:.8f}".rstrip("0").rstrip("."),
            price=f"{take_profit:.8f}".rstrip("0").rstrip("."), stopPrice=f"{stop:.8f}".rstrip("0").rstrip("."),
            stopLimitPrice=f"{stop_limit:.8f}".rstrip("0").rstrip("."), stopLimitTimeInForce="GTC"))


def confirmation_phrase(side, qty, symbol):
    return f"HA {side.upper()} {qty:g} {symbol.upper()}"
