"""Texnik indikatorlar (faqat standart kutubxona).

Manba: binance-trader/app/Indicators.py g'oyalari asosida qayta yozildi.
Farqi: har bir funksiya butun qator (series) qaytaradi, boshidagi hisoblab
bo'lmaydigan joylar ``None``. MACD signal chizig'i endi to'g'ri hisoblanadi
(asl koddagi taxminiy ``macd_line * 0.8`` o'rniga haqiqiy EMA).
"""

import math
from typing import List, Optional, Sequence, Tuple

Series = List[Optional[float]]


def sma(x: Sequence[float], n: int) -> Series:
    out: Series = [None] * len(x)
    s = 0.0
    for i, v in enumerate(x):
        s += v
        if i >= n:
            s -= x[i - n]
        if i >= n - 1:
            out[i] = s / n
    return out


def ema(x: Sequence[Optional[float]], n: int) -> Series:
    """EMA; boshidagi ``None`` qiymatlarni o'tkazib yuboradi, SMA bilan boshlanadi."""
    out: Series = [None] * len(x)
    k = 2.0 / (n + 1)
    seed: List[float] = []
    prev = None
    for i, v in enumerate(x):
        if v is None:
            continue
        if prev is None:
            seed.append(v)
            if len(seed) == n:
                prev = sum(seed) / n
                out[i] = prev
            continue
        prev = v * k + prev * (1 - k)
        out[i] = prev
    return out


def rma(x: Sequence[float], n: int, seed_first: bool = False) -> Series:
    """Wilder silliqlashi. ``seed_first=True`` bo'lsa birinchi qiymatdan boshlaydi
    (ctp-futures-trader/strategy/brother2.py dagi qo'lda hisoblangan SMA kabi)."""
    out: Series = [None] * len(x)
    if not x:
        return out
    if seed_first:
        prev = x[0]
        out[0] = prev
        for i in range(1, len(x)):
            prev = (prev * (n - 1) + x[i]) / n
            out[i] = prev
        return out
    if len(x) < n:
        return out
    prev = sum(x[:n]) / n
    out[n - 1] = prev
    for i in range(n, len(x)):
        prev = (prev * (n - 1) + x[i]) / n
        out[i] = prev
    return out


def rsi(close: Sequence[float], n: int = 14) -> Series:
    out: Series = [None] * len(close)
    if len(close) <= n:
        return out
    gains = losses = 0.0
    for i in range(1, n + 1):
        d = close[i] - close[i - 1]
        gains += max(d, 0.0)
        losses += max(-d, 0.0)
    ag, al = gains / n, losses / n

    def val(g, l):
        if l == 0:
            return 100.0 if g > 0 else 50.0
        return 100.0 - 100.0 / (1.0 + g / l)

    out[n] = val(ag, al)
    for i in range(n + 1, len(close)):
        d = close[i] - close[i - 1]
        ag = (ag * (n - 1) + max(d, 0.0)) / n
        al = (al * (n - 1) + max(-d, 0.0)) / n
        out[i] = val(ag, al)
    return out


def macd(close: Sequence[float], fast: int = 12, slow: int = 26, signal: int = 9) -> Tuple[Series, Series, Series]:
    ef, es = ema(close, fast), ema(close, slow)
    line: Series = [a - b if a is not None and b is not None else None for a, b in zip(ef, es)]
    sig = ema(line, signal)
    hist: Series = [a - b if a is not None and b is not None else None for a, b in zip(line, sig)]
    return line, sig, hist


def bollinger(close: Sequence[float], n: int = 20, k: float = 2.0) -> Tuple[Series, Series, Series]:
    mid = sma(close, n)
    up: Series = [None] * len(close)
    lo: Series = [None] * len(close)
    for i in range(n - 1, len(close)):
        m = mid[i]
        var = sum((c - m) ** 2 for c in close[i - n + 1:i + 1]) / n
        sd = math.sqrt(var)
        up[i], lo[i] = m + k * sd, m - k * sd
    return up, mid, lo


def true_range(high, low, close) -> List[float]:
    tr = [high[0] - low[0]] if high else []
    for i in range(1, len(high)):
        tr.append(max(high[i] - low[i], abs(high[i] - close[i - 1]), abs(low[i] - close[i - 1])))
    return tr


def atr(high, low, close, n: int = 14) -> Series:
    return rma(true_range(high, low, close), n)


def rolling_max(x: Sequence[float], n: int) -> Series:
    return [max(x[i - n + 1:i + 1]) if i >= n - 1 else None for i in range(len(x))]


def rolling_min(x: Sequence[float], n: int) -> Series:
    return [min(x[i - n + 1:i + 1]) if i >= n - 1 else None for i in range(len(x))]


def volume_ratio(volume: Sequence[float], n: int = 20) -> Series:
    avg = sma(volume, n)
    return [v / a if a else None for v, a in zip(volume, avg)]


def vwma(close: Sequence[float], volume: Sequence[float], n: int = 20) -> Series:
    out: Series = [None] * len(close)
    for i in range(n - 1, len(close)):
        v = sum(volume[i - n + 1:i + 1])
        out[i] = sum(c * w for c, w in zip(close[i - n + 1:i + 1], volume[i - n + 1:i + 1])) / v if v else None
    return out


def obv(close: Sequence[float], volume: Sequence[float]) -> List[float]:
    out = [0.0] * len(close)
    for i in range(1, len(close)):
        d = close[i] - close[i - 1]
        out[i] = out[i - 1] + (volume[i] if d > 0 else -volume[i] if d < 0 else 0.0)
    return out


def roc(close: Sequence[float], n: int = 20) -> Series:
    return [(close[i] / close[i - n] - 1) * 100 if i >= n and close[i - n] else None for i in range(len(close))]


def dmi(high, low, close, n: int = 14, smooth: int = 14) -> Tuple[Series, Series, Series]:
    """+DI, -DI, ADX (Wilder) - TradingView ``ta.dmi(n, smooth)`` bilan bir xil ta'rif."""
    L = len(close)
    plus_dm, minus_dm = [0.0] * L, [0.0] * L
    for i in range(1, L):
        up, down = high[i] - high[i - 1], low[i - 1] - low[i]
        plus_dm[i] = up if up > down and up > 0 else 0.0
        minus_dm[i] = down if down > up and down > 0 else 0.0
    tr = rma(true_range(high, low, close), n)
    p, m = rma(plus_dm, n), rma(minus_dm, n)
    pdi: Series = [None] * L
    mdi: Series = [None] * L
    dx: List[float] = []
    dx_idx = []
    for i in range(L):
        if tr[i] and p[i] is not None and m[i] is not None:
            pdi[i], mdi[i] = 100 * p[i] / tr[i], 100 * m[i] / tr[i]
            s = pdi[i] + mdi[i]
            dx.append(100 * abs(pdi[i] - mdi[i]) / s if s else 0.0)
            dx_idx.append(i)
    adx_part = rma(dx, smooth)
    adx: Series = [None] * L
    for k, i in enumerate(dx_idx):
        adx[i] = adx_part[k]
    return pdi, mdi, adx


def percent_rank(x: Sequence[Optional[float]], n: int = 100) -> Series:
    """Oxirgi n qiymat ichida joriy qiymatdan kichik yoki teng bo'lganlar ulushi, % (ta.percentrank kabi)."""
    out: Series = [None] * len(x)
    for i in range(n, len(x)):
        cur = x[i]
        win = [v for v in x[i - n:i] if v is not None]
        if cur is None or not win:
            continue
        out[i] = 100.0 * sum(1 for v in win if v <= cur) / len(win)
    return out
