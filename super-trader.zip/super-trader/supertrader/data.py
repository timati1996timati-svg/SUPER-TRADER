"""Bozor ma'lumotlari: Yahoo Finance (aksiyalar), Binance (kripto), CSV, sintetik.

Manbalar: day-trader-skill (Yahoo v8 chart, query2 -> query1 zaxira),
binance-trader (ommaviy /api/v3/klines). Kalit kerak emas.
"""

import csv
import datetime as _dt
import gzip
import json
import math
import random
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import List, Optional

UA = "Mozilla/5.0 (SuperTrader; +https://github.com)"
CRYPTO_QUOTES = ("USDT", "USDC", "BUSD", "FDUSD", "BTC", "ETH", "BNB", "TRY", "EUR")


@dataclass
class Bar:
    t: int          # ochilish vaqti, UTC epoch soniya
    o: float
    h: float
    l: float
    c: float
    v: float = 0.0

    @property
    def dt(self) -> _dt.datetime:
        return _dt.datetime.fromtimestamp(self.t, _dt.timezone.utc)


class DataError(Exception):
    pass


def _get(url: str, timeout: int = 20) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read()
        if r.headers.get("Content-Encoding") == "gzip":
            data = gzip.decompress(data)
        return data


def is_crypto(symbol: str) -> bool:
    s = symbol.upper()
    return any(s.endswith(q) and len(s) > len(q) + 1 for q in CRYPTO_QUOTES) and "-" not in s and "." not in s


# ---------------------------------------------------------------- Yahoo
YAHOO_HOSTS = ("query2.finance.yahoo.com", "query1.finance.yahoo.com")


def parse_yahoo_chart(doc: dict) -> List[Bar]:
    try:
        res = doc["chart"]["result"][0]
    except (KeyError, IndexError, TypeError):
        err = (doc.get("chart") or {}).get("error") if isinstance(doc, dict) else None
        raise DataError(f"Yahoo javobi bo'sh: {err}")
    ts = res.get("timestamp") or []
    q = res["indicators"]["quote"][0]
    bars = []
    for i, t in enumerate(ts):
        o, h, l, c = q["open"][i], q["high"][i], q["low"][i], q["close"][i]
        if None in (o, h, l, c):
            continue
        bars.append(Bar(int(t), float(o), float(h), float(l), float(c), float(q.get("volume", [0])[i] or 0)))
    return bars


def fetch_yahoo(symbol: str, interval: str = "1d", range_: str = "2y") -> List[Bar]:
    qs = urllib.parse.urlencode({"range": range_, "interval": interval, "includePrePost": "false"})
    last = None
    for host in YAHOO_HOSTS:
        url = f"https://{host}/v8/finance/chart/{urllib.parse.quote(symbol)}?{qs}"
        try:
            return parse_yahoo_chart(json.loads(_get(url)))
        except urllib.error.HTTPError as e:
            last = e
            if e.code in (429,) or e.code >= 500:
                time.sleep(1)
                continue
            if e.code == 404:
                raise DataError(f"Yahoo: '{symbol}' topilmadi")
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as e:
            last = e
    raise DataError(f"Yahoo'dan olib bo'lmadi: {last}")


# ---------------------------------------------------------------- Binance
BINANCE_HOSTS = ("https://api.binance.com", "https://data-api.binance.vision")
BINANCE_INTERVALS = {"1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d", "3d", "1w", "1M"}


def parse_binance_klines(rows) -> List[Bar]:
    return [Bar(int(r[0]) // 1000, float(r[1]), float(r[2]), float(r[3]), float(r[4]), float(r[5])) for r in rows]


def fetch_binance(symbol: str, interval: str = "1d", limit: int = 1000) -> List[Bar]:
    if interval not in BINANCE_INTERVALS:
        raise DataError(f"Binance interval noto'g'ri: {interval}")
    qs = urllib.parse.urlencode({"symbol": symbol.upper(), "interval": interval, "limit": min(limit, 1000)})
    last = None
    for host in BINANCE_HOSTS:
        try:
            rows = json.loads(_get(f"{host}/api/v3/klines?{qs}"))
            if isinstance(rows, dict):
                raise DataError(f"Binance xatosi: {rows.get('msg')}")
            # oxirgi sham hali yopilmagan bo'lishi mumkin - uni tashlaymiz
            bars = parse_binance_klines(rows)
            return bars[:-1] if len(bars) > 1 else bars
        except urllib.error.HTTPError as e:
            last = e
            if e.code == 400:
                raise DataError(f"Binance: '{symbol}' yoki interval noto'g'ri")
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as e:
            last = e
    raise DataError(f"Binance'dan olib bo'lmadi: {last}")


# ---------------------------------------------------------------- CSV
def load_csv(path: str) -> List[Bar]:
    """Ustunlar: time(epoch yoki ISO), open, high, low, close[, volume]."""
    bars = []
    with open(path, newline="") as f:
        for row in csv.DictReader(f):
            row = {k.strip().lower(): v for k, v in row.items() if k}
            t = row.get("time") or row.get("timestamp") or row.get("date")
            try:
                ts = int(float(t))
                if ts > 10 ** 11:
                    ts //= 1000
            except ValueError:
                d = _dt.datetime.fromisoformat(t.replace("Z", "+00:00"))
                if d.tzinfo is None:
                    d = d.replace(tzinfo=_dt.timezone.utc)
                ts = int(d.timestamp())
            bars.append(Bar(ts, float(row["open"]), float(row["high"]), float(row["low"]),
                            float(row["close"]), float(row.get("volume") or 0)))
    bars.sort(key=lambda b: b.t)
    return bars


def load_yahoo_file(path: str) -> List[Bar]:
    """Saqlangan Yahoo chart JSON (.json yoki .json.gz) - day-trader-skill fixture'lari kabi."""
    opener = gzip.open if path.endswith(".gz") else open
    with opener(path, "rt") as f:
        return parse_yahoo_chart(json.load(f))


def save_csv(bars: List[Bar], path: str) -> None:
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["time", "open", "high", "low", "close", "volume"])
        for b in bars:
            w.writerow([_dt.datetime.fromtimestamp(b.t, _dt.timezone.utc).isoformat(), b.o, b.h, b.l, b.c, b.v])


# ---------------------------------------------------------------- Sintetik
def synthetic(n: int = 750, seed: int = 7, start: float = 100.0, interval_sec: int = 86400,
              start_ts: int = 1640995200, intraday_us: bool = False) -> List[Bar]:
    """Internetsiz sinov uchun rejimli (trend/flat) tasodifiy narxlar.

    ``intraday_us=True``: 5 daqiqalik, 9:30-16:00 Nyu-York (13:30-20:00 UTC) seanslar.
    """
    rnd = random.Random(seed)
    bars: List[Bar] = []
    price = start
    drift, vol, left = 0.0, 0.015, 0
    if intraday_us:
        interval_sec = 300
        vol = 0.0015
    t = start_ts
    day = 0
    while len(bars) < n:
        if left <= 0:
            drift = rnd.choice([-1, 0, 0, 1]) * (0.0012 if not intraday_us else 0.0001)
            vol = (0.01 + rnd.random() * 0.02) if not intraday_us else (0.0008 + rnd.random() * 0.0015)
            left = rnd.randint(40, 160)
        left -= 1
        if intraday_us:
            slot = len(bars) % 78
            if slot == 0:
                d = _dt.date(2026, 1, 5) + _dt.timedelta(days=day)
                while d.weekday() >= 5:
                    day += 1
                    d = _dt.date(2026, 1, 5) + _dt.timedelta(days=day)
                day += 1
                t = int(_dt.datetime(d.year, d.month, d.day, 14, 30, tzinfo=_dt.timezone.utc).timestamp())
                price *= math.exp(rnd.gauss(0, vol * 4))  # tungi bo'shliq
            else:
                t += interval_sec
        o = price
        r = rnd.gauss(drift, vol)
        c = o * math.exp(r)
        h = max(o, c) * (1 + abs(rnd.gauss(0, vol / 2)))
        l = min(o, c) * (1 - abs(rnd.gauss(0, vol / 2)))
        bars.append(Bar(t, round(o, 4), round(h, 4), round(l, 4), round(c, 4), round(1e6 * (0.5 + rnd.random()) * (1 + abs(r) / vol), 0)))
        price = c
        if not intraday_us:
            t += interval_sec
    return bars


def load(symbol: Optional[str] = None, interval: str = "1d", source: str = "auto", csv_path: Optional[str] = None,
         range_: str = "2y", limit: int = 1000, seed: int = 7) -> List[Bar]:
    if csv_path:
        if csv_path.endswith((".json", ".json.gz")):
            return load_yahoo_file(csv_path)
        return load_csv(csv_path)
    if source == "demo" or symbol in (None, "", "DEMO"):
        return synthetic(seed=seed, intraday_us=interval in ("5m",))
    if source == "auto":
        source = "binance" if is_crypto(symbol) else "yahoo"
    if source == "binance":
        return fetch_binance(symbol, interval, limit)
    if source == "yahoo":
        return fetch_yahoo(symbol, interval, range_)
    raise DataError(f"Noma'lum manba: {source}")
