"""HTML hisobot (ctp-futures-trader Django dashboard o'rniga - bitta fayl, server kerak emas)."""

import datetime as dt
import html
from typing import List, Optional

from .backtest import Result

CSS = """
:root{--bg:#0f1420;--card:#171e2e;--fg:#e6e9f0;--mut:#8a93a6;--grn:#22c55e;--red:#ef4444;--acc:#60a5fa;--line:#26304a}
@media (prefers-color-scheme: light){:root{--bg:#f6f7fb;--card:#fff;--fg:#141824;--mut:#5b6476;--line:#e3e6ee}}
*{box-sizing:border-box}body{margin:0;font:14px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:var(--bg);color:var(--fg)}
.wrap{max-width:1100px;margin:0 auto;padding:24px}h1{margin:0 0 4px;font-size:24px}h2{font-size:17px;margin:28px 0 10px}
.mut{color:var(--mut)}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px}
.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:12px 14px}
.k{font-size:12px;color:var(--mut)}.v{font-size:20px;font-weight:600;font-variant-numeric:tabular-nums}
.pos{color:var(--grn)}.neg{color:var(--red)}table{width:100%;border-collapse:collapse;font-variant-numeric:tabular-nums}
th,td{padding:6px 8px;border-bottom:1px solid var(--line);text-align:right;white-space:nowrap}th{color:var(--mut);font-weight:500}
td:first-child,th:first-child,td.l,th.l{text-align:left}.tbl{overflow-x:auto;background:var(--card);border:1px solid var(--line);border-radius:12px}
svg{width:100%;height:auto;display:block}.warn{margin-top:28px;font-size:12px;color:var(--mut)}
"""


def _fmt(v, pct=False):
    if isinstance(v, float):
        if v == float("inf"):
            return "∞"
        s = f"{v:,.2f}"
    else:
        s = f"{v:,}" if isinstance(v, int) else str(v)
    return s + ("%" if pct else "")


def _cls(v):
    return "pos" if isinstance(v, (int, float)) and v > 0 else ("neg" if isinstance(v, (int, float)) and v < 0 else "")


def equity_svg(results: List[Result], bh: Optional[List[float]] = None, w=1000, h=300) -> str:
    series = [(r.strategy, r.equity) for r in results]
    if bh:
        series.append(("sotib-ushlab tur", bh))
    allv = [v for _, s in series for v in s]
    if not allv:
        return ""
    lo, hi = min(allv), max(allv)
    if hi == lo:
        hi = lo + 1
    colors = ["#60a5fa", "#22c55e", "#f59e0b", "#a78bfa", "#f472b6", "#2dd4bf"]
    pad = 40
    parts = [f'<svg viewBox="0 0 {w} {h + 30}" role="img" aria-label="Kapital egri chizig\'i">']
    for k in range(5):
        y = pad / 2 + (h - pad) * k / 4
        val = hi - (hi - lo) * k / 4
        parts.append(f'<line x1="{pad + 30}" x2="{w}" y1="{y:.1f}" y2="{y:.1f}" stroke="currentColor" stroke-opacity=".12"/>')
        parts.append(f'<text x="{pad + 24}" y="{y + 4:.1f}" font-size="11" text-anchor="end" fill="currentColor" fill-opacity=".6">{val:,.0f}</text>')
    for idx, (name, s) in enumerate(series):
        n = len(s)
        if n < 2:
            continue
        step = max(1, n // 800)
        pts = " ".join(f"{pad + 30 + (w - pad - 30) * i / (n - 1):.1f},{pad / 2 + (h - pad) * (hi - s[i]) / (hi - lo):.1f}" for i in range(0, n, step))
        dash = ' stroke-dasharray="4 4"' if name == "sotib-ushlab tur" else ""
        c = "#8a93a6" if dash else colors[idx % len(colors)]
        parts.append(f'<polyline fill="none" stroke="{c}" stroke-width="2"{dash} points="{pts}"/>')
        parts.append(f'<rect x="{pad + 30 + idx * 160}" y="{h + 8}" width="12" height="4" fill="{c}"/>'
                     f'<text x="{pad + 48 + idx * 160}" y="{h + 14}" font-size="12" fill="currentColor">{html.escape(name)}</text>')
    parts.append("</svg>")
    return "".join(parts)


LABELS = [("total_return_pct", "Umumiy daromad", True), ("cagr_pct", "Yillik (CAGR)", True), ("max_drawdown_pct", "Maks. tushish", True),
          ("sharpe", "Sharpe", False), ("win_rate", "Yutuq ulushi", True), ("profit_factor", "Profit factor", False),
          ("trades", "Savdolar", False), ("avg_r", "O'rtacha R", False), ("buy_hold_pct", "Sotib-ushlab tur", True)]


def render(symbol: str, results: List[Result], ranking: List[tuple], bars, mc: Optional[dict] = None, title="SuperTrader hisobot") -> str:
    best = results[0]
    bh = [best.start_equity * b.c / bars[0].o for b in bars] if bars else None
    first = dt.datetime.fromtimestamp(bars[0].t, dt.timezone.utc).strftime("%Y-%m-%d")
    last = dt.datetime.fromtimestamp(bars[-1].t, dt.timezone.utc).strftime("%Y-%m-%d")
    out = [f"<!doctype html><html lang='uz'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
           f"<title>{html.escape(title)} - {html.escape(symbol)}</title><style>{CSS}</style></head><body><div class='wrap'>",
           f"<h1>{html.escape(symbol)} · {html.escape(best.strategy)}</h1>",
           f"<div class='mut'>{first} → {last} · {len(bars)} sham · boshlang'ich kapital ${best.start_equity:,.0f}</div>",
           "<h2>Ko'rsatkichlar (eng yaxshi strategiya)</h2><div class='grid'>"]
    for key, lab, pct in LABELS:
        v = best.metrics.get(key, 0)
        c = _cls(-v if key == "max_drawdown_pct" else v) if key not in ("trades",) else ""
        out.append(f"<div class='card'><div class='k'>{lab}</div><div class='v {c}'>{_fmt(v, pct)}</div></div>")
    out.append("</div><h2>Kapital egri chizig'i</h2><div class='card'>" + equity_svg(results, bh) + "</div>")
    if ranking:
        out.append("<h2>Reyting (agentlar musobaqasi)</h2><div class='tbl'><table><tr><th>#</th><th class='l'>Strategiya</th><th>Ball</th><th>Daromad</th><th>Maks. tushish</th><th>Sharpe</th><th>Savdolar</th><th>Yutuq %</th><th>PF</th></tr>")
        for n, (name, sc, m) in enumerate(ranking, 1):
            out.append(f"<tr><td>{n}</td><td class='l'>{html.escape(name)}</td><td>{'—' if sc <= -999 else f'{sc:.2f}'}</td><td class='{_cls(m['total_return_pct'])}'>{m['total_return_pct']:.2f}%</td>"
                       f"<td>{m['max_drawdown_pct']:.2f}%</td><td>{m['sharpe']:.2f}</td><td>{m['trades']}</td><td>{m['win_rate']:.1f}%</td><td>{_fmt(m['profit_factor'])}</td></tr>")
        out.append("</table></div>")
    if mc:
        out.append("<h2>Monte-Karlo (savdolar tartibi tasodifiy, {runs} marta)</h2><div class='grid'>".format(**mc))
        for k, lab in [("median_final", "Median kapital"), ("p05_final", "Yomon 5%"), ("p95_final", "Yaxshi 5%"),
                       ("prob_loss_pct", "Zarar ehtimoli %"), ("p95_dd_pct", "95% tushish")]:
            out.append(f"<div class='card'><div class='k'>{lab}</div><div class='v'>{_fmt(mc[k])}</div></div>")
        out.append("</div>")
    if best.open_position:
        op = best.open_position
        out.append(f"<h2>Hozir ochiq pozitsiya</h2><div class='card'>{op['side']} {op['qty']:g} @ {op['entry']:.4f} · stop {op['stop']:.4f}"
                   f" · maqsad {op['target'] if op['target'] is None else round(op['target'], 4)} · {op['since']} dan</div>")
    out.append("<h2>Savdolar</h2><div class='tbl'><table><tr><th>Kirish</th><th>Chiqish</th><th>Yo'nalish</th><th>Narx</th><th>Chiqish narxi</th><th>Miqdor</th><th>Foyda $</th><th>R</th><th class='l'>Sabab</th></tr>")
    for t in reversed(best.trades[-300:]):
        d = t.to_dict()
        out.append(f"<tr><td>{d['entry_time']}</td><td>{d['exit_time']}</td><td>{t.side}</td><td>{t.entry:,.4f}</td><td>{t.exit:,.4f}</td>"
                   f"<td>{t.qty:g}</td><td class='{_cls(t.pnl)}'>{t.pnl:,.2f}</td><td class='{_cls(t.r)}'>{t.r:+.2f}</td><td class='l'>{html.escape(t.reason_out)}</td></tr>")
    out.append("</table></div><p class='warn'>Bu moliyaviy maslahat emas. O'tmishdagi natija kelajakni kafolatlamaydi. "
               "Avval qog'oz savdoda sinab ko'ring.</p></div></body></html>")
    return "".join(out)


RATING_COLORS = {"SOTIB OL": "#16a34a", "KO'PAYTIR": "#65a30d", "KUT": "#64748b", "KAMAYTIR": "#ea580c", "SOT": "#dc2626"}


def price_svg(bars, d, n=160, w=1000, h=320) -> str:
    from . import indicators as ta
    c = [b.c for b in bars]
    s50, s200 = ta.sma(c, 50), ta.sma(c, 200)
    up, mid, lo = ta.bollinger(c, 20, 2.0)
    k0 = max(0, len(bars) - n)
    seg = bars[k0:]
    vals = [b.h for b in seg] + [b.l for b in seg]
    for extra in (d.plan.stop, d.plan.target):
        if extra is not None:
            vals.append(extra)
    hi, lo_v = max(vals), min(vals)
    pad = (hi - lo_v) * 0.05 or 1
    hi, lo_v = hi + pad, lo_v - pad
    left = 60
    X = lambda k: left + (w - left - 10) * k / max(1, len(seg) - 1)
    Y = lambda v: 10 + (h - 20) * (hi - v) / (hi - lo_v)
    out = [f'<svg viewBox="0 0 {w} {h}" role="img" aria-label="Narx grafigi">']
    for q in range(5):
        v = hi - (hi - lo_v) * q / 4
        out.append(f'<line x1="{left}" x2="{w}" y1="{Y(v):.1f}" y2="{Y(v):.1f}" stroke="currentColor" stroke-opacity=".1"/>'
                   f'<text x="{left - 6}" y="{Y(v) + 4:.1f}" font-size="11" text-anchor="end" fill="currentColor" fill-opacity=".6">{v:,.2f}</text>')
    bw = max(1.0, (w - left) / len(seg) * 0.6)
    for k, b in enumerate(seg):
        col = "#16a34a" if b.c >= b.o else "#dc2626"
        out.append(f'<line x1="{X(k):.1f}" x2="{X(k):.1f}" y1="{Y(b.h):.1f}" y2="{Y(b.l):.1f}" stroke="{col}"/>'
                   f'<rect x="{X(k) - bw / 2:.1f}" y="{Y(max(b.o, b.c)):.1f}" width="{bw:.1f}" height="{max(1, abs(Y(b.o) - Y(b.c))):.1f}" fill="{col}"/>')

    def line(series, color, dash=""):
        pts = [f"{X(k):.1f},{Y(series[k0 + k]):.1f}" for k in range(len(seg)) if series[k0 + k] is not None]
        if len(pts) > 1:
            out.append(f'<polyline fill="none" stroke="{color}" stroke-width="1.6"{dash} points="{" ".join(pts)}"/>')
    line(s50, "#3b82f6")
    line(s200, "#f59e0b")
    line(up, "#94a3b8", ' stroke-dasharray="3 3"')
    line(lo, "#94a3b8", ' stroke-dasharray="3 3"')
    for val, col, lab in ((d.plan.stop, "#dc2626", "stop"), (d.plan.target, "#16a34a", "maqsad")):
        if val is not None:
            out.append(f'<line x1="{left}" x2="{w}" y1="{Y(val):.1f}" y2="{Y(val):.1f}" stroke="{col}" stroke-dasharray="6 4"/>'
                       f'<rect x="{left + 2}" y="{Y(val) - 17:.1f}" width="{len(lab) * 7 + 60}" height="15" rx="3" fill="{col}"/>'
                       f'<text x="{left + 6}" y="{Y(val) - 6:.1f}" font-size="11" fill="#fff">{lab} {val:,.2f}</text>')
    out.append("</svg>")
    return "".join(out)


def render_decision(d, bars) -> str:
    when = dt.datetime.fromtimestamp(d.time, dt.timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    col = RATING_COLORS.get(d.rating, "#64748b")
    pos = (d.score + 100) / 2
    e = html.escape
    out = [f"<!doctype html><html lang='uz'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
           f"<title>{e(d.symbol)} - Agentlar firmasi</title><style>{CSS}"
           ".badge{display:inline-block;padding:6px 14px;border-radius:999px;color:#fff;font-weight:700;font-size:18px}"
           ".gauge{position:relative;height:10px;border-radius:5px;background:linear-gradient(90deg,#dc2626,#ea580c,#64748b,#65a30d,#16a34a);margin:14px 0 4px}"
           ".gauge i{position:absolute;top:-5px;width:4px;height:20px;background:var(--fg);border-radius:2px}"
           ".two{display:grid;grid-template-columns:1fr 1fr;gap:10px}@media(max-width:700px){.two{grid-template-columns:1fr}}"
           "ul{margin:6px 0;padding-left:18px}li{margin:3px 0}</style></head><body><div class='wrap'>",
           f"<h1>{e(d.symbol)} · Agentlar firmasi</h1><div class='mut'>{when} · yopilish {d.close:,.4f} · rejim: {e(d.regime)}</div>",
           f"<div class='card' style='margin-top:16px'><span class='badge' style='background:{col}'>{e(d.rating)}</span> "
           f"<span class='mut'>({d.rating_en}) · ball {d.score:+.0f}/100</span>"
           f"<div class='gauge'><i style='left:calc({pos:.1f}% - 2px)'></i></div>"
           "<div class='mut' style='display:flex;justify-content:space-between;font-size:12px'><span>SOT</span><span>KAMAYTIR</span><span>KUT</span><span>KO'PAYTIR</span><span>SOTIB OL</span></div></div>",
           "<h2>Narx grafigi</h2><div class='card'>" + price_svg(bars, d) + "</div>",
           "<h2>1. Tahlilchilar</h2><div class='tbl'><table><tr><th class='l'>Tahlilchi</th><th>Ball</th><th class='l'>Dalillar</th></tr>"]
    for r in d.reports:
        pts = "<br>".join(("▲ " if p.weight > 0 else "▼ " if p.weight < 0 else "• ") + e(p.text) for p in r.points) or "-"
        out.append(f"<tr><td>{e(r.analyst)}</td><td class='{_cls(r.score)}'>{r.score:+.0f}</td><td class='l' style='white-space:normal'>{pts}</td></tr>")
    out.append("</table></div><h2>2. Bahs</h2><div class='two'>")
    for title, pts, c in (("🐂 Buqa tadqiqotchi", d.bull, "pos"), ("🐻 Ayiq tadqiqotchi", d.bear, "neg")):
        tot = sum(p.weight for p in pts)
        out.append(f"<div class='card'><b>{title}</b> <span class='{c}'>{tot:+.0f}</span><ul>"
                   + "".join(f"<li>{e(p.text)}</li>" for p in pts) + "</ul></div>")
    out.append("</div>")
    pl = d.plan
    plan_txt = (f"{pl.action} ~{pl.entry:,.4f} · stop {pl.stop:,.4f} · maqsad {pl.target:,.4f} ({pl.reward_r:.1f}R)"
                if pl.stop is not None else (f"{pl.action}: yangi pozitsiya ochilmaydi" if pl.action == "SELL" else "KUT: aniq ustunlik yo'q"))
    out.append(f"<h2>3. Treyder rejasi</h2><div class='card'>{e(plan_txt)}</div><h2>4. Risk jamoasi</h2><div class='grid'>")
    for v in d.risk_views:
        out.append(f"<div class='card'><div class='k'>{e(v.who)}</div><div class='v'>x{v.multiplier}</div><div class='mut'>{e(v.reason)}</div></div>")
    out.append(f"</div><h2>5. Portfel menejeri</h2><div class='card'>Risk ko'paytiruvchi <b>x{d.final_multiplier}</b>"
               + (f" · hajm <b>{d.qty:g}</b> · stopda zarar <b>${d.max_loss:,.2f}</b>" if d.qty else "")
               + "".join(f"<div class='mut'>! {e(n)}</div>" for n in d.notes) + "</div>")
    if d.odds:
        o = d.odds
        out.append(f"<h2>6. Vaqt mashinasi</h2><div class='grid'>"
                   f"<div class='card'><div class='k'>Maqsad birinchi</div><div class='v pos'>{o['target_pct']}%</div></div>"
                   f"<div class='card'><div class='k'>Stop birinchi</div><div class='v neg'>{o['stop_pct']}%</div></div>"
                   f"<div class='card'><div class='k'>Hech biri</div><div class='v'>{o['neither_pct']}%</div></div>"
                   f"<div class='card'><div class='k'>O'rtacha R</div><div class='v'>{o['avg_r']:+.2f}</div></div></div>"
                   f"<div class='mut' style='margin-top:6px'>{e(o['verdict'])} · {o['replays']:,} simulyatsiya, {o['horizon']} sham</div>")
    if d.llm:
        L = d.llm
        out.append(f"<h2>7. Claude bahsi</h2><div class='two'><div class='card'><b>🐂 Buqa</b><p>{e(L['bull_case'])}</p></div>"
                   f"<div class='card'><b>🐻 Ayiq</b><p>{e(L['bear_case'])}</p></div></div>"
                   f"<div class='card' style='margin-top:10px'><b>Claude reytingi: {e(L['rating'])}</b> ({L['confidence']}%) · g'olib: {e(L['debate_winner'])}"
                   f"<p>{e(L['summary'])}</p><ul>" + "".join(f"<li>{e(k)}</li>" for k in L.get("key_risks", [])) + "</ul></div>")
    out.append("<p class='warn'>Bu moliyaviy maslahat emas. Agentlar qoidalar asosida ishlaydi; natijani "
               "<code>supertrader calibrate</code> bilan tarixda tekshiring.</p></div></body></html>")
    return "".join(out)
