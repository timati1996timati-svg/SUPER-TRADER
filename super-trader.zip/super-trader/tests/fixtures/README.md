# Test ma'lumotlari

`TSLA-60d5m.json.gz` - Tesla (TSLA) aksiyasining 60 kunlik 5 daqiqalik shamlari (Yahoo Finance
chart JSON formatida). [day-trader-skill](https://github.com/Jakeschincariol/day-trader-skill)
loyihasidan olingan (MIT litsenziyasi, Copyright (c) 2026 Jake Schincariol). Testlar shu
ma'lumotda ORB strategiyasi asl loyihadagi 19-oktabr 2026 misolini aynan takrorlashini tekshiradi.
