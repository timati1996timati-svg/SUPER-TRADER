import datetime as dt
import io
import os
import sys
import tempfile
import unittest
from contextlib import redirect_stdout

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from supertrader import backtest as bt  # noqa: E402
from supertrader import indicators as ta  # noqa: E402
from supertrader import montecarlo as mc  # noqa: E402
from supertrader.broker import BinanceBroker, PaperBroker  # noqa: E402
from supertrader.cli import main  # noqa: E402
from supertrader.data import Bar, load_yahoo_file, synthetic  # noqa: E402
from supertrader.risk import RiskConfig, check_trade, size_position  # noqa: E402
from supertrader.strategies import REGISTRY, Signal, Strategy, make  # noqa: E402

TSLA = os.path.join(ROOT, "tests", "fixtures", "TSLA-60d5m.json.gz")


class Indicators(unittest.TestCase):
    def test_sma_ema(self):
        x = [1, 2, 3, 4, 5, 6]
        self.assertEqual(ta.sma(x, 3), [None, None, 2, 3, 4, 5])
        e = ta.ema(x, 3)
        self.assertEqual(e[2], 2)
        self.assertAlmostEqual(e[3], 3.0)

    def test_rsi_bounds(self):
        up = [float(i) for i in range(30)]
        self.assertEqual(ta.rsi(up)[-1], 100.0)
        r = ta.rsi([b.c for b in synthetic(300)])
        self.assertTrue(all(0 <= v <= 100 for v in r if v is not None))

    def test_macd_matches_definition(self):
        c = [b.c for b in synthetic(200, seed=3)]
        line, sig, hist = ta.macd(c)
        f, s = ta.ema(c, 12), ta.ema(c, 26)
        self.assertAlmostEqual(line[-1], f[-1] - s[-1])
        self.assertAlmostEqual(hist[-1], line[-1] - sig[-1])
        self.assertIsNone(sig[30])
        self.assertIsNotNone(sig[33])

    def test_bollinger(self):
        up, mid, lo = ta.bollinger([10.0] * 25)
        self.assertEqual((up[-1], mid[-1], lo[-1]), (10.0, 10.0, 10.0))


class Risk(unittest.TestCase):
    def test_day_trader_example(self):
        # day-trader-skill README: $5,000 hisob, $50 maks. zarar -> 8 dona TSLA
        cfg = RiskConfig(account=5000, max_loss_usd=50, risk_pct=100, max_position_pct=100)
        s = size_position(cfg, 364.18, 358.32, 370.04)
        self.assertEqual(s.qty, 8)
        self.assertAlmostEqual(s.max_loss, 46.88, places=2)
        self.assertAlmostEqual(s.notional, 2913.44, places=2)
        self.assertTrue(check_trade(cfg, s).ok)

    def test_block_reasons(self):
        cfg = RiskConfig(account=1000, min_reward_risk=2, max_trades_per_day=1)
        s = size_position(cfg, 100, 99, 100.5)
        v = check_trade(cfg, s, trades_today=1)
        self.assertFalse(v.ok)
        self.assertEqual(len(v.reasons), 2)

    def test_fractional_crypto(self):
        cfg = RiskConfig(account=1000, risk_pct=1, fractional=True, max_position_pct=100)
        s = size_position(cfg, 60000, 59000)
        self.assertAlmostEqual(s.qty, 0.01, places=6)


class _Once(Strategy):
    name = "once"
    params = dict(at=5, stop=95.0, target=110.0)

    def entry(self, i):
        return Signal("LONG", self.p["stop"], self.p["target"]) if i == self.p["at"] else None


def _bars(rows):
    return [Bar(1700000000 + 86400 * k, *r, 1000) for k, r in enumerate(rows)]


class Engine(unittest.TestCase):
    def test_fill_next_open_and_stop_first(self):
        rows = [(100, 101, 99, 100)] * 6 + [(102, 103, 101, 102), (102, 111, 94, 100)] + [(100, 101, 99, 100)] * 3
        cfg = RiskConfig(account=10_000, fee_pct=0, slippage_pct=0, max_position_pct=100)
        r = bt.run(_Once(), _bars(rows), cfg)
        self.assertEqual(len(r.trades), 1)
        t = r.trades[0]
        self.assertEqual(t.entry, 102)          # signal bar 5 -> bar 6 ochilishi
        self.assertEqual(t.reason_out, "stop")  # bar 7 ham stop ham maqsadga tegdi -> stop
        self.assertAlmostEqual(t.r, -1.0)

    def test_gap_through_stop_cancels(self):
        rows = [(100, 101, 99, 100)] * 6 + [(90, 91, 89, 90)] * 4
        r = bt.run(_Once(), _bars(rows), RiskConfig(fee_pct=0, slippage_pct=0))
        self.assertEqual(r.trades, [])

    def test_all_strategies_run(self):
        bars = synthetic(600, seed=5)
        for name in ("bollinger", "donchian", "ema_cross", "ensemble"):
            res = bt.run(make(name), bars, RiskConfig())
            self.assertEqual(len(res.equity), len(bars))
            self.assertIn("sharpe", res.metrics)


@unittest.skipUnless(os.path.exists(TSLA), "TSLA fixture yo'q")
class RealTSLA(unittest.TestCase):
    def test_orb_matches_reel(self):
        bars = load_yahoo_file(TSLA)
        s = make("orb")
        s.prepare(bars)
        day = dt.date(2026, 10, 19)
        hi, lo, _, _ = s.range[day]
        self.assertAlmostEqual(hi, 362.18, places=2)
        self.assertAlmostEqual(lo, 354.47, places=2)
        sig = next(x for x in (s.entry(i) for i in range(len(bars)) if s.day[i] == day) if x)
        self.assertAlmostEqual(sig.stop, 358.32, places=1)
        self.assertAlmostEqual(sig.target, 370.03, places=1)


class MonteCarlo(unittest.TestCase):
    def test_deterministic(self):
        bars = synthetic(400)
        a = mc.replay_plan(bars, "LONG", 100, 95, 105, replays=2000, seed=1)
        b = mc.replay_plan(bars, "LONG", 100, 95, 105, replays=2000, seed=1)
        self.assertEqual(a, b)
        self.assertAlmostEqual(a["target_pct"] + a["stop_pct"] + a["neither_pct"], 100, delta=0.2)

    def test_verdict(self):
        self.assertIn("Tanga", mc.verdict(0.52, 1.0))
        self.assertIn("Kuchli maqsad", mc.verdict(0.7, 1.0))


class Brokers(unittest.TestCase):
    def test_paper_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            pb = PaperBroker(os.path.join(d, "p.json"), cash=1000, fee_pct=0)
            pb.open("AAPL", "LONG", 2, 100, stop=95, target=110)
            self.assertEqual(pb.cash, 800)
            ev = pb.check_brackets({"AAPL": 111})
            self.assertEqual(ev[0][1], "maqsad")
            self.assertAlmostEqual(pb.cash, 1022)
            self.assertAlmostEqual(PaperBroker(os.path.join(d, "p.json")).cash, 1022)

    def test_binance_signature(self):
        # Binance rasmiy hujjatidagi namuna
        b = BinanceBroker("k", "NhqPtmdSJYdKjVHjA7PZj4Mge3R5YNiP1e3UZjInClVN65XAbvqqM6A7H5fATj0j")
        q = b.sign(dict(symbol="LTCBTC", side="BUY", type="LIMIT", timeInForce="GTC", quantity=1, price=0.1,
                        recvWindow=5000, timestamp=1499827319559))
        self.assertTrue(q.endswith("signature=c8db56825ae71d6d79447849e617115f4a920fa2acdcab2b053c4b2838bd6b71"))
        self.assertEqual(b.base, BinanceBroker.TESTNET)


class Cli(unittest.TestCase):
    def test_demo_report(self):
        with tempfile.TemporaryDirectory() as d:
            out = os.path.join(d, "r.html")
            with redirect_stdout(io.StringIO()):
                self.assertEqual(main(["demo", "--report", out]), 0)
            with open(out) as f:
                html = f.read()
            self.assertIn("<svg", html)
            self.assertIn("Reyting", html)

    def test_registry(self):
        self.assertEqual(set(REGISTRY), {"bollinger", "donchian", "ema_cross", "orb", "ensemble", "firm"})


if __name__ == "__main__":
    unittest.main()
