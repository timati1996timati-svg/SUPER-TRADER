"""Pine Script v6 uchun oddiy statik tekshiruvchi (TradingView kompilyatori o'rnini bosmaydi).

Tekshiradi: versiya qatori, tab yo'qligi, 4 bo'shliqli chekinish, har qatorda qavs va
qo'shtirnoq muvozanati, e'lon qilinmagan yoki e'londan oldin ishlatilgan nomlar,
global darajada takroriy e'lon, ``:=`` faqat mavjud nomga.

    python3 tests/pine_lint.py tradingview/*.pine
"""

import re
import sys

KEYWORDS = {
    "and", "or", "not", "if", "else", "switch", "var", "varip", "for", "to", "by", "in", "while", "true", "false",
    "na", "float", "int", "bool", "string", "color", "table", "line", "label", "box", "series", "simple", "const",
    "import", "export", "method", "type", "continue", "break", "linefill", "polyline",
}
BUILTIN_VARS = {
    "open", "high", "low", "close", "volume", "time", "time_close", "bar_index", "hl2", "hlc3", "ohlc4", "hlcc4",
    "last_bar_index", "timenow", "year", "month", "dayofmonth", "dayofweek", "hour", "minute", "second",
}
BUILTIN_NS = {
    "ta", "math", "str", "input", "color", "plot", "shape", "location", "size", "position", "text", "table",
    "label", "line", "strategy", "syminfo", "barstate", "timeframe", "format", "alert", "array", "map", "request",
    "currency", "display", "xloc", "yloc", "extend", "session", "order", "adjustment", "barmerge", "hline",
    "font", "chart", "dividends", "earnings", "splits", "matrix", "runtime", "log", "ticker", "box", "polyline",
}
BUILTIN_FUNCS = {
    "plot", "plotshape", "plotchar", "plotarrow", "plotcandle", "plotbar", "fill", "bgcolor", "barcolor", "hline",
    "indicator", "strategy", "library", "alert", "alertcondition", "nz", "na", "fixnan", "max_bars_back",
    "timestamp", "time", "time_close", "float", "int", "bool", "string", "color", "dayofweek", "year", "month",
}

TOKEN = re.compile(r"[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*")


def strip_strings_comments(line: str):
    out, i, in_s, q = [], 0, False, ""
    while i < len(line):
        ch = line[i]
        if in_s:
            if ch == "\\":
                i += 2
                continue
            if ch == q:
                in_s = False
            out.append(" ")
        elif ch in "\"'":
            in_s, q = True, ch
            out.append(" ")
        elif line.startswith("//", i):
            break
        else:
            out.append(ch)
        i += 1
    return "".join(out), in_s


def lint(path: str):
    errors = []
    with open(path, encoding="utf-8") as fh:
        lines = fh.read().split("\n")
    if not any(l.strip() == "//@version=6" for l in lines):
        errors.append("//@version=6 qatori yo'q")
    declared = {}           # name -> line
    global_decl = {}
    func_stack = []         # (indent, params)
    for n, raw in enumerate(lines, 1):
        if "\t" in raw:
            errors.append(f"{n}: tab belgisi")
        code, open_str = strip_strings_comments(raw)
        indent = len(code) - len(code.lstrip(" "))
        code = re.sub(r"#[0-9a-fA-F]{6,8}\b", " ", code)          # rang literallari
        code = re.sub(r"\b\d+(?:\.\d+)?(?:e[+-]?\d+)?\b", " ", code)  # sonlar
        if open_str:
            errors.append(f"{n}: yopilmagan qo'shtirnoq")
        if not code.strip():
            continue
        if indent % 4:
            errors.append(f"{n}: chekinish 4 ga karrali emas ({indent})")
        for a, b in ("()", "[]"):
            if code.count(a) != code.count(b):
                errors.append(f"{n}: '{a}{b}' qavslar muvozanati buzilgan")
        while func_stack and indent <= func_stack[-1][0]:
            func_stack.pop()
        s = code.strip()
        local_params = set().union(*[p for _, p in func_stack]) if func_stack else set()
        # funksiya ta'rifi
        m = re.match(r"^([A-Za-z_]\w*)\s*\((.*)\)\s*=>", s)
        if m:
            name = m.group(1)
            params = set()
            for part in m.group(2).split(","):
                toks = part.strip().split()
                if toks:
                    params.add(toks[-1].split("=")[0])
            declared.setdefault(name, n)
            func_stack.append((indent, params))
            continue
        # e'lonlar
        targets = []
        m = re.match(r"^(?:var\s+|varip\s+)?(?:(?:float|int|bool|string|color|table|line|label)\s+)?([A-Za-z_]\w*)\s*=(?!=)", s)
        mt = re.match(r"^\[([^\]]+)\]\s*=(?!=)", s)
        mr = re.match(r"^([A-Za-z_]\w*)\s*(?::=|\+=|-=|\*=|/=)", s)
        rhs = s
        if mt:
            targets = [t.strip() for t in mt.group(1).split(",")]
            rhs = s[mt.end():]
        elif m and not s.startswith(("if ", "else", "switch")):
            targets = [m.group(1)]
            rhs = s[m.end():]
        elif mr:
            if mr.group(1) not in declared and mr.group(1) not in local_params:
                errors.append(f"{n}: '{mr.group(1)}' e'lon qilinmagan, lekin ':=' bilan o'zgartirilyapti")
            rhs = s[mr.end():]
        # ishlatilgan nomlar
        for tm in TOKEN.finditer(rhs):
            tok = tm.group(0)
            after = rhs[tm.end():].lstrip()
            if after.startswith("=") and not after.startswith("=="):
                continue  # nomli argument
            if after.startswith("=>"):
                continue
            head = tok.split(".")[0]
            if "." in tok and head in BUILTIN_NS:
                continue
            if head in KEYWORDS or head in BUILTIN_VARS or head in local_params:
                continue
            if after.startswith("(") and head in BUILTIN_FUNCS:
                continue
            if head not in declared:
                errors.append(f"{n}: '{head}' e'lon qilinmasdan ishlatilgan")
        for t in targets:
            if indent == 0 and not func_stack:
                if t in global_decl:
                    errors.append(f"{n}: '{t}' qayta e'lon qilingan (avval {global_decl[t]}-qatorda)")
                global_decl[t] = n
            declared.setdefault(t, n)
    return errors


if __name__ == "__main__":
    bad = 0
    for p in sys.argv[1:]:
        errs = lint(p)
        print(f"{p}: {'OK' if not errs else str(len(errs)) + ' xato'}")
        for e in errs:
            print("   ", e)
        bad += len(errs)
    sys.exit(1 if bad else 0)
