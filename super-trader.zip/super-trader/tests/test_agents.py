import json
import os
import sys
import tempfile
import types
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "tradingview"))
sys.path.insert(0, os.path.join(ROOT, "tests"))

from supertrader import backtest as bt  # noqa: E402
from supertrader import indicators as ta  # noqa: E402
from supertrader.agents import RATINGS, Features, analyze, calibrate, decide, rating_of  # noqa: E402
from supertrader.agents import memory as M  # noqa: E402
from supertrader.data import Bar, load_yahoo_file, synthetic  # noqa: E402
from supertrader.risk import RiskConfig  # noqa: E402
from supertrader.strategies import make  # noqa: E402

TSLA = os.path.join(ROOT, "tests", "fixtures", "TSLA-60d5m.json.gz")
PINE = os.path.join(ROOT, "tradingview", "SuperTrader_Pro.pine")
PINE_STRAT = os.path.join(ROOT, "tradingview", "SuperTrader_Pro_Strategy.pine")


class NewIndicators(unittest.TestCase):
    def test_dmi_trend(self):
        n = 120
        h = [100 + i + 1 for i in range(n)]
        l = [100 + i - 1 for i in range(n)]
        c = [100 + i for i in range(n)]
        p, m, adx = ta.dmi(h, l, c)
        self.assertGreater(p[-1], m[-1])
        self.assertGreater(adx[-1], 50)

    def test_percent_rank(self):
        x = list(range(200))
        self.assertEqual(ta.percent_rank(x, 100)[-1], 100.0)

    def test_vwma_equal_volume_is_sma(self):
        c = [float(i) for i in range(1, 50)]
        self.assertAlmostEqual(ta.vwma(c, [1.0] * len(c), 20)[-1], ta.sma(c, 20)[-1])


class Firm(unittest.TestCase):
    def test_rating_thresholds(self):
        self.assertEqual([rating_of(s) for s in (100, 40, 39, 15, 0, -14.9, -15, -39, -40, -100)],
                         ["SOTIB OL", "SOTIB OL", "KO'PAYTIR", "KO'PAYTIR", "KUT", "KUT", "KAMAYTIR", "KAMAYTIR", "SOT", "SOT"])

    def test_uptrend_is_bullish(self):
        bars = [Bar(1700000000 + 86400 * i, 100 * 1.004 ** i, 100 * 1.004 ** i * 1.01, 100 * 1.004 ** i * 0.995,
                    100 * 1.004 ** i * 1.003, 1000 + (i % 7) * 50) for i in range(300)]
        d = analyze(bars, "UP", odds=False)
        self.assertIn(d.rating, RATINGS[:2])
        self.assertEqual(d.plan.action, "BUY")
        self.assertLess(d.plan.stop, d.close)
        self.assertGreater(d.qty, 0)

    def test_downtrend_spot_does_not_short(self):
        bars = [Bar(1700000000 + 86400 * i, 100 * 0.996 ** i, 100 * 0.996 ** i * 1.004, 100 * 0.996 ** i * 0.99,
                    100 * 0.996 ** i * 0.997, 1000) for i in range(300)]
        d = analyze(bars, "DOWN", odds=False)
        self.assertIn(d.rating, RATINGS[3:])
        self.assertEqual(d.plan.action, "SELL")
        self.assertIsNone(d.plan.stop)
        self.assertEqual(d.final_multiplier, 0)
        d2 = analyze(bars, "DOWN", allow_short=True, odds=False)
        self.assertGreater(d2.plan.stop, d2.close)

    def test_point_in_time(self):
        # i-shamdagi qaror keyingi shamlar o'zgarsa ham o'zgarmasligi kerak (oldinga qaramaslik)
        bars = synthetic(400, seed=4)
        i = 300
        a = decide(Features(bars), i)
        changed = bars[:i + 1] + [Bar(b.t, b.o * 3, b.h * 3, b.l * 3, b.c * 3, b.v) for b in bars[i + 1:]]
        b = decide(Features(changed), i)
        self.assertEqual((a.score, a.rating), (b.score, b.rating))

    def test_score_is_sum_of_analysts(self):
        d = analyze(synthetic(400, seed=2), odds=False)
        self.assertAlmostEqual(d.score, max(-100, min(100, sum(r.score for r in d.reports))), places=6)
        self.assertEqual(len(d.reports), 6)

    def test_firm_strategy_backtest(self):
        r = bt.run(make("firm"), synthetic(700, seed=3), RiskConfig())
        self.assertIn("sharpe", r.metrics)

    def test_calibrate_counts(self):
        bars = synthetic(500, seed=1)
        res = calibrate(bars, horizon=10, start=200)
        self.assertEqual(sum(g["n"] for g in res.values()), 500 - 10 - 1 - 200)

    @unittest.skipUnless(os.path.exists(TSLA), "fixture yo'q")
    def test_real_tsla(self):
        d = analyze(load_yahoo_file(TSLA), "TSLA", odds=False)
        self.assertIn(d.rating, RATINGS)


class Memory(unittest.TestCase):
    def test_store_dedupe_and_reflect(self):
        bars = synthetic(300, seed=5)
        with tempfile.TemporaryDirectory() as tmp:
            log = os.path.join(tmp, "d.jsonl")
            d = decide(Features(bars), 250, "X")
            self.assertTrue(M.store(d, log))
            self.assertFalse(M.store(d, log))
            res = M.reflect(M.load(log), {"X": bars}, horizon=10)
            o = res["rows"][0]["outcome"]
            self.assertAlmostEqual(o["entry_close"], bars[251].c)
            self.assertAlmostEqual(o["exit_close"], bars[261].c)
            d2 = decide(Features(bars), 295, "X")
            M.store(d2, log)
            res = M.reflect(M.load(log), {"X": bars}, horizon=10)
            self.assertIsNone(res["rows"][1]["outcome"])  # hali erta


class FakeAnthropic(types.ModuleType):
    """anthropic SDK o'rniga: so'rov shaklini tekshiradi, tayyor JSON qaytaradi."""

    class APIStatusError(Exception):
        status_code = 500
        message = "x"

    class AuthenticationError(APIStatusError):
        pass

    class RateLimitError(APIStatusError):
        pass

    class APIConnectionError(Exception):
        pass

    def __init__(self, reply, stop="end_turn"):
        super().__init__("anthropic")
        self.calls = []
        outer = self

        class Block:
            type = "text"
            text = json.dumps(reply)

        class Resp:
            stop_reason = stop
            content = [Block()]
            model = "claude-opus-5-5"

        class Messages:
            def create(self, **kw):
                outer.calls.append(kw)
                return Resp()

        class Beta:
            messages = Messages()

        class Client:
            beta = Beta()

        self.Anthropic = lambda: Client()


class LLM(unittest.TestCase):
    REPLY = dict(bull_case="b", bear_case="a", debate_winner="buqa", aggressive_view="x", neutral_view="y",
                 conservative_view="z", rating="SOTIB OL", confidence=70, summary="s", key_risks=["r"])

    def _run(self, fake):
        from supertrader.agents import llm
        old = sys.modules.get("anthropic")
        sys.modules["anthropic"] = fake
        try:
            return llm.debate(analyze(synthetic(400, seed=2), odds=False))
        finally:
            if old is None:
                sys.modules.pop("anthropic", None)
            else:
                sys.modules["anthropic"] = old

    def test_request_shape_and_parse(self):
        fake = FakeAnthropic(self.REPLY)
        out = self._run(fake)
        self.assertEqual(out["rating"], "SOTIB OL")
        kw = fake.calls[0]
        self.assertEqual(kw["model"], "claude-opus-5-5")
        self.assertEqual(kw["fallbacks"], "default")
        self.assertIn("server-side-fallback-2026-07-01", kw["betas"])
        self.assertEqual(kw["output_config"]["format"]["type"], "json_schema")
        self.assertNotIn("temperature", kw)
        self.assertNotIn("thinking", kw)

    def test_refusal(self):
        from supertrader.agents.llm import LLMError
        with self.assertRaises(LLMError):
            self._run(FakeAnthropic(self.REPLY, stop="refusal"))


class Pine(unittest.TestCase):
    def test_lint_clean(self):
        from pine_lint import lint
        for p in (PINE, PINE_STRAT):
            self.assertEqual(lint(p), [], p)

    def test_strategy_in_sync(self):
        import build_strategy
        with open(PINE_STRAT) as f:
            self.assertEqual(f.read(), build_strategy.build(), "python3 tradingview/build_strategy.py ni ishga tushiring")

    def test_same_rules_as_python(self):
        with open(PINE) as f:
            s = f.read()
        self.assertIn("lvl      = score >= 40 ? 0 : score >= 15 ? 1 : score > -15 ? 2 : score > -40 ? 3 : 4", s)
        for frag in ("close > sma200 ? 20.0 : -20.0", "sma50 > sma200 ? 15.0 : -15.0", "close > sma50 ? 10.0 : -10.0",
                     "ema12 > ema26 ? 10.0 : -10.0", "rsi > 70 ? -10.0 : rsi < 30 ? 10.0 : rsi >= 50 ? 10.0 : -10.0",
                     "adx >= 20 ? (diP > diM ? 10.0 : -10.0)", "stratScore = 15.0 *", "atrRank >= 95 ? 0.0",
                     "atrRank >= 80 ? 0.5 : 1.0", "strong and nz(adx) >= 25 ? 1.5 : 1.0"):
            self.assertIn(frag, s)


class CliHelp(unittest.TestCase):
    def test_every_subcommand_help(self):
        import contextlib
        import io
        from supertrader.cli import build_parser
        for cmd in ("demo", "strategies", "backtest", "leaderboard", "signal", "analyze", "reflect", "calibrate",
                    "timemachine", "size", "paper", "binance"):
            with contextlib.redirect_stdout(io.StringIO()), self.assertRaises(SystemExit) as cm:
                build_parser().parse_args([cmd, "--help"])
            self.assertEqual(cm.exception.code, 0, cmd)


if __name__ == "__main__":
    unittest.main()
